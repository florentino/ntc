﻿namespace NTC_Consolidator.NTC_View
{
    partial class frmUnderLitigation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.txtFilePath = new MetroFramework.Controls.MetroTextBox();
            this.btnBrowse = new MetroFramework.Controls.MetroButton();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.dgvAccountUnderLit = new MetroFramework.Controls.MetroGrid();
            this.btnExecute = new MetroFramework.Controls.MetroButton();
            this.lblInfo = new System.Windows.Forms.Label();
            this.lblBusy = new MetroFramework.Controls.MetroLabel();
            this.pnlWaitInfo = new System.Windows.Forms.Panel();
            this.lblWaitStatus1 = new MetroFramework.Controls.MetroLabel();
            this.lblWaitFilePath = new MetroFramework.Controls.MetroLabel();
            this.lblWaitStatus = new MetroFramework.Controls.MetroLabel();
            this.lblWaitInfo = new MetroFramework.Controls.MetroLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pnlSummary = new System.Windows.Forms.Panel();
            this.lnkDetailsInserted = new System.Windows.Forms.LinkLabel();
            this.lnkDetailsUpdated = new System.Windows.Forms.LinkLabel();
            this.lblInserted = new System.Windows.Forms.Label();
            this.lblUpdated = new System.Windows.Forms.Label();
            this.lblSHeader = new System.Windows.Forms.Label();
            this.btnClose = new MetroFramework.Controls.MetroButton();
            this.pnlInsertUpdate = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dgrViewInserted = new MetroFramework.Controls.MetroGrid();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgrViewUpdatedList = new MetroFramework.Controls.MetroGrid();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnpnlUpdateInsert = new MetroFramework.Controls.MetroButton();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAccountUnderLit)).BeginInit();
            this.pnlWaitInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlSummary.SuspendLayout();
            this.pnlInsertUpdate.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgrViewInserted)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgrViewUpdatedList)).BeginInit();
            this.SuspendLayout();
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(601, 70);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(78, 19);
            this.metroLabel1.TabIndex = 53;
            this.metroLabel1.Text = "Browse File:";
            // 
            // txtFilePath
            // 
            // 
            // 
            // 
            this.txtFilePath.CustomButton.Image = null;
            this.txtFilePath.CustomButton.Location = new System.Drawing.Point(399, 1);
            this.txtFilePath.CustomButton.Name = "";
            this.txtFilePath.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtFilePath.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtFilePath.CustomButton.TabIndex = 1;
            this.txtFilePath.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtFilePath.CustomButton.UseSelectable = true;
            this.txtFilePath.CustomButton.Visible = false;
            this.txtFilePath.Lines = new string[0];
            this.txtFilePath.Location = new System.Drawing.Point(679, 68);
            this.txtFilePath.MaxLength = 32767;
            this.txtFilePath.Name = "txtFilePath";
            this.txtFilePath.PasswordChar = '\0';
            this.txtFilePath.ReadOnly = true;
            this.txtFilePath.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtFilePath.SelectedText = "";
            this.txtFilePath.SelectionLength = 0;
            this.txtFilePath.SelectionStart = 0;
            this.txtFilePath.Size = new System.Drawing.Size(421, 23);
            this.txtFilePath.TabIndex = 52;
            this.txtFilePath.UseSelectable = true;
            this.txtFilePath.WaterMark = "Source File";
            this.txtFilePath.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtFilePath.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // btnBrowse
            // 
            this.btnBrowse.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnBrowse.Location = new System.Drawing.Point(1099, 68);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnBrowse.TabIndex = 51;
            this.btnBrowse.Text = "Bowse...";
            this.btnBrowse.UseCustomBackColor = true;
            this.btnBrowse.UseCustomForeColor = true;
            this.btnBrowse.UseSelectable = true;
            this.btnBrowse.UseStyleColors = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(27, 70);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(54, 19);
            this.metroLabel2.TabIndex = 54;
            this.metroLabel2.Text = "Preview";
            // 
            // metroPanel1
            // 
            this.metroPanel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.metroPanel1.Controls.Add(this.dgvAccountUnderLit);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(28, 92);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(1147, 421);
            this.metroPanel1.TabIndex = 55;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // dgvAccountUnderLit
            // 
            this.dgvAccountUnderLit.AllowUserToAddRows = false;
            this.dgvAccountUnderLit.AllowUserToDeleteRows = false;
            this.dgvAccountUnderLit.AllowUserToResizeRows = false;
            this.dgvAccountUnderLit.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dgvAccountUnderLit.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvAccountUnderLit.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvAccountUnderLit.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvAccountUnderLit.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle37.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle37.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle37.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle37.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle37.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAccountUnderLit.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle37;
            this.dgvAccountUnderLit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle38.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle38.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle38.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle38.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle38.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvAccountUnderLit.DefaultCellStyle = dataGridViewCellStyle38;
            this.dgvAccountUnderLit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvAccountUnderLit.EnableHeadersVisualStyles = false;
            this.dgvAccountUnderLit.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvAccountUnderLit.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvAccountUnderLit.Location = new System.Drawing.Point(0, 0);
            this.dgvAccountUnderLit.Name = "dgvAccountUnderLit";
            this.dgvAccountUnderLit.ReadOnly = true;
            this.dgvAccountUnderLit.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle39.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle39.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle39.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle39.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle39.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle39.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle39.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAccountUnderLit.RowHeadersDefaultCellStyle = dataGridViewCellStyle39;
            this.dgvAccountUnderLit.RowHeadersVisible = false;
            this.dgvAccountUnderLit.RowHeadersWidth = 150;
            this.dgvAccountUnderLit.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvAccountUnderLit.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvAccountUnderLit.Size = new System.Drawing.Size(1145, 419);
            this.dgvAccountUnderLit.Style = MetroFramework.MetroColorStyle.Blue;
            this.dgvAccountUnderLit.TabIndex = 10;
            this.dgvAccountUnderLit.Theme = MetroFramework.MetroThemeStyle.Light;
            this.dgvAccountUnderLit.UseCustomBackColor = true;
            this.dgvAccountUnderLit.UseCustomForeColor = true;
            this.dgvAccountUnderLit.UseStyleColors = true;
            // 
            // btnExecute
            // 
            this.btnExecute.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnExecute.Location = new System.Drawing.Point(1100, 556);
            this.btnExecute.Name = "btnExecute";
            this.btnExecute.Size = new System.Drawing.Size(75, 23);
            this.btnExecute.TabIndex = 56;
            this.btnExecute.Text = "&Execute";
            this.btnExecute.UseCustomBackColor = true;
            this.btnExecute.UseCustomForeColor = true;
            this.btnExecute.UseSelectable = true;
            this.btnExecute.UseStyleColors = true;
            this.btnExecute.Click += new System.EventHandler(this.btnExecute_Click);
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.Location = new System.Drawing.Point(25, 517);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(92, 13);
            this.lblInfo.TabIndex = 58;
            this.lblInfo.Text = "Total Records: ??";
            // 
            // lblBusy
            // 
            this.lblBusy.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lblBusy.ForeColor = System.Drawing.Color.Red;
            this.lblBusy.Location = new System.Drawing.Point(28, 530);
            this.lblBusy.Name = "lblBusy";
            this.lblBusy.Size = new System.Drawing.Size(349, 21);
            this.lblBusy.TabIndex = 57;
            this.lblBusy.Text = "[busy status]";
            this.lblBusy.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblBusy.UseCustomForeColor = true;
            // 
            // pnlWaitInfo
            // 
            this.pnlWaitInfo.BackColor = System.Drawing.Color.Transparent;
            this.pnlWaitInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlWaitInfo.Controls.Add(this.lblWaitStatus1);
            this.pnlWaitInfo.Controls.Add(this.lblWaitFilePath);
            this.pnlWaitInfo.Controls.Add(this.lblWaitStatus);
            this.pnlWaitInfo.Controls.Add(this.lblWaitInfo);
            this.pnlWaitInfo.Controls.Add(this.pictureBox1);
            this.pnlWaitInfo.Location = new System.Drawing.Point(1208, 258);
            this.pnlWaitInfo.Name = "pnlWaitInfo";
            this.pnlWaitInfo.Size = new System.Drawing.Size(326, 117);
            this.pnlWaitInfo.TabIndex = 59;
            // 
            // lblWaitStatus1
            // 
            this.lblWaitStatus1.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblWaitStatus1.Location = new System.Drawing.Point(3, 156);
            this.lblWaitStatus1.Name = "lblWaitStatus1";
            this.lblWaitStatus1.Size = new System.Drawing.Size(322, 19);
            this.lblWaitStatus1.TabIndex = 4;
            this.lblWaitStatus1.Text = "Total Numbers of Records:";
            this.lblWaitStatus1.Visible = false;
            // 
            // lblWaitFilePath
            // 
            this.lblWaitFilePath.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblWaitFilePath.Location = new System.Drawing.Point(3, 175);
            this.lblWaitFilePath.Name = "lblWaitFilePath";
            this.lblWaitFilePath.Size = new System.Drawing.Size(322, 19);
            this.lblWaitFilePath.TabIndex = 3;
            this.lblWaitFilePath.Text = "File Path:";
            this.lblWaitFilePath.Visible = false;
            // 
            // lblWaitStatus
            // 
            this.lblWaitStatus.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblWaitStatus.Location = new System.Drawing.Point(3, 91);
            this.lblWaitStatus.Name = "lblWaitStatus";
            this.lblWaitStatus.Size = new System.Drawing.Size(322, 19);
            this.lblWaitStatus.TabIndex = 2;
            this.lblWaitStatus.Text = "Status: ";
            // 
            // lblWaitInfo
            // 
            this.lblWaitInfo.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblWaitInfo.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lblWaitInfo.Location = new System.Drawing.Point(3, 60);
            this.lblWaitInfo.Name = "lblWaitInfo";
            this.lblWaitInfo.Size = new System.Drawing.Size(318, 23);
            this.lblWaitInfo.TabIndex = 1;
            this.lblWaitInfo.Text = "Reading ICBS Raw File, Please Wait...";
            this.lblWaitInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::NTC_Consolidator.Properties.Resources.lg_discuss_ellipsis_preloader;
            this.pictureBox1.Location = new System.Drawing.Point(3, -14);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(318, 94);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pnlSummary
            // 
            this.pnlSummary.BackColor = System.Drawing.Color.Transparent;
            this.pnlSummary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlSummary.Controls.Add(this.lnkDetailsInserted);
            this.pnlSummary.Controls.Add(this.lnkDetailsUpdated);
            this.pnlSummary.Controls.Add(this.lblInserted);
            this.pnlSummary.Controls.Add(this.lblUpdated);
            this.pnlSummary.Controls.Add(this.lblSHeader);
            this.pnlSummary.Controls.Add(this.btnClose);
            this.pnlSummary.Location = new System.Drawing.Point(679, 659);
            this.pnlSummary.Name = "pnlSummary";
            this.pnlSummary.Size = new System.Drawing.Size(283, 169);
            this.pnlSummary.TabIndex = 60;
            // 
            // lnkDetailsInserted
            // 
            this.lnkDetailsInserted.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkDetailsInserted.Location = new System.Drawing.Point(183, 84);
            this.lnkDetailsInserted.Name = "lnkDetailsInserted";
            this.lnkDetailsInserted.Size = new System.Drawing.Size(90, 14);
            this.lnkDetailsInserted.TabIndex = 62;
            this.lnkDetailsInserted.TabStop = true;
            this.lnkDetailsInserted.Text = "?? out of ??.";
            this.lnkDetailsInserted.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkDetailsInserted_LinkClicked);
            this.lnkDetailsInserted.DoubleClick += new System.EventHandler(this.lnkDetailsInserted_DoubleClick);
            // 
            // lnkDetailsUpdated
            // 
            this.lnkDetailsUpdated.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.lnkDetailsUpdated.Location = new System.Drawing.Point(188, 63);
            this.lnkDetailsUpdated.Name = "lnkDetailsUpdated";
            this.lnkDetailsUpdated.Size = new System.Drawing.Size(90, 14);
            this.lnkDetailsUpdated.TabIndex = 61;
            this.lnkDetailsUpdated.TabStop = true;
            this.lnkDetailsUpdated.Text = "?? out of ??.";
            this.lnkDetailsUpdated.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnkDetailsUpdated_LinkClicked);
            this.lnkDetailsUpdated.DoubleClick += new System.EventHandler(this.lnkDetails_DoubleClick);
            // 
            // lblInserted
            // 
            this.lblInserted.Location = new System.Drawing.Point(11, 84);
            this.lblInserted.Name = "lblInserted";
            this.lblInserted.Size = new System.Drawing.Size(267, 17);
            this.lblInserted.TabIndex = 60;
            this.lblInserted.Text = "Total Numbers of Records Inserted:  ";
            // 
            // lblUpdated
            // 
            this.lblUpdated.Location = new System.Drawing.Point(11, 63);
            this.lblUpdated.Name = "lblUpdated";
            this.lblUpdated.Size = new System.Drawing.Size(267, 14);
            this.lblUpdated.TabIndex = 59;
            this.lblUpdated.Text = "Total Numbers of Records Updated: ";
            // 
            // lblSHeader
            // 
            this.lblSHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSHeader.Location = new System.Drawing.Point(3, 10);
            this.lblSHeader.Name = "lblSHeader";
            this.lblSHeader.Size = new System.Drawing.Size(275, 33);
            this.lblSHeader.TabIndex = 58;
            this.lblSHeader.Text = "Processed Summary";
            this.lblSHeader.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnClose.Location = new System.Drawing.Point(215, 128);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(47, 23);
            this.btnClose.TabIndex = 57;
            this.btnClose.Text = "&Close";
            this.btnClose.UseCustomBackColor = true;
            this.btnClose.UseCustomForeColor = true;
            this.btnClose.UseSelectable = true;
            this.btnClose.UseStyleColors = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // pnlInsertUpdate
            // 
            this.pnlInsertUpdate.BackColor = System.Drawing.Color.Transparent;
            this.pnlInsertUpdate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlInsertUpdate.Controls.Add(this.panel2);
            this.pnlInsertUpdate.Controls.Add(this.panel1);
            this.pnlInsertUpdate.Controls.Add(this.label5);
            this.pnlInsertUpdate.Controls.Add(this.label4);
            this.pnlInsertUpdate.Controls.Add(this.label6);
            this.pnlInsertUpdate.Controls.Add(this.btnpnlUpdateInsert);
            this.pnlInsertUpdate.Location = new System.Drawing.Point(132, 659);
            this.pnlInsertUpdate.Name = "pnlInsertUpdate";
            this.pnlInsertUpdate.Size = new System.Drawing.Size(527, 404);
            this.pnlInsertUpdate.TabIndex = 63;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.dgrViewInserted);
            this.panel2.Location = new System.Drawing.Point(266, 101);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(233, 234);
            this.panel2.TabIndex = 64;
            // 
            // dgrViewInserted
            // 
            this.dgrViewInserted.AllowUserToAddRows = false;
            this.dgrViewInserted.AllowUserToDeleteRows = false;
            this.dgrViewInserted.AllowUserToResizeRows = false;
            this.dgrViewInserted.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgrViewInserted.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgrViewInserted.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgrViewInserted.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle40.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle40.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle40.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle40.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle40.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgrViewInserted.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle40;
            this.dgrViewInserted.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle41.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle41.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle41.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle41.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle41.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle41.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle41.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrViewInserted.DefaultCellStyle = dataGridViewCellStyle41;
            this.dgrViewInserted.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgrViewInserted.EnableHeadersVisualStyles = false;
            this.dgrViewInserted.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgrViewInserted.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgrViewInserted.Location = new System.Drawing.Point(0, 0);
            this.dgrViewInserted.Name = "dgrViewInserted";
            this.dgrViewInserted.ReadOnly = true;
            this.dgrViewInserted.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle42.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle42.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle42.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle42.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle42.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle42.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgrViewInserted.RowHeadersDefaultCellStyle = dataGridViewCellStyle42;
            this.dgrViewInserted.RowHeadersVisible = false;
            this.dgrViewInserted.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgrViewInserted.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrViewInserted.Size = new System.Drawing.Size(231, 232);
            this.dgrViewInserted.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.dgrViewUpdatedList);
            this.panel1.Location = new System.Drawing.Point(18, 100);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(233, 234);
            this.panel1.TabIndex = 63;
            // 
            // dgrViewUpdatedList
            // 
            this.dgrViewUpdatedList.AllowUserToAddRows = false;
            this.dgrViewUpdatedList.AllowUserToDeleteRows = false;
            this.dgrViewUpdatedList.AllowUserToResizeRows = false;
            this.dgrViewUpdatedList.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgrViewUpdatedList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgrViewUpdatedList.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgrViewUpdatedList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle43.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle43.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle43.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle43.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle43.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle43.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle43.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgrViewUpdatedList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle43;
            this.dgrViewUpdatedList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle44.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle44.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle44.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle44.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle44.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle44.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgrViewUpdatedList.DefaultCellStyle = dataGridViewCellStyle44;
            this.dgrViewUpdatedList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgrViewUpdatedList.EnableHeadersVisualStyles = false;
            this.dgrViewUpdatedList.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgrViewUpdatedList.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgrViewUpdatedList.Location = new System.Drawing.Point(0, 0);
            this.dgrViewUpdatedList.Name = "dgrViewUpdatedList";
            this.dgrViewUpdatedList.ReadOnly = true;
            this.dgrViewUpdatedList.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle45.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle45.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle45.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle45.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle45.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle45.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgrViewUpdatedList.RowHeadersDefaultCellStyle = dataGridViewCellStyle45;
            this.dgrViewUpdatedList.RowHeadersVisible = false;
            this.dgrViewUpdatedList.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgrViewUpdatedList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgrViewUpdatedList.Size = new System.Drawing.Size(231, 232);
            this.dgrViewUpdatedList.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(263, 81);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 13);
            this.label5.TabIndex = 62;
            this.label5.Text = "List of Item Inserted";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 81);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 13);
            this.label4.TabIndex = 61;
            this.label4.Text = "List of Item Updated";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(3, 10);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(519, 33);
            this.label6.TabIndex = 58;
            this.label6.Text = "Account Updated / Inserted Details";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnpnlUpdateInsert
            // 
            this.btnpnlUpdateInsert.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnpnlUpdateInsert.Location = new System.Drawing.Point(465, 363);
            this.btnpnlUpdateInsert.Name = "btnpnlUpdateInsert";
            this.btnpnlUpdateInsert.Size = new System.Drawing.Size(47, 23);
            this.btnpnlUpdateInsert.TabIndex = 57;
            this.btnpnlUpdateInsert.Text = "&Close";
            this.btnpnlUpdateInsert.UseCustomBackColor = true;
            this.btnpnlUpdateInsert.UseCustomForeColor = true;
            this.btnpnlUpdateInsert.UseSelectable = true;
            this.btnpnlUpdateInsert.UseStyleColors = true;
            this.btnpnlUpdateInsert.Click += new System.EventHandler(this.btnpnlUpdateInsert_Click);
            // 
            // frmUnderLitigation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1201, 605);
            this.Controls.Add(this.pnlInsertUpdate);
            this.Controls.Add(this.pnlSummary);
            this.Controls.Add(this.pnlWaitInfo);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.lblBusy);
            this.Controls.Add(this.btnExecute);
            this.Controls.Add(this.metroPanel1);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.txtFilePath);
            this.Controls.Add(this.btnBrowse);
            this.MaximizeBox = false;
            this.Name = "frmUnderLitigation";
            this.ShadowType = MetroFramework.Forms.MetroFormShadowType.DropShadow;
            this.Style = MetroFramework.MetroColorStyle.Yellow;
            this.Text = "Account Under Litigation";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmUnderLitigation_FormClosed);
            this.Load += new System.EventHandler(this.frmUnderLitigation_Load);
            this.metroPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAccountUnderLit)).EndInit();
            this.pnlWaitInfo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlSummary.ResumeLayout(false);
            this.pnlInsertUpdate.ResumeLayout(false);
            this.pnlInsertUpdate.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgrViewInserted)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgrViewUpdatedList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTextBox txtFilePath;
        private MetroFramework.Controls.MetroButton btnBrowse;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroGrid dgvAccountUnderLit;
        private MetroFramework.Controls.MetroButton btnExecute;
        private System.Windows.Forms.Label lblInfo;
        private MetroFramework.Controls.MetroLabel lblBusy;
        private System.Windows.Forms.Panel pnlWaitInfo;
        private MetroFramework.Controls.MetroLabel lblWaitStatus1;
        private MetroFramework.Controls.MetroLabel lblWaitFilePath;
        private MetroFramework.Controls.MetroLabel lblWaitStatus;
        private MetroFramework.Controls.MetroLabel lblWaitInfo;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel pnlSummary;
        private System.Windows.Forms.Label lblInserted;
        private System.Windows.Forms.Label lblUpdated;
        private System.Windows.Forms.Label lblSHeader;
        private MetroFramework.Controls.MetroButton btnClose;
        private System.Windows.Forms.LinkLabel lnkDetailsInserted;
        private System.Windows.Forms.LinkLabel lnkDetailsUpdated;
        private System.Windows.Forms.Panel pnlInsertUpdate;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private MetroFramework.Controls.MetroButton btnpnlUpdateInsert;
        private System.Windows.Forms.Panel panel1;
        private MetroFramework.Controls.MetroGrid dgrViewUpdatedList;
        private System.Windows.Forms.Panel panel2;
        private MetroFramework.Controls.MetroGrid dgrViewInserted;
    }
}