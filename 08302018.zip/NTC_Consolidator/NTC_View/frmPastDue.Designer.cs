﻿namespace NTC_Consolidator.NTC_View
{
    partial class frmPastDue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.dgvPastDueAccount = new MetroFramework.Controls.MetroGrid();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.txtFilePath = new MetroFramework.Controls.MetroTextBox();
            this.pnlWaitInfo = new System.Windows.Forms.Panel();
            this.lblWaitStatus1 = new MetroFramework.Controls.MetroLabel();
            this.lblWaitFilePath = new MetroFramework.Controls.MetroLabel();
            this.lblWaitStatus = new MetroFramework.Controls.MetroLabel();
            this.lblWaitInfo = new MetroFramework.Controls.MetroLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblInfo = new System.Windows.Forms.Label();
            this.lblBusy = new MetroFramework.Controls.MetroLabel();
            this.btnExecute = new MetroFramework.Controls.MetroButton();
            this.btnBrowse = new MetroFramework.Controls.MetroButton();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPastDueAccount)).BeginInit();
            this.pnlWaitInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.metroPanel1.Controls.Add(this.dgvPastDueAccount);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(30, 93);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(1144, 421);
            this.metroPanel1.TabIndex = 79;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // dgvPastDueAccount
            // 
            this.dgvPastDueAccount.AllowUserToAddRows = false;
            this.dgvPastDueAccount.AllowUserToDeleteRows = false;
            this.dgvPastDueAccount.AllowUserToResizeRows = false;
            this.dgvPastDueAccount.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.dgvPastDueAccount.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvPastDueAccount.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPastDueAccount.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvPastDueAccount.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPastDueAccount.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvPastDueAccount.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvPastDueAccount.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgvPastDueAccount.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvPastDueAccount.EnableHeadersVisualStyles = false;
            this.dgvPastDueAccount.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.dgvPastDueAccount.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.dgvPastDueAccount.Location = new System.Drawing.Point(0, 0);
            this.dgvPastDueAccount.Name = "dgvPastDueAccount";
            this.dgvPastDueAccount.ReadOnly = true;
            this.dgvPastDueAccount.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(198)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPastDueAccount.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvPastDueAccount.RowHeadersVisible = false;
            this.dgvPastDueAccount.RowHeadersWidth = 150;
            this.dgvPastDueAccount.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvPastDueAccount.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPastDueAccount.Size = new System.Drawing.Size(1142, 419);
            this.dgvPastDueAccount.Style = MetroFramework.MetroColorStyle.Blue;
            this.dgvPastDueAccount.TabIndex = 10;
            this.dgvPastDueAccount.Theme = MetroFramework.MetroThemeStyle.Light;
            this.dgvPastDueAccount.UseCustomBackColor = true;
            this.dgvPastDueAccount.UseCustomForeColor = true;
            this.dgvPastDueAccount.UseStyleColors = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(29, 70);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(54, 19);
            this.metroLabel2.TabIndex = 78;
            this.metroLabel2.Text = "Preview";
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(549, 72);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(78, 19);
            this.metroLabel1.TabIndex = 77;
            this.metroLabel1.Text = "Browse File:";
            // 
            // txtFilePath
            // 
            // 
            // 
            // 
            this.txtFilePath.CustomButton.Image = null;
            this.txtFilePath.CustomButton.Location = new System.Drawing.Point(449, 1);
            this.txtFilePath.CustomButton.Name = "";
            this.txtFilePath.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtFilePath.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtFilePath.CustomButton.TabIndex = 1;
            this.txtFilePath.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtFilePath.CustomButton.UseSelectable = true;
            this.txtFilePath.CustomButton.Visible = false;
            this.txtFilePath.Lines = new string[0];
            this.txtFilePath.Location = new System.Drawing.Point(633, 69);
            this.txtFilePath.MaxLength = 32767;
            this.txtFilePath.Name = "txtFilePath";
            this.txtFilePath.PasswordChar = '\0';
            this.txtFilePath.ReadOnly = true;
            this.txtFilePath.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtFilePath.SelectedText = "";
            this.txtFilePath.SelectionLength = 0;
            this.txtFilePath.SelectionStart = 0;
            this.txtFilePath.Size = new System.Drawing.Size(471, 23);
            this.txtFilePath.TabIndex = 76;
            this.txtFilePath.UseSelectable = true;
            this.txtFilePath.WaterMark = "Source File";
            this.txtFilePath.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtFilePath.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // pnlWaitInfo
            // 
            this.pnlWaitInfo.BackColor = System.Drawing.Color.Transparent;
            this.pnlWaitInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlWaitInfo.Controls.Add(this.lblWaitStatus1);
            this.pnlWaitInfo.Controls.Add(this.lblWaitFilePath);
            this.pnlWaitInfo.Controls.Add(this.lblWaitStatus);
            this.pnlWaitInfo.Controls.Add(this.lblWaitInfo);
            this.pnlWaitInfo.Controls.Add(this.pictureBox1);
            this.pnlWaitInfo.Location = new System.Drawing.Point(1211, 17);
            this.pnlWaitInfo.Name = "pnlWaitInfo";
            this.pnlWaitInfo.Size = new System.Drawing.Size(326, 117);
            this.pnlWaitInfo.TabIndex = 83;
            // 
            // lblWaitStatus1
            // 
            this.lblWaitStatus1.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblWaitStatus1.Location = new System.Drawing.Point(3, 156);
            this.lblWaitStatus1.Name = "lblWaitStatus1";
            this.lblWaitStatus1.Size = new System.Drawing.Size(322, 19);
            this.lblWaitStatus1.TabIndex = 4;
            this.lblWaitStatus1.Text = "Total Numbers of Records:";
            this.lblWaitStatus1.Visible = false;
            // 
            // lblWaitFilePath
            // 
            this.lblWaitFilePath.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblWaitFilePath.Location = new System.Drawing.Point(3, 175);
            this.lblWaitFilePath.Name = "lblWaitFilePath";
            this.lblWaitFilePath.Size = new System.Drawing.Size(322, 19);
            this.lblWaitFilePath.TabIndex = 3;
            this.lblWaitFilePath.Text = "File Path:";
            this.lblWaitFilePath.Visible = false;
            // 
            // lblWaitStatus
            // 
            this.lblWaitStatus.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblWaitStatus.Location = new System.Drawing.Point(3, 91);
            this.lblWaitStatus.Name = "lblWaitStatus";
            this.lblWaitStatus.Size = new System.Drawing.Size(322, 19);
            this.lblWaitStatus.TabIndex = 2;
            this.lblWaitStatus.Text = "Status: ";
            // 
            // lblWaitInfo
            // 
            this.lblWaitInfo.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblWaitInfo.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lblWaitInfo.Location = new System.Drawing.Point(3, 60);
            this.lblWaitInfo.Name = "lblWaitInfo";
            this.lblWaitInfo.Size = new System.Drawing.Size(318, 23);
            this.lblWaitInfo.TabIndex = 1;
            this.lblWaitInfo.Text = "Reading ICBS Raw File, Please Wait...";
            this.lblWaitInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::NTC_Consolidator.Properties.Resources.lg_discuss_ellipsis_preloader;
            this.pictureBox1.Location = new System.Drawing.Point(3, -14);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(318, 94);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.Location = new System.Drawing.Point(27, 518);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(92, 13);
            this.lblInfo.TabIndex = 82;
            this.lblInfo.Text = "Total Records: ??";
            // 
            // lblBusy
            // 
            this.lblBusy.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lblBusy.ForeColor = System.Drawing.Color.Red;
            this.lblBusy.Location = new System.Drawing.Point(30, 531);
            this.lblBusy.Name = "lblBusy";
            this.lblBusy.Size = new System.Drawing.Size(349, 21);
            this.lblBusy.TabIndex = 81;
            this.lblBusy.Text = "[busy status]";
            this.lblBusy.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblBusy.UseCustomForeColor = true;
            // 
            // btnExecute
            // 
            this.btnExecute.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnExecute.Location = new System.Drawing.Point(1098, 531);
            this.btnExecute.Name = "btnExecute";
            this.btnExecute.Size = new System.Drawing.Size(75, 23);
            this.btnExecute.TabIndex = 80;
            this.btnExecute.Text = "&Execute";
            this.btnExecute.UseCustomBackColor = true;
            this.btnExecute.UseCustomForeColor = true;
            this.btnExecute.UseSelectable = true;
            this.btnExecute.UseStyleColors = true;
            this.btnExecute.Click += new System.EventHandler(this.btnExecute_Click);
            // 
            // btnBrowse
            // 
            this.btnBrowse.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnBrowse.Location = new System.Drawing.Point(1100, 69);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnBrowse.TabIndex = 75;
            this.btnBrowse.Text = "Bowse...";
            this.btnBrowse.UseCustomBackColor = true;
            this.btnBrowse.UseCustomForeColor = true;
            this.btnBrowse.UseSelectable = true;
            this.btnBrowse.UseStyleColors = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // frmPastDue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1201, 605);
            this.Controls.Add(this.metroPanel1);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.txtFilePath);
            this.Controls.Add(this.pnlWaitInfo);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.lblBusy);
            this.Controls.Add(this.btnExecute);
            this.Controls.Add(this.btnBrowse);
            this.MaximizeBox = false;
            this.Name = "frmPastDue";
            this.ShadowType = MetroFramework.Forms.MetroFormShadowType.DropShadow;
            this.Style = MetroFramework.MetroColorStyle.Yellow;
            this.Text = "Past Due Account";
            this.Load += new System.EventHandler(this.frmPastDue_Load);
            this.metroPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPastDueAccount)).EndInit();
            this.pnlWaitInfo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroGrid dgvPastDueAccount;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTextBox txtFilePath;
        private System.Windows.Forms.Panel pnlWaitInfo;
        private MetroFramework.Controls.MetroLabel lblWaitStatus1;
        private MetroFramework.Controls.MetroLabel lblWaitFilePath;
        private MetroFramework.Controls.MetroLabel lblWaitStatus;
        private MetroFramework.Controls.MetroLabel lblWaitInfo;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblInfo;
        private MetroFramework.Controls.MetroLabel lblBusy;
        private MetroFramework.Controls.MetroButton btnExecute;
        private MetroFramework.Controls.MetroButton btnBrowse;
    }
}