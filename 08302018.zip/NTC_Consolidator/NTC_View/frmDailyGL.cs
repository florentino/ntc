﻿using MetroFramework;
using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Core.Repository;
using NTC_Consolidator.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmDailyGL : MetroFramework.Forms.MetroForm
    {

        private IDailyGL dailyGLRepository;
        private static frmDailyGL frmdailyGL = null;

        private BackgroundWorker retrieveWorker;
        private BackgroundWorker saveWorker;
        DataTable dtDailyGL;

        //DataTable dtupdated = new DataTable("Updated");
        NumberStyles styles;
        DateTime dateparam;
        string[] progressArray = new string[5];


        public static frmDailyGL Instance()
        {
            if (frmdailyGL == null)
            {
                frmdailyGL = new frmDailyGL();
            }
            return frmdailyGL;
        }

        public frmDailyGL()
        {
            InitializeComponent();
            this.dailyGLRepository = new DailyGLRepository(new NTC_Context_Entities());
            pnlWaitInfo.Location = new Point(this.ClientSize.Width / 2 - pnlWaitInfo.Size.Width / 2, this.ClientSize.Height / 2 - pnlWaitInfo.Size.Height / 2);
            pnlWaitInfo.Visible = false;

            lblBusy.Text = "";
        }

        private void frmDailyGL_Load(object sender, EventArgs e)
        {
            //lblWaitInfo.Text = "Fetching Data from server, Please wait...";
            //lblWaitStatus.Text = "Status: Processing...";

            //pnlWaitInfo.Visible = true;

            //retrieveWorker = new BackgroundWorker();
            //retrieveWorker.WorkerReportsProgress = true;
            //retrieveWorker.DoWork += new DoWorkEventHandler(retrieveWorker_DoWork);
            //retrieveWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(retrieveWorker_RunWorkerCompleted);
            //retrieveWorker.ProgressChanged += new ProgressChangedEventHandler(retrieveWorker_ProgressChanged);
            //retrieveWorker.WorkerSupportsCancellation = true;
            //retrieveWorker.RunWorkerAsync();
        }

        private void retrieveWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitInfo.Text = "Fetching Data from server, Please wait...";

            lblWaitInfo.Text = labelsreports[1];
        }

        private void retrieveWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";
            }
            else if (e.Error != null)
            {
                if (e.ToString().Contains("It is already opened exclusively by another user"))
                {
                    MetroMessageBox.Show(this, "\r\n" + txtFilePath.Text + " File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }
                else if (e.ToString().Contains("External table is not in the expected format"))
                {
                    MetroMessageBox.Show(this, "\r\nPlease save first the file with the extension name of \".xls\".\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }
                else
                {
                    MetroMessageBox.Show(this, "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                lblWaitStatus.Text = "Status: Error Encountered while processing";
                return;
            }
            else
            {
                lblInfo.Text = "Total Records: " + dtDailyGL.Rows.Count.ToString();

                pnlWaitInfo.Visible = false;
            }
        }

        private void retrieveWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                string connString = "";

                if (Path.GetExtension(txtFilePath.Text) == ".xls")
                    connString = string.Format("Provider = Microsoft.Jet.OLEDB.4.0;Data Source={0};" + "Extended Properties='Excel 8.0;HDR=YES;IMEX=1;'", txtFilePath.Text);

                if (Path.GetExtension(txtFilePath.Text) == ".xlsx")
                {
                    // connString = string.Format("Provider = Microsoft.ACE.OLEDB.12.0;Data Source={0};" + "Extended Properties='Excel 12.0 Xml;HDR=NO;IMEX=1;'", txtFilePath.Text);

                    MetroMessageBox.Show(this, "\r\nPlease change the file format from XLSX to XLS.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }

                // string connString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties='Excel 8.0;HDR=NO;IMEX=1;'", txtFilePath.Text);
                using (OleDbConnection conn = new OleDbConnection(connString))
                {
                    conn.Open();
                    OleDbCommand cmd = new OleDbCommand();
                    DataTable dbSchema = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    if (dbSchema == null || dbSchema.Rows.Count < 1)
                    {
                        throw new Exception("Error: Could not determined the name of the worksheet.");
                    }

                    string worksheetname = dbSchema.Rows[0]["TABLE_NAME"].ToString();


                    OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM[" + worksheetname + "]", conn);


                    DataTable dtold = new DataTable(worksheetname);

                    da.Fill(dtold);
                    progressArray[0] = (1 * 100 / dtold.Rows.Count).ToString(); // percent
                    progressArray[1] = "Loading records, Please wait..."; //header text
                    progressArray[2] = "Status: In-progress"; //Status
                    progressArray[3] = "";// i.ToString(); //column
                    progressArray[4] = "0";// dtold.Columns.Count;// headers.Length.ToString(); //total column

                    retrieveWorker.ReportProgress(1 * 100 / dtold.Rows.Count, progressArray); // wla lng, just to show the loading information
                    dtDailyGL = dtold;

                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error encountered while reading the file, Please contact your system administrator");
            }

        }

        private void table()
        {
            dtDailyGL.Columns.Add("GMACT");
            dtDailyGL.Columns.Add("GMCURC");
            dtDailyGL.Columns.Add("GMCNTR");
            dtDailyGL.Columns.Add("GMNAME");
            dtDailyGL.Columns.Add("GMCBAL");
            dtDailyGL.Columns.Add("GMFCYE");
            dtDailyGL.Columns.Add("GMEMO");
            dtDailyGL.Columns.Add("GFEMO");
            dtDailyGL.Columns.Add("GMYBAL");
            dtDailyGL.Columns.Add("GMFCYY");
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            lblWaitInfo.Text = "Please wait, While loading excel file.";
            lblWaitStatus.Text = "Status: Processing...";

            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "NTC Consolidator";
            dlg.Filter = "Excel Files(.xls)|*.xls";//| Excel Files(.xlsx) | *.xlsx";

            // dlg.Multiselect = true;

            DialogResult resDlg = dlg.ShowDialog();

            if (resDlg == DialogResult.OK)
            {
                txtFilePath.Text = dlg.FileName;

                pnlWaitInfo.Visible = true;

                retrieveWorker = new BackgroundWorker();
                retrieveWorker.WorkerReportsProgress = true;
                retrieveWorker.DoWork += new DoWorkEventHandler(retrieveWorker_DoWork);
                retrieveWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(retrieveWorker_RunWorkerCompleted);
                retrieveWorker.ProgressChanged += new ProgressChangedEventHandler(retrieveWorker_ProgressChanged);
                retrieveWorker.WorkerSupportsCancellation = true;
                retrieveWorker.RunWorkerAsync();
            }
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            pnlWaitInfo.Visible = true;
            lblWaitInfo.Text = "Saving records, Please wait...";
            lblWaitStatus.Text = "Status: In-progress...";


            saveWorker = new BackgroundWorker();
            saveWorker.WorkerReportsProgress = true;
            saveWorker.DoWork += new DoWorkEventHandler(saveWorker_DoWork);
            saveWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(saveWorker_RunWorkerCompleted);
            saveWorker.ProgressChanged += new ProgressChangedEventHandler(saveWorker_ProgressChanged);
            saveWorker.WorkerSupportsCancellation = true;
            saveWorker.RunWorkerAsync();
        }


        private void saveWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                var iCount = 1;
                foreach (DataRow dritem in dtDailyGL.Rows)
                {
                    BDOLF_DailyGL data = new BDOLF_DailyGL();

                    // var _System = dritem["SYSTEM"].ToString();

                    #region Data
                    progressArray[0] = (iCount * 100 / dtDailyGL.Rows.Count).ToString(); // percent
                    progressArray[1] = "Saving records, Please wait..."; //header text
                    progressArray[2] = "Status: In-progress"; //Status
                    progressArray[3] = "";// i.ToString(); //column
                    progressArray[4] = "0";// dtold.Columns.Count;// headers.Length.ToString(); //total column

                    data.GMACT = dritem["GMACT"] == null ? "" : dritem["GMACT"].ToString();
                    data.isDeleted = false;
                    data.CreatedBy = frmConsolidator.UserName;
                    data.CreatedDate = DateTime.Today;
                    data.GMCURC = dritem["GMCURC"] == null ? 0 : Convert.ToInt32(dritem["GMCURC"]);
                    data.GMCNTR = dritem["ACCOUNTNO"] == null ? 0 : Convert.ToInt32(dritem["ACCOUNTNO"]);
                    data.GMNAME = dritem["GMNAME"] == null ? "" : dritem["GMNAME"].ToString();
                    data.GMCBAL = dritem["GMCBAL"] == null ? 0M : Convert.ToDecimal(dritem["GMCBAL"]);
                    data.GMFCYE = dritem["GMFCYE"] == null ? 0 : Convert.ToInt32(dritem["GMFCYE"]);
                    data.GMEMO = dritem["GMEMO"] == null ? 0M : Convert.ToDecimal(dritem["GMEMO"]);
                    data.GFEMO = dritem["GFEMO"] == null ? 0 : Convert.ToInt32(dritem["GFEMO"]);
                    data.GMYBAL = dritem["GMYBAL"] == null ? 0M : Convert.ToDecimal(dritem["GMYBAL"]);
                    data.GMFCYY = dritem["GMFCYY"] == null ? 0 : Convert.ToInt32(dritem["GMFCYY"]);
                    #endregion

                    dailyGLRepository.DeleteGL(data);
                    dailyGLRepository.InsertRecord(data);

                    saveWorker.ReportProgress(iCount++ * 100 / dtDailyGL.Rows.Count, progressArray); // wla lng
                }
            }
            catch (Exception ex)
            {

                if (ex.Message.Contains("It is already opened exclusively by another user"))
                {
                    MetroMessageBox.Show(this, "\r\n" + txtFilePath.Text + " File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                else
                {
                    MetroMessageBox.Show(this, "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                throw new Exception("Error encountered while reading the file, Please contact your system administrator");
            }
        }

        private void saveWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";
                MetroMessageBox.Show(this, "\r\nOop! Something went wrong and coudn't process your request.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if (e.Error != null)
            {
                lblWaitStatus.Text = "Status: Error Encountered while processing";
                MetroMessageBox.Show(this, "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            else
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "DONE";
                lblWaitStatus.Text = "Status: Success";

                MetroMessageBox.Show(this, "\r\nPast Due Account was successfully appended.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void saveWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitStatus.Text = labelsreports[2].ToString();
            lblWaitInfo.Text = labelsreports[1].ToString();
        }
    }
}
