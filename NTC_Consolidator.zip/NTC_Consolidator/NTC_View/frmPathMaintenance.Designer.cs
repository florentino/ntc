﻿namespace NTC_Consolidator.NTC_View
{
    partial class frmPathMaintenance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.txtICBSFilePath = new MetroFramework.Controls.MetroTextBox();
            this.btnCancel = new MetroFramework.Controls.MetroButton();
            this.btnICBSBrowse = new MetroFramework.Controls.MetroButton();
            this.btnOK = new MetroFramework.Controls.MetroButton();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.txtAAFFilePath = new MetroFramework.Controls.MetroTextBox();
            this.btnAAFBrowse = new MetroFramework.Controls.MetroButton();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.txtFAMSFilePath = new MetroFramework.Controls.MetroTextBox();
            this.btnFAMSBrowse = new MetroFramework.Controls.MetroButton();
            this.SuspendLayout();
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(23, 95);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(123, 19);
            this.metroLabel1.TabIndex = 55;
            this.metroLabel1.Text = "Set ICBS Raw File/s:";
            // 
            // txtICBSFilePath
            // 
            // 
            // 
            // 
            this.txtICBSFilePath.CustomButton.Image = null;
            this.txtICBSFilePath.CustomButton.Location = new System.Drawing.Point(204, 1);
            this.txtICBSFilePath.CustomButton.Name = "";
            this.txtICBSFilePath.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtICBSFilePath.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtICBSFilePath.CustomButton.TabIndex = 1;
            this.txtICBSFilePath.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtICBSFilePath.CustomButton.UseSelectable = true;
            this.txtICBSFilePath.CustomButton.Visible = false;
            this.txtICBSFilePath.Lines = new string[0];
            this.txtICBSFilePath.Location = new System.Drawing.Point(27, 117);
            this.txtICBSFilePath.MaxLength = 32767;
            this.txtICBSFilePath.Name = "txtICBSFilePath";
            this.txtICBSFilePath.PasswordChar = '\0';
            this.txtICBSFilePath.ReadOnly = true;
            this.txtICBSFilePath.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtICBSFilePath.SelectedText = "";
            this.txtICBSFilePath.SelectionLength = 0;
            this.txtICBSFilePath.SelectionStart = 0;
            this.txtICBSFilePath.Size = new System.Drawing.Size(226, 23);
            this.txtICBSFilePath.TabIndex = 54;
            this.txtICBSFilePath.UseSelectable = true;
            this.txtICBSFilePath.WaterMark = "ICBS File Path";
            this.txtICBSFilePath.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtICBSFilePath.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnCancel.Location = new System.Drawing.Point(237, 327);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(45, 23);
            this.btnCancel.TabIndex = 53;
            this.btnCancel.Text = "&Close";
            this.btnCancel.UseCustomBackColor = true;
            this.btnCancel.UseCustomForeColor = true;
            this.btnCancel.UseSelectable = true;
            this.btnCancel.UseStyleColors = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnICBSBrowse
            // 
            this.btnICBSBrowse.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnICBSBrowse.Location = new System.Drawing.Point(252, 117);
            this.btnICBSBrowse.Name = "btnICBSBrowse";
            this.btnICBSBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnICBSBrowse.TabIndex = 52;
            this.btnICBSBrowse.Text = "Bowse...";
            this.btnICBSBrowse.UseCustomBackColor = true;
            this.btnICBSBrowse.UseCustomForeColor = true;
            this.btnICBSBrowse.UseSelectable = true;
            this.btnICBSBrowse.UseStyleColors = true;
            this.btnICBSBrowse.Click += new System.EventHandler(this.btnICBSBrowse_Click);
            // 
            // btnOK
            // 
            this.btnOK.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnOK.Location = new System.Drawing.Point(288, 327);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(43, 23);
            this.btnOK.TabIndex = 51;
            this.btnOK.Text = "&Save";
            this.btnOK.UseCustomBackColor = true;
            this.btnOK.UseCustomForeColor = true;
            this.btnOK.UseSelectable = true;
            this.btnOK.UseStyleColors = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(27, 171);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(121, 19);
            this.metroLabel2.TabIndex = 58;
            this.metroLabel2.Text = "Set AAF Raw File/s:";
            // 
            // txtAAFFilePath
            // 
            // 
            // 
            // 
            this.txtAAFFilePath.CustomButton.Image = null;
            this.txtAAFFilePath.CustomButton.Location = new System.Drawing.Point(204, 1);
            this.txtAAFFilePath.CustomButton.Name = "";
            this.txtAAFFilePath.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtAAFFilePath.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtAAFFilePath.CustomButton.TabIndex = 1;
            this.txtAAFFilePath.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtAAFFilePath.CustomButton.UseSelectable = true;
            this.txtAAFFilePath.CustomButton.Visible = false;
            this.txtAAFFilePath.Lines = new string[0];
            this.txtAAFFilePath.Location = new System.Drawing.Point(31, 193);
            this.txtAAFFilePath.MaxLength = 32767;
            this.txtAAFFilePath.Name = "txtAAFFilePath";
            this.txtAAFFilePath.PasswordChar = '\0';
            this.txtAAFFilePath.ReadOnly = true;
            this.txtAAFFilePath.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAAFFilePath.SelectedText = "";
            this.txtAAFFilePath.SelectionLength = 0;
            this.txtAAFFilePath.SelectionStart = 0;
            this.txtAAFFilePath.Size = new System.Drawing.Size(226, 23);
            this.txtAAFFilePath.TabIndex = 57;
            this.txtAAFFilePath.UseSelectable = true;
            this.txtAAFFilePath.WaterMark = "AAF File Path";
            this.txtAAFFilePath.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtAAFFilePath.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // btnAAFBrowse
            // 
            this.btnAAFBrowse.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnAAFBrowse.Location = new System.Drawing.Point(256, 193);
            this.btnAAFBrowse.Name = "btnAAFBrowse";
            this.btnAAFBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnAAFBrowse.TabIndex = 56;
            this.btnAAFBrowse.Text = "Bowse...";
            this.btnAAFBrowse.UseCustomBackColor = true;
            this.btnAAFBrowse.UseCustomForeColor = true;
            this.btnAAFBrowse.UseSelectable = true;
            this.btnAAFBrowse.UseStyleColors = true;
            this.btnAAFBrowse.Click += new System.EventHandler(this.btnAAFBrowse_Click);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(27, 244);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(129, 19);
            this.metroLabel3.TabIndex = 61;
            this.metroLabel3.Text = "Set FaMS Raw File/s:";
            // 
            // txtFAMSFilePath
            // 
            // 
            // 
            // 
            this.txtFAMSFilePath.CustomButton.Image = null;
            this.txtFAMSFilePath.CustomButton.Location = new System.Drawing.Point(204, 1);
            this.txtFAMSFilePath.CustomButton.Name = "";
            this.txtFAMSFilePath.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtFAMSFilePath.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtFAMSFilePath.CustomButton.TabIndex = 1;
            this.txtFAMSFilePath.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtFAMSFilePath.CustomButton.UseSelectable = true;
            this.txtFAMSFilePath.CustomButton.Visible = false;
            this.txtFAMSFilePath.Lines = new string[0];
            this.txtFAMSFilePath.Location = new System.Drawing.Point(31, 266);
            this.txtFAMSFilePath.MaxLength = 32767;
            this.txtFAMSFilePath.Name = "txtFAMSFilePath";
            this.txtFAMSFilePath.PasswordChar = '\0';
            this.txtFAMSFilePath.ReadOnly = true;
            this.txtFAMSFilePath.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtFAMSFilePath.SelectedText = "";
            this.txtFAMSFilePath.SelectionLength = 0;
            this.txtFAMSFilePath.SelectionStart = 0;
            this.txtFAMSFilePath.Size = new System.Drawing.Size(226, 23);
            this.txtFAMSFilePath.TabIndex = 60;
            this.txtFAMSFilePath.UseSelectable = true;
            this.txtFAMSFilePath.WaterMark = "FaMS File Path";
            this.txtFAMSFilePath.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtFAMSFilePath.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // btnFAMSBrowse
            // 
            this.btnFAMSBrowse.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnFAMSBrowse.Location = new System.Drawing.Point(256, 266);
            this.btnFAMSBrowse.Name = "btnFAMSBrowse";
            this.btnFAMSBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnFAMSBrowse.TabIndex = 59;
            this.btnFAMSBrowse.Text = "Bowse...";
            this.btnFAMSBrowse.UseCustomBackColor = true;
            this.btnFAMSBrowse.UseCustomForeColor = true;
            this.btnFAMSBrowse.UseSelectable = true;
            this.btnFAMSBrowse.UseStyleColors = true;
            this.btnFAMSBrowse.Click += new System.EventHandler(this.btnFAMSBrowse_Click);
            // 
            // frmPathMaintenance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(365, 364);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.txtFAMSFilePath);
            this.Controls.Add(this.btnFAMSBrowse);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.txtAAFFilePath);
            this.Controls.Add(this.btnAAFBrowse);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.txtICBSFilePath);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnICBSBrowse);
            this.Controls.Add(this.btnOK);
            this.MaximizeBox = false;
            this.Name = "frmPathMaintenance";
            this.ShadowType = MetroFramework.Forms.MetroFormShadowType.DropShadow;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Style = MetroFramework.MetroColorStyle.Yellow;
            this.Text = "File Path Maintenance";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmPathMaintenance_FormClosed);
            this.Load += new System.EventHandler(this.frmPathMaintenance_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTextBox txtICBSFilePath;
        private MetroFramework.Controls.MetroButton btnCancel;
        private MetroFramework.Controls.MetroButton btnICBSBrowse;
        private MetroFramework.Controls.MetroButton btnOK;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroTextBox txtAAFFilePath;
        private MetroFramework.Controls.MetroButton btnAAFBrowse;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroTextBox txtFAMSFilePath;
        private MetroFramework.Controls.MetroButton btnFAMSBrowse;
    }
}