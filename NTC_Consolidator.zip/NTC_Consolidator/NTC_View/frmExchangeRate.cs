﻿using NTC.Infrastructure.Services;
using NTC_Consolidator.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmExchangeRate : MetroFramework.Forms.MetroForm
    {
        private static frmExchangeRate rateform = null;
        public static frmExchangeRate Instance()
        {
            if (rateform == null)
            {
                rateform = new frmExchangeRate();
            }
            return rateform;
        }

        public frmExchangeRate()
        {
            //if (Program.Role != "Accounting")
            //{
            //    MetroFramework.MetroMessageBox.Show(this, "\r\n\r\nSorry, You dont have a permission to access this module, Please contact your system administrator", "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    Application.Exit();
            //}
            InitializeComponent();
        }

        private void frmExchangeRate_Load(object sender, EventArgs e)
        {
            GetCurrency();
        }

        private void GetCurrency()
        {
            var currencies = CultureInfo.GetCultures(CultureTypes.SpecificCultures)
                                                    .Select(ci => ci.LCID).Distinct()
                                                    .Select(id => new RegionInfo(id))
                                                    .GroupBy(r => r.ISOCurrencySymbol)
                                                    .Select(g => g.First())
                                                    .Select(r => new
                                                    {
                                                        r.ISOCurrencySymbol,
                                                        r.CurrencyEnglishName,
                                                        r.CurrencySymbol,
                                                        r.Name,
                                                    }).ToList();

            DataTable dtcurrencies = new DataTable();
            dtcurrencies.Clear();
            dtcurrencies.Columns.Add("ID");
            dtcurrencies.Columns.Add("CountryName");
            dtcurrencies.Columns.Add("CurrencySymbol");
            dtcurrencies.Columns.Add("CurrencyEnglishName");
            DataRow dr = null;

            var rowNum = 0;
            foreach (var currency in currencies)
            {
                rowNum++;
                dr = dtcurrencies.NewRow();
                dr["ID"] = rowNum;
                dr["CountryName"] = currency.Name;
                dr["CurrencySymbol"] = currency.ISOCurrencySymbol;
                dr["CurrencyEnglishName"] = currency.CurrencyEnglishName + " ( " + currency.ISOCurrencySymbol + " ) " + currency.CurrencySymbol;
                dtcurrencies.Rows.Add(dr);
            }

            dtcurrencies.DefaultView.Sort = "[CurrencyEnglishName] ASC";

            cmbDescription.DataSource = dtcurrencies;
            cmbDescription.DisplayMember = "CurrencyEnglishName";
            cmbDescription.ValueMember = "CurrencySymbol";
            //cmbDescription.SelectedText = "Philippine Peso  PHP  PhP";
            cmbDescription.SelectedIndex = -1;
        }

        private void txtRate_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            decimal x;
            if (ch == (char)Keys.Back)
            {
                e.Handled = false;
            }
            else if (!char.IsDigit(ch) && ch != '.' || !Decimal.TryParse(txtRate.Text + ch, out x))
            {
                e.Handled = true;
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            var isPassed = false;
            var selectedCurrency = cmbDescription.SelectedValue != null ? cmbDescription.SelectedValue.ToString() : "";
            var rateAmount = txtRate.Text;

            #region CorrespondingGL Validation Using EF DataAnnotation

            ExchangeRate eRate = new ExchangeRate();

            isPassed = IsValid(isPassed, selectedCurrency, rateAmount, eRate); //Check for Valid Input

            if (!isPassed)
            {
                return;
            }
            else
            {
                //validate first before saving
                var _instance = new NTCService();

                var retval = _instance.InsertCurrencyType(selectedCurrency, rateAmount, Program.UserName);

                if (retval == 1)//retval == 1 Successfully saved
                {
                    MetroFramework.MetroMessageBox.Show(this, "\r\n\r\nSuccessfully saved", "Exchange Rate", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    cmbDescription.SelectedIndex = -1;
                    txtRate.Text = "";
                }
                else if (retval == 0) //retval == 0 GL Code Already Exist
                {
                    MetroFramework.MetroMessageBox.Show(this, "\r\n\r\nCurrency Type Already Exist in the Database", "Exists", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else if (retval == 2) //retval == 2 error encountered
                {
                    MetroFramework.MetroMessageBox.Show(this, "\r\n\r\nError encountered, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
            }

            #endregion
        }

        //IsValid(isPassed, selectedCurrency, rateAmount, eRate); //Check for Valid Input
        private bool IsValid(bool isPassed, string selectedCurrency, string rateAmount, ExchangeRate eRate)
        {
            isPassed = true;

            try
            {
                if (string.IsNullOrEmpty(selectedCurrency))
                {
                    eRate.CurrencyCode = "";
                }
                else
                {
                    lblErrCurrType.Text = "";
                }
            }
            catch (ValidationException ex)
            {
                lblErrCurrType.Text = ex.Message;
                isPassed = false;
            }

            try
            {
                if (string.IsNullOrEmpty(rateAmount))
                {
                    eRate.CurrencyRate = "";
                }
                else
                {
                    lblErrRate.Text = "";
                }
            }
            catch (ValidationException ex)
            {
                lblErrRate.Text = ex.Message;
                isPassed = false;
            }

            return isPassed;
        }

    }
}
