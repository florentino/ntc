﻿using MetroFramework;
using NTC.Infrastructure.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmPathMaintenance : MetroFramework.Forms.MetroForm
    {
        private string _icbs = "";
        private string _icbsEXT = "";
        private string _aafEXT = "";
        private string _aaf = "";
        private string _fams = "";
        private string _famsEXT = "";

        private static frmPathMaintenance mform = null;

        public static frmPathMaintenance Instance()
        {
            if (mform == null)
            {
                mform = new frmPathMaintenance();
            }
            return mform;
        }

        public frmPathMaintenance()
        {
            InitializeComponent();
        }

        private void frmPathMaintenance_Load(object sender, EventArgs e)
        {

        }

        private void btnICBSBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "NTC Consolidator";
            dlg.Filter = "Text Files(.txt) | *.txt| CSV Files(.csv)|*.csv";


            // dlg.Multiselect = true;

            DialogResult dr = dlg.ShowDialog();

            if (dr == DialogResult.OK)
            {
                _icbs = Path.GetDirectoryName(dlg.FileName);
                _icbsEXT = Path.GetExtension(dlg.FileName);
                txtICBSFilePath.Text = dlg.FileName;
            }
        }

        private void btnAAFBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "NTC Consolidator";
            dlg.Filter = "Excel Files(.xls)|*.xls| Excel Files(.xlsx) | *.xlsx";
            // dlg.Multiselect = true;

            DialogResult dr = dlg.ShowDialog();

            if (dr == DialogResult.OK)
            {
                _aaf = Path.GetDirectoryName(dlg.FileName);
                _aafEXT = Path.GetExtension(dlg.FileName);
                txtAAFFilePath.Text = dlg.FileName;
            }
        }

        private void btnFAMSBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "NTC Consolidator";
            dlg.Filter = "Excel Files(.xls)|*.xls| Excel Files(.xlsx) | *.xlsx";
            // dlg.Multiselect = true;

            DialogResult dr = dlg.ShowDialog();

            if (dr == DialogResult.OK)
            {
                _fams = Path.GetDirectoryName(dlg.FileName);//dlg.FileName;
                _famsEXT = Path.GetExtension(dlg.FileName);
                txtFAMSFilePath.Text = dlg.FileName;
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            var _instance = new NTCService();

            var retval = _instance.InsertFilePAth(_icbs, _icbsEXT, _aaf, _aafEXT, _fams, _famsEXT, Program.UserName, DateTime.Now);

            if (retval == 1)//retval == 1 Successfully saved
            {
                MetroMessageBox.Show(this, "\r\n\r\nSuccessfully saved", "Raw File Path Maintenance", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //MetroMessageBox.Show(new Form() { TopMost = true, StartPosition = FormStartPosition.CenterScreen }, "\r\n\r\nSuccessfully saved", "Raw File Path Maintenance", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (retval == 2) //retval == 2 error encountered
            {
                MetroMessageBox.Show(this, "\r\n\r\nError encountered, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                //MetroMessageBox.Show(new Form() { TopMost = true, StartPosition = FormStartPosition.CenterScreen }, "\r\n\r\nError encountered, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            //frmPathMaintenance.mform = null;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            frmPathMaintenance.mform = null;
            this.Close();
        }

        private void frmPathMaintenance_FormClosed(object sender, FormClosedEventArgs e)
        {
            frmPathMaintenance.mform = null;
        }
    }
}
