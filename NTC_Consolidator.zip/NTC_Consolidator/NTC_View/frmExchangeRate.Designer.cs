﻿namespace NTC_Consolidator.NTC_View
{
    partial class frmExchangeRate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblErrRate = new MetroFramework.Controls.MetroLabel();
            this.lblErrCurrType = new MetroFramework.Controls.MetroLabel();
            this.txtRate = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.btnSubmit = new MetroFramework.Controls.MetroButton();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.cmbDescription = new MetroFramework.Controls.MetroComboBox();
            this.SuspendLayout();
            // 
            // lblErrRate
            // 
            this.lblErrRate.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblErrRate.ForeColor = System.Drawing.Color.Red;
            this.lblErrRate.Location = new System.Drawing.Point(30, 205);
            this.lblErrRate.Name = "lblErrRate";
            this.lblErrRate.Size = new System.Drawing.Size(278, 19);
            this.lblErrRate.Style = MetroFramework.MetroColorStyle.Red;
            this.lblErrRate.TabIndex = 27;
            this.lblErrRate.UseStyleColors = true;
            // 
            // lblErrCurrType
            // 
            this.lblErrCurrType.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblErrCurrType.ForeColor = System.Drawing.Color.Red;
            this.lblErrCurrType.Location = new System.Drawing.Point(29, 131);
            this.lblErrCurrType.Name = "lblErrCurrType";
            this.lblErrCurrType.Size = new System.Drawing.Size(278, 19);
            this.lblErrCurrType.Style = MetroFramework.MetroColorStyle.Red;
            this.lblErrCurrType.TabIndex = 26;
            this.lblErrCurrType.UseStyleColors = true;
            // 
            // txtRate
            // 
            this.txtRate.BackColor = System.Drawing.Color.White;
            // 
            // 
            // 
            this.txtRate.CustomButton.Image = null;
            this.txtRate.CustomButton.Location = new System.Drawing.Point(256, 1);
            this.txtRate.CustomButton.Name = "";
            this.txtRate.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtRate.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtRate.CustomButton.TabIndex = 1;
            this.txtRate.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtRate.CustomButton.UseSelectable = true;
            this.txtRate.CustomButton.Visible = false;
            this.txtRate.FontSize = MetroFramework.MetroTextBoxSize.Medium;
            this.txtRate.Lines = new string[0];
            this.txtRate.Location = new System.Drawing.Point(30, 179);
            this.txtRate.MaxLength = 32767;
            this.txtRate.Name = "txtRate";
            this.txtRate.PasswordChar = '\0';
            this.txtRate.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtRate.SelectedText = "";
            this.txtRate.SelectionLength = 0;
            this.txtRate.SelectionStart = 0;
            this.txtRate.Size = new System.Drawing.Size(278, 23);
            this.txtRate.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtRate.TabIndex = 25;
            this.txtRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtRate.UseSelectable = true;
            this.txtRate.WaterMark = "0.0000";
            this.txtRate.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtRate.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtRate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRate_KeyPress);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(30, 157);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(35, 19);
            this.metroLabel3.TabIndex = 24;
            this.metroLabel3.Text = "Rate";
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(246, 253);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(61, 34);
            this.btnSubmit.Style = MetroFramework.MetroColorStyle.Blue;
            this.btnSubmit.TabIndex = 20;
            this.btnSubmit.Text = "&Submit";
            this.btnSubmit.UseSelectable = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(29, 77);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(93, 19);
            this.metroLabel2.TabIndex = 30;
            this.metroLabel2.Text = "Currency Type";
            // 
            // cmbDescription
            // 
            this.cmbDescription.DropDownHeight = 80;
            this.cmbDescription.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbDescription.FormattingEnabled = true;
            this.cmbDescription.IntegralHeight = false;
            this.cmbDescription.ItemHeight = 23;
            this.cmbDescription.Location = new System.Drawing.Point(30, 99);
            this.cmbDescription.MaxDropDownItems = 20;
            this.cmbDescription.Name = "cmbDescription";
            this.cmbDescription.Size = new System.Drawing.Size(277, 29);
            this.cmbDescription.Sorted = true;
            this.cmbDescription.TabIndex = 31;
            this.cmbDescription.UseSelectable = true;
            this.cmbDescription.UseStyleColors = true;
            // 
            // frmExchangeRate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(339, 309);
            this.Controls.Add(this.cmbDescription);
            this.Controls.Add(this.metroLabel2);
            this.Controls.Add(this.lblErrRate);
            this.Controls.Add(this.lblErrCurrType);
            this.Controls.Add(this.txtRate);
            this.Controls.Add(this.metroLabel3);
            this.Controls.Add(this.btnSubmit);
            this.MaximizeBox = false;
            this.Name = "frmExchangeRate";
            this.Style = MetroFramework.MetroColorStyle.Yellow;
            this.Text = "Exchange Rate";
            this.Load += new System.EventHandler(this.frmExchangeRate_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroLabel lblErrRate;
        private MetroFramework.Controls.MetroLabel lblErrCurrType;
        private MetroFramework.Controls.MetroTextBox txtRate;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel cmbCurrencyType;
        private MetroFramework.Controls.MetroButton btnSubmit;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroComboBox cmbDescription;
    }
}