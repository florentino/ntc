﻿using NTC.Core;
using NTC.Infrastructure.Implementation.UnitOfWork;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace NTC.Infrastructure.Services
{
    public class NTCService
    {
        private UnitOfWork uow = null;

        public NTCService()
        {
            uow = new UnitOfWork();
        }

        public NTCService(UnitOfWork uow_)
        {
            this.uow = uow_;
        }

        #region Corresnponding GL
        //For GL
        private bool isExistGL(string code)
        {
            return uow.CorrespondingGLRepository.GetAll().Where(x => x.GLCode.Contains(code)).ToList().Count > 0 ? true : false;
        }

        //For Gl
        public DataTable GetAllGLRecord()
        {
            var val = uow.CorrespondingGLRepository.GetAll().Where(a => a.isDeleted == false).ToList();


            DataTable dt = new DataTable();
            dt.Columns.Add("RowID");
            dt.Columns.Add("GLCode");
            dt.Columns.Add("GLName");
            dt.Columns.Add("ProductDesc");
            dt.Columns.Add("System");
            dt.Columns.Add("Status");
            dt.Columns.Add("CreatedDate");
            dt.Columns.Add("CreatedBy");
            DataRow dr = null;
            var rowCount = 1;
            foreach (var item in val)
            {
                dr = dt.NewRow();
                dr["RowID"] = rowCount++;
                dr["GLCode"] = item.GLCode;
                dr["GLName"] = item.GLName;
                dr["ProductDesc"] = item.ProductDesc;
                dr["System"] = item.System;
                dr["Status"] = item.Status;
                dr["CreatedDate"] = Convert.ToDateTime(item.CreatedDate.ToString()).ToString("d");
                dr["CreatedBy"] = item.CreatedBy;
                dt.Rows.Add(dr);
            }
            return dt;
        }

        //For GL
        public int InsertGL(string txtcode, string txtname, string username, string system, string status, string product)
        {
            var retVal = 0;

            try
            {
                if (!isExistGL(txtcode))
                {
                    var gldata = new BDOLF_CorrepondingGL();

                    gldata.GLCode = txtcode;
                    gldata.GLName = txtname;

                    gldata.ProductDesc = product;
                    gldata.Status = status;
                    gldata.System = system;

                    gldata.CreatedBy = username;
                    gldata.CreatedDate = DateTime.Now;

                    uow.CorrespondingGLRepository.Add(gldata);
                    uow.SaveChanges();
                    retVal = 1;
                }
            }
            catch (Exception ex)
            {
                retVal = 2;
            }

            return retVal;
        }
        #endregion

        #region ExchangeRate
        //For ExchangeRate
        public int InsertCurrencyType(string selectedCurrency, string rateAmount, string username)
        {
            var retVal = 0;

            try
            {
                if (!isExistCurrencyRate(selectedCurrency))
                {
                    var ratedata = new BDOLF_ExchangeRate();

                    ratedata.CurrencyCode = selectedCurrency;
                    ratedata.CurrencyRate = Convert.ToDecimal(rateAmount);
                    ratedata.CreatedBy = username;
                    ratedata.CreatedDate = DateTime.Now;

                    uow.ExchangeRateRepository.Add(ratedata);
                    uow.SaveChanges();
                    retVal = 1;
                }
            }
            catch (Exception ex)
            {
                retVal = 2;
            }

            return retVal;
        }

        //For ExchangeRate
        private bool isExistCurrencyRate(string code)
        {
            return uow.ExchangeRateRepository.GetAll().Where(x => x.CurrencyCode.Contains(code)).ToList().Count > 0 ? true : false;
        }

        //For ExchangeRate
        public DataTable GetAllExchangeRateRecord()
        {
            var val = uow.ExchangeRateRepository.GetAll().ToList();
            DataTable dt = new DataTable();

            dt.Columns.Add("CurrencyCode");
            dt.Columns.Add("CurrencyRate");
            dt.Columns.Add("CreatedDate");
            dt.Columns.Add("CreatedBy");
            DataRow dr = null;

            foreach (var item in val)
            {
                dr = dt.NewRow();
                dr["CurrencyCode"] = item.CurrencyCode;
                dr["CurrencyRate"] = item.CurrencyRate;
                dr["CreatedDate"] = Convert.ToDateTime(item.CreatedDate.ToString()).ToString("d");
                dr["CreatedBy"] = item.CreatedBy;
                dt.Rows.Add(dr);
            }
            return dt;
        }
        #endregion

        #region frmQualifyingCapital
        //For frmQualifyingCapital
        public int InsertCapital(string Description, string Amount, string username)
        {
            var retVal = 0;

            try
            {
                if (!isExistCurrencyRate(Description))
                {
                    var capitaldata = new BDOLF_QualifyingCapital();

                    capitaldata.Description = Description;
                    capitaldata.Amount = Convert.ToDecimal(Amount);
                    capitaldata.CreatedBy = username;
                    capitaldata.CreatedDate = DateTime.Now;

                    uow.QualifyingCapitalRepository.Add(capitaldata);
                    uow.SaveChanges();
                    retVal = 1;
                }
            }
            catch (Exception ex)
            {
                retVal = 2;
            }

            return retVal;
        }

        //For frmQualifyingCapital
        private bool isExistQualifyingCapital(string code)
        {
            return uow.QualifyingCapitalRepository.GetAll().Where(x => x.Description.Contains(code)).ToList().Count > 0 ? true : false;
        }

        //For frmQualifyingCapital
        public DataTable GetAllQualifyingCapitalRecord()
        {
            var val = uow.QualifyingCapitalRepository.GetAll().ToList();
            DataTable dt = new DataTable();

            dt.Columns.Add("Description");
            dt.Columns.Add("Amount");
            dt.Columns.Add("CreatedDate");
            dt.Columns.Add("CreatedBy");
            DataRow dr = null;

            foreach (var item in val)
            {
                dr = dt.NewRow();
                dr["Description"] = item.Description;
                dr["Amount"] = item.Amount;
                dr["CreatedDate"] = Convert.ToDateTime(item.CreatedDate.ToString()).ToString("d");
                dr["CreatedBy"] = item.CreatedBy;
                dt.Rows.Add(dr);
            }
            return dt;
        }
        #endregion

        #region MainConsolidator
        public List<string> GetColumnNames()
        {
            var properties = (from t in typeof(BDOLF_NTC_Consolidator).GetProperties()
                              select t.Name).ToList();

            return properties;
        }

        //Get Currency Rate from GL Table
        public decimal GetCurrencyRate(string code)
        {
            var result = uow.ExchangeRateRepository.GetAll().Where(i => i.CurrencyCode == code).FirstOrDefault().CurrencyRate;
            return Convert.ToDecimal(result);
        }

        public bool BulkInsertConsoRecord(object[] objconsolidate)
        {
            var retVal = false;

            //  var conso = new BDOLF_NTC_Consolidator();



            uow.MainConsolidatorRepository.BulkInsertRecord(objconsolidate);
            //uow.SaveChanges();

            return retVal;
        }

        public static void InsertIntoMembers(DataTable dataTable)
        {
            using (var connection = new SqlConnection(@"data source=;persist security info=True;user id=;password=;initial catalog=;MultipleActiveResultSets=True;App=EntityFramework"))
            {
                SqlTransaction transaction = null;
                connection.Open();
                try
                {
                    transaction = connection.BeginTransaction();
                    using (var sqlBulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.TableLock, transaction))
                    {
                        //sqlBulkCopy.DestinationTableName = "Members";
                        //sqlBulkCopy.ColumnMappings.Add("Firstname", "Firstname");
                        //sqlBulkCopy.ColumnMappings.Add("Lastname", "Lastname");
                        //sqlBulkCopy.ColumnMappings.Add("DOB", "DOB");
                        //sqlBulkCopy.ColumnMappings.Add("Gender", "Gender");
                        //sqlBulkCopy.ColumnMappings.Add("Email", "Email");
                        //sqlBulkCopy.ColumnMappings.Add("Address1", "Address1");
                        //sqlBulkCopy.ColumnMappings.Add("Address2", "Address2");
                        //sqlBulkCopy.ColumnMappings.Add("Address3", "Address3");
                        //sqlBulkCopy.ColumnMappings.Add("Address4", "Address4");
                        //sqlBulkCopy.ColumnMappings.Add("Postcode", "Postcode");

                        //sqlBulkCopy.ColumnMappings.Add("MobileNumber", "MobileNumber");
                        //sqlBulkCopy.ColumnMappings.Add("TelephoneNumber", "TelephoneNumber");

                        //sqlBulkCopy.ColumnMappings.Add("Deleted", "Deleted");

                        //sqlBulkCopy.WriteToServer(dataTable);


                    }
                    transaction.Commit();
                }
                catch (Exception)
                {
                    transaction.Rollback();
                }

            }
        }
        #endregion

        #region FilePath Maintenance
        public DataTable GetAllPath()
        {
            var val = uow.FilePathRepository.GetAll().ToList();

            DataTable dt = new DataTable();
            dt.Columns.Add("PathID");
            dt.Columns.Add("ICBSFilePath");
            dt.Columns.Add("ICBSFileExtension");
            dt.Columns.Add("AAFFilePath");
            dt.Columns.Add("AAFFileExtension");
            dt.Columns.Add("FAMSFilePath");
            dt.Columns.Add("FAMSFileExtension");

            DataRow dr = null;
            var rowCount = 1;
            foreach (var item in val)
            {
                dr = dt.NewRow();
                dr["PathID"] = item.PathID;
                dr["ICBSFilePath"] = item.ICBSFilePath;
                dr["ICBSFileExtension"] = item.ICBSFileExtension;
                dr["AAFFilePath"] = item.AAFFilePath;
                dr["AAFFileExtension"] = item.AAFFileExtension;
                dr["FAMSFilePath"] = item.FAMSFilePath;
                dr["FAMSFileExtension"] = item.FAMSFileExtension;
                dt.Rows.Add(dr);
                rowCount++;
            }
            return dt;
        }

        //For File Path

        public int InsertFilePAth(string _icbs, string _icbsEXT, string _aaf, string _aafEXT, string _fams, string _famsEXT, string username, DateTime dateinserted)
        {
            var retVal = 0;

            var id = GetAllPath().Rows[0]["PathID"];

            try
            {
                var filePath = new BDOLF_PathMaintenance();

                //filePath.PathID = Convert.ToInt32(id);
                filePath.ICBSFilePath = _icbs;
                filePath.ICBSFileExtension = _icbsEXT;
                filePath.AAFFilePath = _aaf;
                filePath.AAFFileExtension = _aafEXT;
                filePath.FAMSFilePath = _fams;
                filePath.FAMSFileExtension = _famsEXT;
                filePath.UserName = username;
                filePath.DateInserted = DateTime.Now;

                if (id.ToString() == "")
                {
                    uow.FilePathRepository.Add(filePath);
                }
                else
                {
                    uow.FilePathRepository.Update(filePath);
                }

                uow.SaveChanges();

                retVal = 1;
            }
            catch (Exception ex)
            {
                retVal = 2;
            }

            return retVal;
        }
        #endregion

        //Get Record From Aging Inventory

        //public DataTable GetAAFData(DateTime dateparam)
        //{
        //    DataTable dtAaf = new DataTable();
        //    dtAaf.Columns.Add("AccountNo");
        //    dtAaf.Columns.Add("ClientName");
        //    dtAaf.Columns.Add("AO");
        //    dtAaf.Columns.Add("FacilityCode");
        //    dtAaf.Columns.Add("StatusPERSYSTEM");
        //    dtAaf.Columns.Add("ValueDate");
        //    dtAaf.Columns.Add("FirstDueDate");
        //    dtAaf.Columns.Add("MaturityDate");
        //    dtAaf.Columns.Add("SYSTEM");
        //    dtAaf.Columns.Add("AccountNo");
        //    dtAaf.Columns.Add("ClientName");
        //    dtAaf.Columns.Add("AO");
        //    dtAaf.Columns.Add("FacilityCode");
        //    dtAaf.Columns.Add("StatusPERSYSTEM");
        //    dtAaf.Columns.Add("ValueDate");
        //    dtAaf.Columns.Add("FirstDueDate");
        //    dtAaf.Columns.Add("MaturityDate");
        //    dtAaf.Columns.Add("TotalLoan");
        //    dtAaf.Columns.Add("OB");
        //    dtAaf.Columns.Add("MonthlyOB");
        //    dtAaf.Columns.Add("UDIBalance");
        //    dtAaf.Columns.Add("OrigERV");
        //    dtAaf.Columns.Add("PVRV");
        //    dtAaf.Columns.Add("OrigGD");
        //    dtAaf.Columns.Add("PVGD");
        //    dtAaf.Columns.Add("OriginalRate");
        //    dtAaf.Columns.Add("CurrentRate");
        //    dtAaf.Columns.Add("TermInmonths");
        //    dtAaf.Columns.Add("RemainingTermInMonths");
        //    dtAaf.Columns.Add("OriginalAmortizationAAF");
        //    dtAaf.Columns.Add("PaymentScheduleAmortizationAAF");
        //    dtAaf.Columns.Add("RepricedDate");
        //    dtAaf.Columns.Add("AAFICBSRateType");
        //    dtAaf.Columns.Add("RepricedAmortization");
        //    dtAaf.Columns.Add("PastDueDateITLDateExtractedPerAAFICBS");
        //    dtAaf.Columns.Add("PerFaMSAAFICBSIndustryCode");
        //    dtAaf.Columns.Add("IndustryHeader");
        //    dtAaf.Columns.Add("IndustryDetail");
        //    dtAaf.Columns.Add("Collateral");
        //    dtAaf.Columns.Add("PerFaMSAAFICBSAssetSizeInwords");
        //    dtAaf.Columns.Add("ICBSGLCODE");
        //    dtAaf.Columns.Add("ICBSGLName");
        //    dtAaf.Columns.Add("COSTCENTER");
        //    dtAaf.Columns.Add("BRANCHNAMEOFCOSTCENTERPERSYSTEM");
        //    dtAaf.Columns.Add("OriginatingBranchBooked");
        //    dtAaf.Columns.Add("NationalityPerICBS");
        //    dtAaf.Columns.Add("NextRateReviewDateExtractedPerFaMSAAFICBS");
        //    dtAaf.Columns.Add("TAXID");
        //    dtAaf.Columns.Add("CustomerTypeDescription");
        //    dtAaf.Columns.Add("RELCode");
        //    dtAaf.Columns.Add("REECode");
        //    dtAaf.Columns.Add("REEAddtlInfo");
        //    dtAaf.Columns.Add("AcctRef");
        //    dtAaf.Columns.Add("RPT");
        //    dtAaf.Columns.Add("ASSETCOST");
        //    dtAaf.Columns.Add("LeaseType");
        //    dtAaf.Columns.Add("ICBSCollateralCode");
        //    dtAaf.Columns.Add("AssetValue");
        //    dtAaf.Columns.Add("ApprovedAmount");
        //    dtAaf.Columns.Add("LastPrincipalPay");
        //    dtAaf.Columns.Add("PrincipalPayDate");
        //    dtAaf.Columns.Add("LastInterestPay");
        //    dtAaf.Columns.Add("LastInterestPayDate");
        //    dtAaf.Columns.Add("PreviousMonthsNPLTaggingByRisk");
        //    dtAaf.Columns.Add("SpecificRequiredProvisions");
        //    dtAaf.Columns.Add("GeneralRequiredProvisions");

        //    DataRow dr = null;

        //    #region Configuration
        //    string dbName = ConfigurationManager.AppSettings["AAFDBSource"];
        //    string dbServer = ConfigurationManager.AppSettings["AAFDBSource"];
        //    string dbDatabase = ConfigurationManager.AppSettings["AAFDBase"];
        //    string dbUserID = ConfigurationManager.AppSettings["AAFUserName"];
        //    string dbPassword = ConfigurationManager.AppSettings["AAFPassword"];
        //    string dbProviderName = ConfigurationManager.AppSettings["dbProviderName"];
        //    #endregion
        //    //string myconn = "Server=" + (dbServer) + ";Database=" + (dbDatabase) + ";User ID=" + Enc_Dec.Decrypt.Decryptor(dbUserID) + ";Password=" + Enc_Dec.Decrypt.Decryptor(dbPassword);
        //    string connstring = "Server=" + dbServer + ";Database=" + dbDatabase + ";User ID=" + dbUserID + ";Password=" + dbPassword;
        //    //Create the connection object
        //    using (SqlConnection conn = new SqlConnection(connstring))
        //    {
        //        // Open the SqlConnection.
        //        conn.Open();
        //        //Create the SQLCommand object
        //        using (SqlCommand command = new SqlCommand("dbo.BDOLFSP_AgingInventory", conn) { CommandType = CommandType.StoredProcedure })
        //        {
        //            //Pass the parameter values here
        //            command.Parameters.AddWithValue("@cutoffdate", dateparam);
        //            command.CommandTimeout = 0;
        //            using (SqlDataReader reader = command.ExecuteReader())
        //            {
        //                //read the data
        //                while (reader.Read())
        //                {
        //                    dr = dtAaf.NewRow();

        //                    dr["AccountNo"] = reader[""].ToString();
        //                    dr["ClientName"] = reader[""].ToString();
        //                    dr["AO"] = reader[""].ToString();
        //                    dr["FacilityCode"] = reader[""].ToString();
        //                    dr["StatusPERSYSTEM"] = reader[""].ToString();
        //                    dr["ValueDate"] = reader[""].ToString();
        //                    dr["FirstDueDate"] = reader[""].ToString();
        //                    dr["MaturityDate"] = reader[""].ToString();
        //                    dr["SYSTEM"] = reader[""].ToString();
        //                    dr["AccountNo"] = reader[""].ToString();
        //                    dr["ClientName"] = reader[""].ToString();
        //                    dr["AO"] = reader[""].ToString();
        //                    dr["FacilityCode"] = reader[""].ToString();
        //                    dr["StatusPERSYSTEM"] = reader[""].ToString();
        //                    dr["ValueDate"] = reader[""].ToString();
        //                    dr["FirstDueDate"] = reader[""].ToString();
        //                    dr["MaturityDate"] = reader[""].ToString();
        //                    dr["TotalLoan"] = reader[""].ToString();
        //                    dr["OB"] = reader[""].ToString();
        //                    dr["MonthlyOB"] = reader[""].ToString();
        //                    dr["UDIBalance"] = reader[""].ToString();
        //                    dr["OrigERV"] = reader[""].ToString();
        //                    dr["PVRV"] = reader[""].ToString();
        //                    dr["OrigGD"] = reader[""].ToString();
        //                    dr["PVGD"] = reader[""].ToString();
        //                    dr["OriginalRate"] = reader[""].ToString();
        //                    dr["CurrentRate"] = reader[""].ToString();
        //                    dr["TermInmonths"] = reader[""].ToString();
        //                    dr["RemainingTermInMonths"] = reader[""].ToString();
        //                    dr["OriginalAmortizationAAF"] = reader[""].ToString();
        //                    dr["PaymentScheduleAmortizationAAF"] = reader[""].ToString();
        //                    dr["RepricedDate"] = reader[""].ToString();
        //                    dr["AAFICBSRateType"] = reader[""].ToString();
        //                    dr["RepricedAmortization"] = reader[""].ToString();
        //                    dr["PastDueDateITLDateExtractedPerAAFICBS"] = reader[""].ToString();
        //                    dr["PerFaMSAAFICBSIndustryCode"] = reader[""].ToString();
        //                    dr["IndustryHeader"] = reader[""].ToString();
        //                    dr["IndustryDetail"] = reader[""].ToString();
        //                    dr["Collateral"] = reader[""].ToString();
        //                    dr["PerFaMSAAFICBSAssetSizeInwords"] = reader[""].ToString();
        //                    dr["ICBSGLCODE"] = reader[""].ToString();
        //                    dr["ICBSGLName"] = reader[""].ToString();
        //                    dr["COSTCENTER"] = reader[""].ToString();
        //                    dr["BRANCHNAMEOFCOSTCENTERPERSYSTEM"] = reader[""].ToString();
        //                    dr["OriginatingBranchBooked"] = reader[""].ToString();
        //                    dr["NationalityPerICBS"] = reader[""].ToString();
        //                    dr["NextRateReviewDateExtractedPerFaMSAAFICBS"] = reader[""].ToString();
        //                    dr["TAXID"] = reader[""].ToString();
        //                    dr["CustomerTypeDescription"] = reader[""].ToString();
        //                    dr["RELCode"] = reader[""].ToString();
        //                    dr["REECode"] = reader[""].ToString();
        //                    dr["REEAddtlInfo"] = reader[""].ToString();
        //                    dr["AcctRef"] = reader[""].ToString();
        //                    dr["RPT"] = reader[""].ToString();
        //                    dr["ASSETCOST"] = reader[""].ToString();
        //                    dr["LeaseType"] = reader[""].ToString();
        //                    dr["ICBSCollateralCode"] = reader[""].ToString();
        //                    dr["AssetValue"] = reader[""].ToString();
        //                    dr["ApprovedAmount"] = reader[""].ToString();
        //                    dr["LastPrincipalPay"] = reader[""].ToString();
        //                    dr["PrincipalPayDate"] = reader[""].ToString();
        //                    dr["LastInterestPay"] = reader[""].ToString();
        //                    dr["LastInterestPayDate"] = reader[""].ToString();
        //                    dr["PreviousMonthsNPLTaggingByRisk"] = reader[""].ToString();
        //                    dr["SpecificRequiredProvisions"] = reader[""].ToString();
        //                    dr["GeneralRequiredProvisions"] = reader[""].ToString();

        //                }
        //            }
        //        }

        //        conn.Close();
        //    }

        //    return dtAaf;




















        //    //var context = new NTCEntities();

        //    //DataSet ds = new DataSet();
        //    //using (SqlConnection connection = new SqlConnection(context.Database.Connection.ConnectionString))
        //    //{
        //    //    try
        //    //    {
        //    //        using (SqlCommand cmd = new SqlCommand("dbo.BDOLFSP_AgingInventory", connection))
        //    //        {
        //    //            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
        //    //            adapter.SelectCommand.CommandType = CommandType.StoredProcedure;
        //    //            adapter.SelectCommand.Parameters.Add(new SqlParameter("@cutoffdate", dateparam));
        //    //            adapter.Fill(ds);
        //    //        }
        //    //    }
        //    //    catch (Exception ex)
        //    //    {

        //    //        throw;
        //    //    }
        //    //}
        //    //return ds.Tables[0];
        //}

    }
}
