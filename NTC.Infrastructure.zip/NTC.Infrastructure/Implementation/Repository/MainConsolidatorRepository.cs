﻿using NTC.Core;
using NTC.Infrastructure.Implementation.Interfaces;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC.Infrastructure.Implementation.Repository
{
    public class MainConsolidatorRepository : IRepository<BDOLF_NTC_Consolidator>
    {
        private NTCEntities entities = null;
        protected DbSet DbSet;
        public MainConsolidatorRepository(NTCEntities _entities)
        {
            entities = _entities;
            DbSet = _entities.Set<BDOLF_NTC_Consolidator>();
        }

        void IRepository<BDOLF_NTC_Consolidator>.Add(BDOLF_NTC_Consolidator entity)
        {
            DbSet.Add(entity);
        }

        void IRepository<BDOLF_NTC_Consolidator>.Update(BDOLF_NTC_Consolidator entity)
        {
            DbSet.Attach(entity);
        }

        void IRepository<BDOLF_NTC_Consolidator>.Delete(BDOLF_NTC_Consolidator entity)
        {
            DbSet.Remove(entity);
        }

        IEnumerable<BDOLF_NTC_Consolidator> IRepository<BDOLF_NTC_Consolidator>.GetAll()
        {
            return DbSet as IEnumerable<BDOLF_NTC_Consolidator>;
        }


        BDOLF_NTC_Consolidator IRepository<BDOLF_NTC_Consolidator>.Find(int id)
        {

            return DbSet.Find(id) as BDOLF_NTC_Consolidator;

        }

        BDOLF_NTC_Consolidator IRepository<BDOLF_NTC_Consolidator>.FindByCode(string code)
        {
            return DbSet.Find(code) as BDOLF_NTC_Consolidator;
        }

        public bool isExists(string code)
        {
            var data = DbSet.Find(code);// as BDOLF_ExchangeRate;

            return data != null ? true : false;
        }
        public List<BDOLF_NTC_Consolidator> GetAllColumnName()
        {
            throw new NotImplementedException();
        }

        //public IEnumerable<BDOLF_NTC_Consolidator> ExecWithStoreProcedure(string query, params object[] parameters)
        //{
        //    throw new NotImplementedException();
        //}

        public void BulkInsertRecord(object[] data)
        {
            var icbsData = (DataTable)data[0];
            var aafData = (DataTable)data[1];
            var famsData = (ArrayList)data[2];
            var sdf = new BDOLF_NTC_Consolidator();

            string connectionString = (new NTCEntities()).Database.Connection.ConnectionString;
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (var transaction = connection.BeginTransaction())
                {
                    try
                    {
                        using (var sqlBulkCopy = new SqlBulkCopy(connection, SqlBulkCopyOptions.TableLock, transaction))
                        {
                            entities.Configuration.AutoDetectChangesEnabled = false;
                            entities.Configuration.ValidateOnSaveEnabled = false;

                            // my DataTable column names match my SQL Column names, so I simply made this loop. However if your column names don't match, just pass in which datatable name matches the SQL column name in Column Mappings
                            foreach (DataColumn col in icbsData.Columns)
                            {
                                sqlBulkCopy.ColumnMappings.Add(col.ColumnName, col.ColumnName);
                            }

                            sqlBulkCopy.BulkCopyTimeout = 0;
                            sqlBulkCopy.DestinationTableName = "BDOLF_NTC_Consolidator";
                            sqlBulkCopy.WriteToServer(icbsData);


                            #region MyRegion

                            sqlBulkCopy.DestinationTableName = "BDOLF_NTC_Consolidator";

                            sqlBulkCopy.ColumnMappings.Add("TransID", "TransID");
                            sqlBulkCopy.ColumnMappings.Add("TranNo", "TranNo");
                            sqlBulkCopy.ColumnMappings.Add("RawFiles", "RawFiles");
                            sqlBulkCopy.ColumnMappings.Add("isConsolidated", "isConsolidated");
                            sqlBulkCopy.ColumnMappings.Add("isDeleted", "isDeleted");
                            sqlBulkCopy.ColumnMappings.Add("UserName", "UserName");
                            sqlBulkCopy.ColumnMappings.Add("TransDate", "TransDate");
                            sqlBulkCopy.ColumnMappings.Add("RecordDate", "RecordDate");
                            sqlBulkCopy.ColumnMappings.Add("SYSTEM", "SYSTEM");
                            sqlBulkCopy.ColumnMappings.Add("AccountNo", "AccountNo");
                            sqlBulkCopy.ColumnMappings.Add("ClientName", "ClientName");
                            sqlBulkCopy.ColumnMappings.Add("AO", "AO");
                            sqlBulkCopy.ColumnMappings.Add("FacilityCode", "FacilityCode");
                            sqlBulkCopy.ColumnMappings.Add("StatusPerSystem", "StatusPerSystem");
                            sqlBulkCopy.ColumnMappings.Add("ValueDate", "ValueDate");
                            sqlBulkCopy.ColumnMappings.Add("FirstDueDate", "FirstDueDate");
                            sqlBulkCopy.ColumnMappings.Add("MaturityDate", "MaturityDate");
                            sqlBulkCopy.ColumnMappings.Add("TotalLoan", "TotalLoan");
                            sqlBulkCopy.ColumnMappings.Add("OB", "OB");
                            sqlBulkCopy.ColumnMappings.Add("MonthlyOB", "MonthlyOB");
                            sqlBulkCopy.ColumnMappings.Add("UDIBalance", "UDIBalance");
                            sqlBulkCopy.ColumnMappings.Add("ClientsEquity", "ClientsEquity");
                            sqlBulkCopy.ColumnMappings.Add("AccruedInterestReceivable", "AccruedInterestReceivable");
                            sqlBulkCopy.ColumnMappings.Add("OrigERV", "OrigERV");
                            sqlBulkCopy.ColumnMappings.Add("PVRV", "PVRV");
                            sqlBulkCopy.ColumnMappings.Add("OrigGD", "OrigGD");
                            sqlBulkCopy.ColumnMappings.Add("PVGD", "PVGD");
                            sqlBulkCopy.ColumnMappings.Add("TotalLoanPortfolio", "TotalLoanPortfolio");
                            sqlBulkCopy.ColumnMappings.Add("NTC", "NTC");
                            sqlBulkCopy.ColumnMappings.Add("OriginalRate", "OriginalRate");
                            sqlBulkCopy.ColumnMappings.Add("CurrentRate", "CurrentRate");
                            sqlBulkCopy.ColumnMappings.Add("TermInMonths", "TermInMonths");
                            sqlBulkCopy.ColumnMappings.Add("RemainingTermInMonths", "RemainingTermInMonths");
                            sqlBulkCopy.ColumnMappings.Add("OriginalAmortizationAAF", "OriginalAmortizationAAF");
                            sqlBulkCopy.ColumnMappings.Add("PaymentScheduleAmortizationAAF", "PaymentScheduleAmortizationAAF");
                            sqlBulkCopy.ColumnMappings.Add("RepricedDate", "RepricedDate");
                            sqlBulkCopy.ColumnMappings.Add("AAFICBSRateType", "AAFICBSRateType");
                            sqlBulkCopy.ColumnMappings.Add("RepricedAmortization", "RepricedAmortization");
                            sqlBulkCopy.ColumnMappings.Add("PastDueDateITLDateExtractedPerAAFICBS", "PastDueDateITLDateExtractedPerAAFICBS");
                            sqlBulkCopy.ColumnMappings.Add("PerFaMSAAFICBSIndustryCode", "PerFaMSAAFICBSIndustryCode");
                            sqlBulkCopy.ColumnMappings.Add("IndustryHeader", "IndustryHeader");
                            sqlBulkCopy.ColumnMappings.Add("IndustryDetail", "IndustryDetail");
                            sqlBulkCopy.ColumnMappings.Add("Collateral", "Collateral");
                            sqlBulkCopy.ColumnMappings.Add("PerFaMSAAFICBSAssetSize", "PerFaMSAAFICBSAssetSize");
                            sqlBulkCopy.ColumnMappings.Add("PerFaMSAAFICBSAssetSizeInWords", "PerFaMSAAFICBSAssetSizeInWords");
                            sqlBulkCopy.ColumnMappings.Add("ICBSGLCode", "ICBSGLCode");
                            sqlBulkCopy.ColumnMappings.Add("ICBSGLName", "ICBSGLName");
                            sqlBulkCopy.ColumnMappings.Add("CostCenter", "CostCenter");
                            sqlBulkCopy.ColumnMappings.Add("BranchNameOfCostCenterPerSystem", "BranchNameOfCostCenterPerSystem");
                            sqlBulkCopy.ColumnMappings.Add("StatusPerGL", "StatusPerGL");
                            sqlBulkCopy.ColumnMappings.Add("OriginatingBranchBooked", "OriginatingBranchBooked");
                            sqlBulkCopy.ColumnMappings.Add("NationalityPerICBS", "NationalityPerICBS");
                            sqlBulkCopy.ColumnMappings.Add("NextRateReviewDateExtractedPerFaMSAAFICBS", "NextRateReviewDateExtractedPerFaMSAAFICBS");
                            sqlBulkCopy.ColumnMappings.Add("TaxID", "TaxID");
                            sqlBulkCopy.ColumnMappings.Add("LoanPurposeCode", "LoanPurposeCode");
                            sqlBulkCopy.ColumnMappings.Add("MaturityTypeCode", "MaturityTypeCode");
                            sqlBulkCopy.ColumnMappings.Add("BankRelationship", "BankRelationship");
                            sqlBulkCopy.ColumnMappings.Add("SyndicatedLoanInd", "SyndicatedLoanInd");
                            sqlBulkCopy.ColumnMappings.Add("CustomerTypeDescription", "CustomerTypeDescription");
                            sqlBulkCopy.ColumnMappings.Add("RELCode", "RELCode");
                            sqlBulkCopy.ColumnMappings.Add("REECode", "REECode");
                            sqlBulkCopy.ColumnMappings.Add("REEAddtlInfo", "REEAddtlInfo");
                            sqlBulkCopy.ColumnMappings.Add("AcctRef", "AcctRef");
                            sqlBulkCopy.ColumnMappings.Add("RPT", "RPT");
                            sqlBulkCopy.ColumnMappings.Add("ASSETCOST", "ASSETCOST");
                            sqlBulkCopy.ColumnMappings.Add("LeaseType", "LeaseType");
                            sqlBulkCopy.ColumnMappings.Add("Provisioning", "Provisioning");
                            sqlBulkCopy.ColumnMappings.Add("Matrix", "Matrix");
                            sqlBulkCopy.ColumnMappings.Add("Remarks", "Remarks");
                            sqlBulkCopy.ColumnMappings.Add("ICBSCollateralCode", "ICBSCollateralCode");
                            sqlBulkCopy.ColumnMappings.Add("AssetValue", "AssetValue");
                            sqlBulkCopy.ColumnMappings.Add("ApprovedAmount", "ApprovedAmount");
                            sqlBulkCopy.ColumnMappings.Add("CPNumber", "CPNumber");
                            sqlBulkCopy.ColumnMappings.Add("LastPrincipalPay", "LastPrincipalPay");
                            sqlBulkCopy.ColumnMappings.Add("PrincipalPayDate", "PrincipalPayDate");
                            sqlBulkCopy.ColumnMappings.Add("LastInterestPay", "LastInterestPay");
                            sqlBulkCopy.ColumnMappings.Add("LastInterestPayDate", "LastInterestPayDate");
                            sqlBulkCopy.ColumnMappings.Add("PreviousMonthsNPLTaggingByRisk", "PreviousMonthsNPLTaggingByRisk");
                            sqlBulkCopy.ColumnMappings.Add("SpecificRequiredProvisions", "SpecificRequiredProvisions");
                            sqlBulkCopy.ColumnMappings.Add("GeneralRequiredProvisions", "GeneralRequiredProvisions");
                            sqlBulkCopy.ColumnMappings.Add("Reason", "Reason");
                            #endregion

                            //foreach (DataColumn column in aafData.Columns)
                            //{
                            //    sqlBulkCopy.ColumnMappings.Add(column.ColumnName, column.ColumnName);
                            //}

                            sqlBulkCopy.WriteToServer(icbsData);
                            sqlBulkCopy.WriteToServer(aafData);
                        }
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        transaction.Rollback();
                    }
                    finally
                    {
                        transaction.Dispose();
                        connection.Close();
                    }
                }
            }
        }

    }
}
