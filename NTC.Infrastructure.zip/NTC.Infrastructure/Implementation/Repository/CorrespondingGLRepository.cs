﻿using System.Linq;
using NTC.Core;
using System.Data.Entity;
using System;
using NTC.Infrastructure.Implementation.Interfaces;
using System.Collections.Generic;

namespace NTC.Infrastructure.Implementation.Repository
{
    public class CorrespondingGLRepository : IRepository<BDOLF_CorrepondingGL>
    {
        private NTCEntities entities = null;
        protected DbSet DbSet;
        public CorrespondingGLRepository(NTCEntities _entities)
        {
            entities = _entities;
            DbSet = _entities.Set<BDOLF_CorrepondingGL>();
        }

        void IRepository<BDOLF_CorrepondingGL>.Add(BDOLF_CorrepondingGL entity)
        {
            DbSet.Add(entity);
        }

        void IRepository<BDOLF_CorrepondingGL>.Update(BDOLF_CorrepondingGL entity)
        {
            DbSet.Attach(entity);
            
        }

        void IRepository<BDOLF_CorrepondingGL>.Delete(BDOLF_CorrepondingGL entity)
        {
            DbSet.Remove(entity);
        }

        IEnumerable<BDOLF_CorrepondingGL> IRepository<BDOLF_CorrepondingGL>.GetAll()
        {
            return DbSet as IEnumerable<BDOLF_CorrepondingGL>;
        }


        BDOLF_CorrepondingGL IRepository<BDOLF_CorrepondingGL>.Find(int id)
        {

            return DbSet.Find(id) as BDOLF_CorrepondingGL;

        }

        BDOLF_CorrepondingGL IRepository<BDOLF_CorrepondingGL>.FindByCode(string code)
        {
            return DbSet.Find(code) as BDOLF_CorrepondingGL;
        }

        public bool isExists(string code)
        {
            var data = DbSet.Find(code);// as BDOLF_CorrepondingGL;

            return data != null ? true : false;
        }

        public List<BDOLF_CorrepondingGL> GetAllColumnName()
        {
            throw new NotImplementedException();
        }

        public void BulkInsertRecord(object[] data)
        {
            throw new NotImplementedException();
        }
    }
}
