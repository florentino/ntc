﻿using NTC.Core;
using NTC.Infrastructure.Implementation.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC.Infrastructure.Implementation.Repository
{
    public class FilePathRepository : IRepository<BDOLF_PathMaintenance>
    {
        private NTCEntities entities = null;
        protected DbSet DbSet;
        public FilePathRepository(NTCEntities _entities)
        {
            entities = _entities;
            DbSet = _entities.Set<BDOLF_PathMaintenance>();
        }


        public void Add(BDOLF_PathMaintenance entity)
        {
            DbSet.Add(entity);
        }

        public void BulkInsertRecord(object[] data)
        {
            throw new NotImplementedException();
        }

        public void Delete(BDOLF_PathMaintenance entity)
        {
            DbSet.Remove(entity);
        }

        public BDOLF_PathMaintenance Find(int id)
        {
            throw new NotImplementedException();
        }

        public BDOLF_PathMaintenance FindByCode(string code)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<BDOLF_PathMaintenance> GetAll()
        {
            return DbSet as IEnumerable<BDOLF_PathMaintenance>;
        }

        public List<BDOLF_PathMaintenance> GetAllColumnName()
        {
            throw new NotImplementedException();
        }

        public bool isExists(string code)
        {
            throw new NotImplementedException();
        }

        public void Update(BDOLF_PathMaintenance entity)
        {
            entities.Entry(entity).State = EntityState.Modified;
            DbSet.Attach(entity);
        }
    }
}
