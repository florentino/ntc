﻿using NTC.Core;
using NTC.Infrastructure.Implementation.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC.Infrastructure.Implementation.Repository
{
    public class QualifyingCapitalRepository : IRepository<BDOLF_QualifyingCapital>
    {
        private NTCEntities entities = null;
        protected DbSet DbSet;
        public QualifyingCapitalRepository(NTCEntities _entities)
        {
            entities = _entities;
            DbSet = _entities.Set<BDOLF_QualifyingCapital>();
        }

        void IRepository<BDOLF_QualifyingCapital>.Add(BDOLF_QualifyingCapital entity)
        {
            DbSet.Add(entity);
        }

        void IRepository<BDOLF_QualifyingCapital>.Update(BDOLF_QualifyingCapital entity)
        {
            DbSet.Attach(entity);
        }

        void IRepository<BDOLF_QualifyingCapital>.Delete(BDOLF_QualifyingCapital entity)
        {
            DbSet.Remove(entity);
        }

        IEnumerable<BDOLF_QualifyingCapital> IRepository<BDOLF_QualifyingCapital>.GetAll()
        {
            return DbSet as IEnumerable<BDOLF_QualifyingCapital>;
        }

        BDOLF_QualifyingCapital IRepository<BDOLF_QualifyingCapital>.Find(int id)
        {
            return DbSet.Find(id) as BDOLF_QualifyingCapital;
        }

        BDOLF_QualifyingCapital IRepository<BDOLF_QualifyingCapital>.FindByCode(string code)
        {
            return DbSet.Find(code) as BDOLF_QualifyingCapital;
        }

        public bool isExists(string code)
        {
            var data = DbSet.Find(code);// as BDOLF_QualifyingCapital;

            return data != null ? true : false;
        }
        public List<BDOLF_QualifyingCapital> GetAllColumnName()
        {
            throw new NotImplementedException();
        }

        public void BulkInsertRecord(object[] data)
        {
            throw new NotImplementedException();
        }
    }
}
