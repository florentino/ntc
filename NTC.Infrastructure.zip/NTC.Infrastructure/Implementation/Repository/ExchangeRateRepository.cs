﻿using NTC.Core;
using NTC.Infrastructure.Implementation.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC.Infrastructure.Implementation.Repository
{
    public class ExchangeRateRepository : IRepository<BDOLF_ExchangeRate>
    {
        private NTCEntities entities = null;
        protected DbSet DbSet;
        public ExchangeRateRepository(NTCEntities _entities)
        {
            entities = _entities;
            DbSet = _entities.Set<BDOLF_ExchangeRate>();
        }

        void IRepository<BDOLF_ExchangeRate>.Add(BDOLF_ExchangeRate entity)
        {
            DbSet.Add(entity);
        }

        void IRepository<BDOLF_ExchangeRate>.Update(BDOLF_ExchangeRate entity)
        {
            DbSet.Attach(entity);
        }

        void IRepository<BDOLF_ExchangeRate>.Delete(BDOLF_ExchangeRate entity)
        {
            DbSet.Remove(entity);
        }

        IEnumerable<BDOLF_ExchangeRate> IRepository<BDOLF_ExchangeRate>.GetAll()
        {
            return DbSet as IEnumerable<BDOLF_ExchangeRate>;
        }


        BDOLF_ExchangeRate IRepository<BDOLF_ExchangeRate>.Find(int id)
        {

            return DbSet.Find(id) as BDOLF_ExchangeRate;

        }

        BDOLF_ExchangeRate IRepository<BDOLF_ExchangeRate>.FindByCode(string code)
        {
            return DbSet.Find(code) as BDOLF_ExchangeRate;
        }

        public bool isExists(string code)
        {
            var data = DbSet.Find(code);// as BDOLF_ExchangeRate;

            return data != null ? true : false;
        }

        public List<BDOLF_ExchangeRate> GetAllColumnName()
        {
            throw new NotImplementedException();
        }

        public void BulkInsertRecord(object[] data)
        {
            throw new NotImplementedException();
        }
    }
}
