﻿
using System;
using NTC.Core;
using NTC.Infrastructure.Implementation.Repository;
using NTC.Infrastructure.Implementation.Interfaces;

namespace NTC.Infrastructure.Implementation.UnitOfWork
{
    public class UnitOfWork : IDisposable
    {
        private NTCEntities entities = null;
        public UnitOfWork()
        {
            entities = new NTCEntities();
        }

        #region Corresponding GL
        //For Corresponding GL
        // Add all the repository handles here
        IRepository<BDOLF_CorrepondingGL> correspondingGL_Repository = null;

        // Add all the repository getters here
        public IRepository<BDOLF_CorrepondingGL> CorrespondingGLRepository
        {
            get
            {
                if (correspondingGL_Repository == null)
                {
                    correspondingGL_Repository = new CorrespondingGLRepository(entities);
                }
                return correspondingGL_Repository;
            }
        }
        #endregion

        #region Exchange eRate
        //For ExchangeRate
        // Add all the repository handles here
        IRepository<BDOLF_ExchangeRate> ExchangeRate_Repository = null;

        // Add all the repository getters here
        public IRepository<BDOLF_ExchangeRate> ExchangeRateRepository
        {
            get
            {
                if (ExchangeRate_Repository == null)
                {
                    ExchangeRate_Repository = new ExchangeRateRepository(entities);
                }
                return ExchangeRate_Repository;
            }
        }

        #endregion

        #region Qualifying Capital
        //For ExchangeRate
        // Add all the repository handles here
        IRepository<BDOLF_QualifyingCapital> QualifyingCapital_Repository = null;

        // Add all the repository getters here
        public IRepository<BDOLF_QualifyingCapital> QualifyingCapitalRepository
        {
            get
            {
                if (QualifyingCapital_Repository == null)
                {
                    QualifyingCapital_Repository = new QualifyingCapitalRepository(entities);
                }
                return QualifyingCapital_Repository;
            }
        }

        #endregion

        #region Main Consolidator
        //For  Main Consolidator
        // Add all the repository handles here
        IRepository<BDOLF_NTC_Consolidator> MainConsolidator_Repository = null;

        // Add all the repository getters here
        public IRepository<BDOLF_NTC_Consolidator> MainConsolidatorRepository
        {
            get
            {
                if (MainConsolidator_Repository == null)
                {
                    MainConsolidator_Repository = new MainConsolidatorRepository(entities);
                }
                return MainConsolidator_Repository;
            }
        }
        #endregion

        #region File Path Maintenance
       
        // Add all the repository handles here
        IRepository<BDOLF_PathMaintenance> filePath_Repository = null;

        // Add all the repository getters here
        public IRepository<BDOLF_PathMaintenance> FilePathRepository
        {
            get
            {
                if (filePath_Repository == null)
                {
                    filePath_Repository = new FilePathRepository(entities);
                }
                return filePath_Repository;
            }
        }
        #endregion

        public void SaveChanges()
        {
            entities.SaveChanges();
        }

        #region disposed
        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    entities.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
