﻿using System.Collections.Generic;
using System.Linq;

namespace NTC.Infrastructure.Implementation.Interfaces
{
    public interface IRepository<T> where T : class
    {
      
        void Add(T entity);

        void Update(T entity);

        void Delete(T entity);

        IEnumerable<T> GetAll();
        T Find(int id);

        T FindByCode(string code);

        bool isExists(string code);

        List<T> GetAllColumnName();

        void BulkInsertRecord(object[] data);
        //List<T> ExecWithStoreProcedure(string query, params object[] parameters)
       
    }
}
