﻿using System;

namespace NTC.Infrastructure.Implementation.Interfaces
{
    public interface IUnitOfWork : IDisposable
    {
        void SaveChanges();
    }
}
