﻿using MetroFramework;
using NTC_Consolidator.NTC_View;
using System;
using System.Configuration;
using System.Data.Entity.Core.EntityClient;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Windows.Forms;

namespace NTC_Consolidator
{
    static class Program
    {
        public static string Role = String.Empty;
        public static string UserName = String.Empty;
        public static string Password = String.Empty;

        public static string ICBSPath = String.Empty;
        public static string AAFUsername = String.Empty;
        public static string AAFPassword = String.Empty;
        public static string AAFDbServer = String.Empty;
        public static string AAFDBSource = String.Empty;

        public static string FAMSUsername = String.Empty;
        public static string FAMSPassword = String.Empty;
        public static string FAMSDbServer = String.Empty;
        public static string FAMSDBSource = String.Empty;
        public static string ntc_connectionname = "NTC_Context_Entities";

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            //Role = _role;
            //UserName = _username;
            if (IsApplicationAlreadyRunning() == true)
            {
                MessageBox.Show("NTC Consolidator is already running", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                //MetroMessageBox.Show(this, "\r\nNTC Consolidator is already running", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                //ModifyDataBaseConnection(_providerbname, _servername, _dbname, _userid, _password, ntc_connectionname);

                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new frmConsolidator());
            }
        }

        static bool IsApplicationAlreadyRunning()
        {
            string proc = Process.GetCurrentProcess().ProcessName;
            Process[] processes = Process.GetProcessesByName(proc);
            return processes.Length > 1 ? true : false;
        }

        private static void ModifyDataBaseConnection(string _providerbname, string _servername, string _dbname, string _userid, string _password, string ntc_connectionname)
        {
            // < add name = "NTC_Context_Entities" connectionString = "metadata=res://*/Data.NTC_Model.csdl|res://*/Data.NTC_Model.ssdl|res://*/Data.NTC_Model.msl;provider=System.Data.SqlClient;provider connection string=&quot;data source=bdowldb10v;initial catalog=tmpNTC;user id=d_aaf_test2;password=password;MultipleActiveResultSets=True;App=EntityFramework&quot;" providerName = "System.Data.EntityClient" />
            // Specify the provider name, server and database.
            string providerName = _providerbname;// "System.Data.SqlClient";
            string serverName = _servername;
            string databaseName = _dbname;
            string Metadata = @"res://*/Data.NTC_Model.csdl|res://*/Data.NTC_Model.ssdl|res://*/Data.NTC_Model.msl";
            string userId = _userid;
            string password = _password;

            // Initialize the connection string builder for the
            // underlying provider.
            SqlConnectionStringBuilder sqlBuilder = new SqlConnectionStringBuilder();

            // Set the properties for the data source.
            sqlBuilder.DataSource = serverName;
            sqlBuilder.InitialCatalog = databaseName;
            sqlBuilder.IntegratedSecurity = true;
            sqlBuilder.UserID = userId;
            sqlBuilder.Password = password;

            // Build the SqlConnection connection string.
            string providerString = sqlBuilder.ToString();

            // Initialize the EntityConnectionStringBuilder.
            EntityConnectionStringBuilder entityBuilder = new EntityConnectionStringBuilder();

            //Set the provider name.
            entityBuilder.Provider = providerName;

            // Set the provider-specific connection string.
            entityBuilder.ProviderConnectionString = providerString;

            // Set the Metadata location.
            entityBuilder.Metadata = Metadata;

            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            //config.ConnectionStrings.ConnectionStrings["NTC_Context_Entities"].ConnectionString = entityBuilder.ToString();
            config.ConnectionStrings.ConnectionStrings[ntc_connectionname].ConnectionString = entityBuilder.ToString();
            config.Save(ConfigurationSaveMode.Modified, true);
            ConfigurationManager.RefreshSection("connectionStrings");

            //using (EntityConnection conn = new EntityConnection(entityBuilder.ToString()))
            //{
            //    conn.Open();
            //    MessageBox.Show("Just testing the connection.");
            //    conn.Close();
            //}
        }
    }
}
