﻿using MetroFramework;
using Microsoft.Reporting.WinForms;
using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Core.Repository;
using NTC_Consolidator.Data;
using NTC_Consolidator.Helper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmReportViewer : MetroFramework.Forms.MetroForm
    {
        private ICorrespondingGLRepository correspondingGLRepository;
        private IConsolidator consolidatorRepository;
        private IFilePathRepository filePathRepository;
        private IExchangeRate exchangeRate;

        List<ReportParameter> parameters = new List<ReportParameter>();

        Array iResult;

        double totalOB = 0.0;
        double totalGMYBal = 0.0;

        double totalUDIBal = 0.0;
        double totalGMYBALUDI = 0.0;

        double totalPVRV = 0.0;
        double totalGMYBALPVRV = 0.0;

        double totalPVGD = 0.0;
        double totalGMYBALPVGD = 0.0;

        double totalGMYACCRUEDINTERESTRECEIVABLE = 0.0;
        double totalACCRUEDINTERESTRECEIVABLE = 0.0;

        double totalGMYCLIENTSEQUITY = 0.0;
        double totalCLIENTSEQUITY = 0.0;

        double ntcGrandTotalGYMBal = 0.0;
        double ntcGrandTotalSum = 0.0;
        double ntcGrandTotalDiff = 0.0;

        double totalDiffOB = 0.0;
        double totalDiffUDI = 0.0;
        double totalDiffPVRV = 0.0;
        double totalDiffPVGD = 0.0;
        double totalDiffACCR = 0.0;
        double totalDiffEQ = 0.0;


        DataTable dtSource = new DataTable();
        DataTable dtexceptionalReport;
        DataTable dtSumOfOB;
        DataTable dtSumOfUDIBalance;
        DataTable dtSumOfPVRV;
        DataTable dtSumOfPVGD;
        DataTable dtSumOfACCRUEDINTERESTRECEIVABLE;
        DataTable dtSumOfCLIENTEQUITY;

        private static frmReportViewer frmrptviewer = null;
        private string ExportFilename = "";
        private string rptDataSetName = "";
        private string filename = "";
        private string fileDestination = "";
        private string[] rptDataSetNameForSummary = new string[6];

        private string rdlcFile = "";
        private string sheetname = "";
        private string pathfile = "";
        bool IsBusy = false;
        private BackgroundWorker summaryWorker;
        private BackgroundWorker summaryExportWorker;

        public static frmReportViewer Instance()
        {
            if (frmrptviewer == null)
            {
                frmrptviewer = new frmReportViewer();
            }
            return frmrptviewer;
        }

        public frmReportViewer()
        {
            InitializeComponent();
            this.consolidatorRepository = new ConsolidatorRepository(new NTC_Context_Entities());
            this.filePathRepository = new FilePathRepository(new NTC_Context_Entities());
            this.exchangeRate = new ExchangeRateRepository(new NTC_Context_Entities());
            this.correspondingGLRepository = new CorrespondingGLRepository(new NTC_Context_Entities());

            pnlWaitInfo.Location = new Point(this.ClientSize.Width / 2 - pnlWaitInfo.Size.Width / 2, this.ClientSize.Height / 2 - pnlWaitInfo.Size.Height / 2);
            pnlWaitInfo.Visible = false;
        }

        private void frmReportViewer_Load(object sender, EventArgs e)
        {
            this.reportViewer1.RefreshReport();
            var firstDayOfMonth = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
            cmbDateFrom.Text = firstDayOfMonth.ToShortDateString();
            btnExecute.Enabled = false;
            lblBusy.Text = "";
            btnExport.Enabled = false;
        }

        // public void LoadDataToRDLC(string rptDataSetName, string filename, DataTable dtSource, string fileDestination, string fileFormat, string rdlcFile, string sheetname)
        public void LoadDataToRDLC(string rptDataSetName, DataTable dtSource, string rdlcFile, string sheetname, List<ReportParameter> rParams)
        {
            this.reportViewer1.LocalReport.DataSources.Clear();

            pathfile = "NTC_Consolidator.Report." + rdlcFile;

            ReportDataSource dSource = new ReportDataSource();
            dSource.Name = rptDataSetName;
            dSource.Value = dtSource;

            this.reportViewer1.LocalReport.DisplayName = sheetname;
            this.reportViewer1.ProcessingMode = ProcessingMode.Local;
            this.reportViewer1.LocalReport.DataSources.Add(dSource);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = pathfile;
            this.reportViewer1.LocalReport.SetParameters(rParams);
            this.reportViewer1.RefreshReport();
        }

        public void LoadDataToRDLCForSummary(string rdlcFile, string sheetname, List<ReportParameter> rParams)
        {
            try
            {
                this.reportViewer1.LocalReport.DataSources.Clear();

                pathfile = "NTC_Consolidator.Report." + rdlcFile;

                rptDataSetNameForSummary[0] = "dssummary";
                rptDataSetNameForSummary[1] = "dsSumOfUDIBalance";
                rptDataSetNameForSummary[2] = "dsSumOfPVRV";
                rptDataSetNameForSummary[3] = "dsSumOfPVGD";
                rptDataSetNameForSummary[4] = "dsSumOfAccIntReceievables";
                rptDataSetNameForSummary[5] = "dsSumOfClientEquity";

                ReportDataSource dSOB = new ReportDataSource(rptDataSetNameForSummary[0].ToString(), dtSumOfOB);
                ReportDataSource dSUDIBalance = new ReportDataSource(rptDataSetNameForSummary[1], dtSumOfUDIBalance);
                ReportDataSource dSPVRV = new ReportDataSource(rptDataSetNameForSummary[2], dtSumOfPVRV);
                ReportDataSource dSPVGD = new ReportDataSource(rptDataSetNameForSummary[3], dtSumOfPVGD);
                ReportDataSource dSACCRUEDINTERESTRECEIVABLE = new ReportDataSource(rptDataSetNameForSummary[4], dtSumOfACCRUEDINTERESTRECEIVABLE);
                ReportDataSource dSCLIENTEQUITY = new ReportDataSource(rptDataSetNameForSummary[5], dtSumOfCLIENTEQUITY);


                this.reportViewer1.LocalReport.DisplayName = sheetname;
                this.reportViewer1.ProcessingMode = ProcessingMode.Local;
                this.reportViewer1.LocalReport.DataSources.Add(dSOB);
                this.reportViewer1.LocalReport.DataSources.Add(dSUDIBalance);
                this.reportViewer1.LocalReport.DataSources.Add(dSPVRV);
                this.reportViewer1.LocalReport.DataSources.Add(dSPVGD);
                this.reportViewer1.LocalReport.DataSources.Add(dSACCRUEDINTERESTRECEIVABLE);
                this.reportViewer1.LocalReport.DataSources.Add(dSCLIENTEQUITY);
                this.reportViewer1.LocalReport.ReportEmbeddedResource = pathfile;
                this.reportViewer1.LocalReport.SetParameters(rParams);
                this.reportViewer1.RefreshReport();
            }
            catch (Exception ex)
            {

                throw;
            }
        }


        //private void GenerateExcel(string fileDestination, string ExportFilename, string fileFormat)
        //{
        //    Warning[] warnings;
        //    string[] streamids;
        //    string mimeType;
        //    string encoding;
        //    string extension;
        //    byte[] bytes = this.reportViewer1.LocalReport.Render(fileFormat.ToUpper(), "", out mimeType, out encoding, out extension, out streamids, out warnings);
        //    FileStream fs = new FileStream(fileDestination, FileMode.Create);
        //    fs.Write(bytes, 0, bytes.Length);
        //    fs.Close();
        //}

        private DataTable GetBlankIndustryCode()
        {
            dtexceptionalReport = new DataTable();
            dtexceptionalReport.Columns.Add(new DataColumn("SYSTEM"));
            dtexceptionalReport.Columns.Add(new DataColumn("AccountNo"));
            dtexceptionalReport.Columns.Add(new DataColumn("ClientName"));
            dtexceptionalReport.Columns.Add(new DataColumn("AO"));
            dtexceptionalReport.Columns.Add(new DataColumn("PerFaMSAAFICBSIndustryCode"));
            dtexceptionalReport.Columns.Add(new DataColumn("IndustryHeader"));
            dtexceptionalReport.Columns.Add(new DataColumn("IndustryDetail"));

            DataRow dr = null;

            foreach (var objVal in iResult)
            {
                var item = objVal.ObjectToData();

                dr = dtexceptionalReport.NewRow();
                dr["AccountNo"] = item.Rows[0]["AccountNo"];
                dr["ClientName"] = item.Rows[0]["ClientName"];
                dr["AO"] = item.Rows[0]["AO"];
                dr["PerFaMSAAFICBSIndustryCode"] = item.Rows[0]["PerFaMSAAFICBSIndustryCode"];
                dr["IndustryHeader"] = item.Rows[0]["IndustryHeader"];
                dr["IndustryDetail"] = item.Rows[0]["IndustryDetail"];

                dtexceptionalReport.Rows.Add(dr);
            }
            return dtexceptionalReport;
        }

        private DataTable GetInvalidDosriTagging()
        {
            dtexceptionalReport = new DataTable();
            dtexceptionalReport.Columns.Add(new DataColumn("AccountNo"));
            dtexceptionalReport.Columns.Add(new DataColumn("ClientName"));
            dtexceptionalReport.Columns.Add(new DataColumn("AO"));
            dtexceptionalReport.Columns.Add(new DataColumn("RPT"));

            DataRow dr = null;

            foreach (var objVal in iResult)
            {
                var item = objVal.ObjectToData();

                dr = dtexceptionalReport.NewRow();
                dr["AccountNo"] = item.Rows[0]["AccountNo"];
                dr["ClientName"] = item.Rows[0]["ClientName"];
                dr["AO"] = item.Rows[0]["AO"];
                dr["RPT"] = item.Rows[0]["RPT"];

                dtexceptionalReport.Rows.Add(dr);
            }
            return dtexceptionalReport;
        }

        //private DataTable GetICBSZeroAsset()
        //{
        //    dtexceptionalReport = new DataTable();
        //    dtexceptionalReport.Columns.Add(new DataColumn("PNNUMBER"));
        //    dtexceptionalReport.Columns.Add(new DataColumn("CUSTOMERNAME"));
        //    dtexceptionalReport.Columns.Add(new DataColumn("OFFICERAOCODE"));
        //    dtexceptionalReport.Columns.Add(new DataColumn("SIZEOFFIRM"));

        //    DataRow dr = null;

        //    foreach (var objVal in iResult)
        //    {
        //        var item = objVal.ObjectToData();

        //        dr = dtexceptionalReport.NewRow();
        //        dr["PNNUMBER"] = item.Rows[0]["AccountNo"];
        //        dr["CUSTOMERNAME"] = item.Rows[0]["ClientName"];
        //        dr["OFFICERAOCODE"] = item.Rows[0]["AO"];
        //        dr["SIZEOFFIRM"] = item.Rows[0]["PerFaMSAAFICBSAssetSize"];

        //        dtexceptionalReport.Rows.Add(dr);
        //    }
        //    return dtexceptionalReport;
        //}

        private DataTable GetZeroAsset()
        {
            dtexceptionalReport = new DataTable();
            dtexceptionalReport.Columns.Add(new DataColumn("AccountNo"));
            dtexceptionalReport.Columns.Add(new DataColumn("ClientName"));
            dtexceptionalReport.Columns.Add(new DataColumn("AO"));
            dtexceptionalReport.Columns.Add(new DataColumn("AssetSize"));

            DataRow dr = null;

            foreach (var objVal in iResult)
            {
                var item = objVal.ObjectToData();

                dr = dtexceptionalReport.NewRow();
                dr["AccountNo"] = item.Rows[0]["AccountNo"];
                dr["ClientName"] = item.Rows[0]["ClientName"];
                dr["AO"] = item.Rows[0]["AO"];
                dr["AssetSize"] = item.Rows[0]["PerFaMSAAFICBSAssetSize"];

                dtexceptionalReport.Rows.Add(dr);
            }
            return dtexceptionalReport;
        }

        private DataTable GetDiffRiskAndGL()
        {
            dtexceptionalReport = new DataTable();
            dtexceptionalReport.Columns.Add(new DataColumn("System"));
            dtexceptionalReport.Columns.Add(new DataColumn("AccountNo"));
            dtexceptionalReport.Columns.Add(new DataColumn("ClientName"));
            dtexceptionalReport.Columns.Add(new DataColumn("TaggingPerSystem"));
            dtexceptionalReport.Columns.Add(new DataColumn("TaggingByRisk"));

            DataRow dr = null;

            foreach (var objVal in iResult)
            {
                var item = objVal.ObjectToData();

                dr = dtexceptionalReport.NewRow();
                dr["System"] = item.Rows[0]["SYSTEM"];
                dr["AccountNo"] = item.Rows[0]["AccountNo"];
                dr["ClientName"] = item.Rows[0]["ClientName"];
                dr["TaggingPerSystem"] = item.Rows[0]["StatusPerSystem"];
                dr["TaggingByRisk"] = item.Rows[0]["PreviousMonthsNPLTaggingByRisk"];

                dtexceptionalReport.Rows.Add(dr);
            }
            return dtexceptionalReport;
        }

        private DataTable GetSumOfOB()
        {
            dtSumOfOB = new DataTable();
            dtSumOfOB.Columns.Add(new DataColumn("SYSTEM"));
            dtSumOfOB.Columns.Add(new DataColumn("AccountNo"));
            dtSumOfOB.Columns.Add(new DataColumn("GMACT"));
            dtSumOfOB.Columns.Add(new DataColumn("GMNAME"));
            dtSumOfOB.Columns.Add(new DataColumn("GMYBAL"));
            dtSumOfOB.Columns.Add(new DataColumn("ICBSGLCODE"));
            dtSumOfOB.Columns.Add(new DataColumn("ICBSGLNAME"));
            dtSumOfOB.Columns.Add(new DataColumn("OB"));
            dtSumOfOB.Columns.Add(new DataColumn("DIFFERENCE"));
            dtSumOfOB.Columns.Add(new DataColumn("Total"));
            //dtSumOfOB.Columns.Add(new DataColumn("totalGMYBAL"));

            DataRow dr = null;
            var _SubTotalOB = 0.00;
            var _SubTotalGMYBAL = 0.00;
            //var _DIFFERENCE = 0.00;
            if (iResult.Length > 0)
            {
                foreach (var objVal in iResult)
                {
                    var item = objVal.ObjectToData();

                    dr = dtSumOfOB.NewRow();
                    dr["SYSTEM"] = item.Rows[0]["SYSTEM"];
                    dr["GMACT"] = item.Rows[0]["GMACT"];
                    dr["GMNAME"] = item.Rows[0]["ICBSGLName"];
                    dr["GMYBAL"] = Convert.ToDouble(item.Rows[0]["GMYBAL"]);
                    dr["ICBSGLCODE"] = item.Rows[0]["ICBSGLCode"];
                    dr["ICBSGLNAME"] = item.Rows[0]["ICBSGLName"];
                    dr["OB"] = Convert.ToDouble(item.Rows[0]["OB"]);
                    dr["DIFFERENCE"] = Convert.ToDouble(item.Rows[0]["Diff"]);

                    _SubTotalGMYBAL += Convert.ToDouble(item.Rows[0]["GMYBAL"]);
                    //dr["SubTotalGMYBAL"] = _SubTotalGMYBAL;

                    _SubTotalOB += Convert.ToDouble(item.Rows[0]["OB"]);
                    totalDiffOB += Convert.ToDouble(item.Rows[0]["Diff"]);

                    dtSumOfOB.Rows.Add(dr);
                }
            }
            totalOB = _SubTotalOB;
            totalGMYBal = _SubTotalGMYBAL;
            return dtSumOfOB;
        }

        private DataTable GetSumOfUDIBalance()
        {
            dtSumOfUDIBalance = new DataTable();
            dtSumOfUDIBalance.Columns.Add(new DataColumn("SYSTEM"));
            dtSumOfUDIBalance.Columns.Add(new DataColumn("GMACT"));
            dtSumOfUDIBalance.Columns.Add(new DataColumn("GMNAME"));
            dtSumOfUDIBalance.Columns.Add(new DataColumn("GMYBAL"));
            dtSumOfUDIBalance.Columns.Add(new DataColumn("ICBSGLCODE"));
            dtSumOfUDIBalance.Columns.Add(new DataColumn("ICBSGLNAME"));
            dtSumOfUDIBalance.Columns.Add(new DataColumn("SUMOFUDIBalance"));
            dtSumOfUDIBalance.Columns.Add(new DataColumn("DIFFERENCE"));
            var _SubTotalUDI = 0.00;
            var _SubTotalUDIBAL = 0.00;

            DataRow dr = null;
            if (iResult.Length > 0)
            {
                foreach (var objVal in iResult)
                {
                    var item = objVal.ObjectToData();

                    dr = dtSumOfUDIBalance.NewRow();
                    dr["SYSTEM"] = item.Rows[0]["SYSTEM"];
                    dr["GMACT"] = item.Rows[0]["GMACT"];
                    dr["GMNAME"] = item.Rows[0]["GMNAME"];
                    dr["GMYBAL"] = item.Rows[0]["GMYBAL"];
                    dr["ICBSGLCODE"] = item.Rows[0]["ICBSGLCode"];
                    dr["ICBSGLNAME"] = item.Rows[0]["ICBSGLName"];
                    dr["SUMOFUDIBalance"] = item.Rows[0]["UDIBalance"];
                    dr["DIFFERENCE"] = Convert.ToDouble(item.Rows[0]["Diff"]);

                    _SubTotalUDI += Convert.ToDouble(item.Rows[0]["GMYBAL"]);
                    _SubTotalUDIBAL += Convert.ToDouble(item.Rows[0]["UDIBalance"]);
                    totalDiffUDI += Convert.ToDouble(item.Rows[0]["Diff"]);
                    dtSumOfUDIBalance.Rows.Add(dr);
                }
            }

            totalUDIBal = _SubTotalUDIBAL;
            totalGMYBALUDI = _SubTotalUDI;

            return dtSumOfUDIBalance;
        }

        private DataTable GetSumOfPVRV()
        {
            dtSumOfPVRV = new DataTable();
            dtSumOfPVRV.Columns.Add(new DataColumn("SYSTEM"));
            dtSumOfPVRV.Columns.Add(new DataColumn("GMACT"));
            dtSumOfPVRV.Columns.Add(new DataColumn("GMNAME"));
            dtSumOfPVRV.Columns.Add(new DataColumn("GMYBAL"));
            dtSumOfPVRV.Columns.Add(new DataColumn("ICBSGLCODE"));
            dtSumOfPVRV.Columns.Add(new DataColumn("ICBSGLNAME"));
            dtSumOfPVRV.Columns.Add(new DataColumn("FACILITYCODE"));
            dtSumOfPVRV.Columns.Add(new DataColumn("PVRV"));
            dtSumOfPVRV.Columns.Add(new DataColumn("DIFFERENCE"));
            var _SubTotalPVRV = 0.00;
            var _SubTotalPVRVBAL = 0.00;
            DataRow dr = null;
            if (iResult.Length > 0)
            {
                foreach (var objVal in iResult)
                {
                    var item = objVal.ObjectToData();

                    dr = dtSumOfPVRV.NewRow();
                    dr["SYSTEM"] = item.Rows[0]["SYSTEM"];
                    dr["GMACT"] = item.Rows[0]["GMACT"];
                    dr["GMNAME"] = item.Rows[0]["GMNAME"];
                    dr["GMYBAL"] = item.Rows[0]["GMYBAL"];

                    dr["ICBSGLCODE"] = item.Rows[0]["ICBSGLCode"];
                    dr["ICBSGLNAME"] = item.Rows[0]["ICBSGLName"];
                    dr["FACILITYCODE"] = item.Rows[0]["FacilityCode"];
                    dr["PVRV"] = item.Rows[0]["PVRV"];
                    dr["DIFFERENCE"] = Convert.ToDouble(item.Rows[0]["Diff"]);

                    _SubTotalPVRV += Convert.ToDouble(item.Rows[0]["GMYBAL"]);
                    _SubTotalPVRVBAL += Convert.ToDouble(item.Rows[0]["PVRV"]);
                    totalDiffPVRV += Convert.ToDouble(item.Rows[0]["Diff"]);
                    dtSumOfPVRV.Rows.Add(dr);
                }
            }

            totalGMYBALPVRV = _SubTotalPVRV;
            totalPVRV = _SubTotalPVRVBAL;

            return dtSumOfPVRV;
        }

        private DataTable GetSumOfPVGD()
        {
            dtSumOfPVGD = new DataTable();
            dtSumOfPVGD.Columns.Add(new DataColumn("SYSTEM"));
            dtSumOfPVGD.Columns.Add(new DataColumn("GMACT"));
            dtSumOfPVGD.Columns.Add(new DataColumn("GMNAME"));
            dtSumOfPVGD.Columns.Add(new DataColumn("GMYBAL"));
            dtSumOfPVGD.Columns.Add(new DataColumn("ICBSGLCODE"));
            dtSumOfPVGD.Columns.Add(new DataColumn("ICBSGLNAME"));
            dtSumOfPVGD.Columns.Add(new DataColumn("FACILITYCODE"));
            dtSumOfPVGD.Columns.Add(new DataColumn("PVGD"));
            dtSumOfPVGD.Columns.Add(new DataColumn("DIFFERENCE"));  
            var _SubTotalPVGD = 0.00;
            var _SubTotalPVGDBAL = 0.00;

            DataRow dr = null;
            if (iResult.Length > 0)
            {
                foreach (var objVal in iResult)
                {
                    var item = objVal.ObjectToData();

                    dr = dtSumOfPVGD.NewRow();
                    dr["SYSTEM"] = item.Rows[0]["SYSTEM"];
                    dr["GMACT"] = item.Rows[0]["GMACT"];
                    dr["GMNAME"] = item.Rows[0]["GMNAME"];
                    dr["GMYBAL"] = item.Rows[0]["GMYBAL"];
                    dr["ICBSGLCODE"] = item.Rows[0]["ICBSGLCode"];
                    dr["ICBSGLNAME"] = item.Rows[0]["ICBSGLName"];
                    dr["FACILITYCODE"] = item.Rows[0]["FacilityCode"];
                    dr["PVGD"] = item.Rows[0]["PVGD"];
                    dr["DIFFERENCE"] = Convert.ToDouble(item.Rows[0]["Diff"]);
                    _SubTotalPVGD += Convert.ToDouble(item.Rows[0]["GMYBAL"]);
                    _SubTotalPVGDBAL += Convert.ToDouble(item.Rows[0]["PVGD"]);
                    totalDiffPVGD += Convert.ToDouble(item.Rows[0]["Diff"]);
                    dtSumOfPVGD.Rows.Add(dr);
                }
            }

            totalPVGD = _SubTotalPVGDBAL;
            totalGMYBALPVGD = _SubTotalPVGD;

            return dtSumOfPVGD;
        }

        private DataTable GetSumOfACCRUEDINTERESTRECEIVABLE()
        {
            dtSumOfACCRUEDINTERESTRECEIVABLE = new DataTable();
            dtSumOfACCRUEDINTERESTRECEIVABLE.Columns.Add(new DataColumn("SYSTEM"));
            dtSumOfACCRUEDINTERESTRECEIVABLE.Columns.Add(new DataColumn("GMACT"));
            dtSumOfACCRUEDINTERESTRECEIVABLE.Columns.Add(new DataColumn("GMNAME"));
            dtSumOfACCRUEDINTERESTRECEIVABLE.Columns.Add(new DataColumn("GMYBAL"));
            dtSumOfACCRUEDINTERESTRECEIVABLE.Columns.Add(new DataColumn("ICBSGLCODE"));
            dtSumOfACCRUEDINTERESTRECEIVABLE.Columns.Add(new DataColumn("ICBSGLNAME"));
            dtSumOfACCRUEDINTERESTRECEIVABLE.Columns.Add(new DataColumn("SUMOFACCRUEDINTERESTRECEIVABLE"));
            dtSumOfACCRUEDINTERESTRECEIVABLE.Columns.Add(new DataColumn("DIFFERENCE"));
            var _SubTotalGMYBAL = 0.00;
            var _SubTotalACCRUEDINTERESTRECEIVABLE = 0.00;

            DataRow dr = null;
            if (iResult.Length > 0)
            {
                foreach (var objVal in iResult)
                {
                    var item = objVal.ObjectToData();

                    dr = dtSumOfACCRUEDINTERESTRECEIVABLE.NewRow();
                    dr["SYSTEM"] = item.Rows[0]["SYSTEM"];
                    dr["GMACT"] = item.Rows[0]["GMACT"];
                    dr["GMNAME"] = item.Rows[0]["GMNAME"];
                    dr["GMYBAL"] = item.Rows[0]["GMYBAL"];
                    dr["DIFFERENCE"] = Convert.ToDouble(item.Rows[0]["Diff"]);
                    dr["ICBSGLCODE"] = item.Rows[0]["ICBSGLCode"];
                    dr["ICBSGLNAME"] = item.Rows[0]["ICBSGLName"];
                    dr["SUMOFACCRUEDINTERESTRECEIVABLE"] = item.Rows[0]["AccruedInterestReceivable"];
                    totalDiffACCR += Convert.ToDouble(item.Rows[0]["Diff"]);
                    _SubTotalGMYBAL += Convert.ToDouble(item.Rows[0]["GMYBAL"]);
                    _SubTotalACCRUEDINTERESTRECEIVABLE += Convert.ToDouble(item.Rows[0]["AccruedInterestReceivable"]);

                    dtSumOfACCRUEDINTERESTRECEIVABLE.Rows.Add(dr);
                }
            }

            totalACCRUEDINTERESTRECEIVABLE = _SubTotalACCRUEDINTERESTRECEIVABLE;
            totalGMYACCRUEDINTERESTRECEIVABLE = _SubTotalGMYBAL;

            return dtSumOfACCRUEDINTERESTRECEIVABLE;
        }

        private DataTable GetSumOfCLIENTEQUITY()
        {
            dtSumOfCLIENTEQUITY = new DataTable();
            dtSumOfCLIENTEQUITY.Columns.Add(new DataColumn("SYSTEM"));
            dtSumOfCLIENTEQUITY.Columns.Add(new DataColumn("GMACT"));
            dtSumOfCLIENTEQUITY.Columns.Add(new DataColumn("GMNAME"));
            dtSumOfCLIENTEQUITY.Columns.Add(new DataColumn("GMYBAL"));
            dtSumOfCLIENTEQUITY.Columns.Add(new DataColumn("ICBSGLCODE"));
            dtSumOfCLIENTEQUITY.Columns.Add(new DataColumn("ICBSGLNAME"));
            dtSumOfCLIENTEQUITY.Columns.Add(new DataColumn("SUMOFCLIENTEQUITY"));
            dtSumOfCLIENTEQUITY.Columns.Add(new DataColumn("DIFFERENCE"));
            var _SubTotalGMY = 0.00;
            var _SubTotalCLIENTEQUITY = 0.00;

            DataRow dr = null;
            if (iResult.Length > 0)
            {
                foreach (var objVal in iResult)
                {
                    var item = objVal.ObjectToData();

                    dr = dtSumOfCLIENTEQUITY.NewRow();
                    dr["SYSTEM"] = item.Rows[0]["SYSTEM"];
                    dr["GMACT"] = item.Rows[0]["GMACT"];
                    dr["GMNAME"] = item.Rows[0]["GMNAME"];
                    dr["GMYBAL"] = item.Rows[0]["GMYBAL"];
                    dr["DIFFERENCE"] = Convert.ToDouble(item.Rows[0]["Diff"]);
                    dr["ICBSGLCODE"] = item.Rows[0]["ICBSGLCode"];
                    dr["ICBSGLNAME"] = item.Rows[0]["ICBSGLName"];
                    dr["SUMOFCLIENTEQUITY"] = item.Rows[0]["ClientsEquity"];
                    totalDiffEQ += Convert.ToDouble(item.Rows[0]["Diff"]);
                    _SubTotalGMY += Convert.ToDouble(item.Rows[0]["GMYBAL"]);
                    _SubTotalCLIENTEQUITY += Convert.ToDouble(item.Rows[0]["ClientsEquity"]);


                    dtSumOfCLIENTEQUITY.Rows.Add(dr);
                }
            }

            totalGMYCLIENTSEQUITY = _SubTotalGMY;
            totalCLIENTSEQUITY = _SubTotalCLIENTEQUITY;
            return dtSumOfCLIENTEQUITY;
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            if (!IsBusy)
            {
                pnlWaitInfo.Visible = true;
                lblWaitInfo.Text = "Fetching records, Please wait...";
                lblWaitStatus.Text = "Status: In-progress...";
                dtexceptionalReport = new DataTable();

                summaryWorker = new BackgroundWorker();
                summaryWorker.WorkerReportsProgress = true;
                summaryWorker.DoWork += new DoWorkEventHandler(summaryWorker_DoWork);
                summaryWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(summaryWorker_RunWorkerCompleted);
                summaryWorker.ProgressChanged += new ProgressChangedEventHandler(summaryWorker_ProgressChanged);
                summaryWorker.WorkerSupportsCancellation = true;
                summaryWorker.RunWorkerAsync();
            }
            else
            {
                lblBusy.Text = "Busy processing, Please wait...";
            }
        }

        private void DisplayData(List<ReportParameter> _parameters, string _rptDataSetName, string[] _rptDataSetNameForSummary)
        {
            if (filename == "NTC Summary Report")
            {
                // var dtDataSetNameArray = new string[6];
                // rptDataSetName = _rptDataSetNameForSummary[0];

                LoadDataToRDLCForSummary(rdlcFile, sheetname, _parameters);
            }
            else
            {
                LoadDataToRDLC(rptDataSetName, dtexceptionalReport, rdlcFile, sheetname, _parameters);
            }
        }

        private void summaryWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            IsBusy = true;

            try
            {
                
                var frmdate = Convert.ToDateTime(cmbDateFrom.Text);
                var todate = DateTime.Today;//Convert.ToDateTime(cmbDateFrom.Text);

                switch (txtRptName.Text.Trim().ToLower())
                {
                    #region NTCReport
                    case "consolidator":
                        parameters.Add(new ReportParameter("paramDateFrom", cmbDateFrom.Text));
                        //consolidatorRepository.GetAll().ToDataTable();
                        dtexceptionalReport = consolidatorRepository.GetAll().ToDataTable();
                        rptDataSetName = "dsNTCReport";
                        filename = "NTC Consolidated File";
                        rdlcFile = "NTCConsolidatorReport.rdlc";
                        sheetname = "NTC Consolidated Report";

                        //dtexceptionalReport = ToDataTableFromArray(iResult);
                        break;
                    //case "corresponding gl":
                    //    //iResult = consolidatorRepository.ExceptionReportBlankIndustryCode(frmdate, todate, "ICBS");
                    //    rptDataSetName = "dsCorrespondingGL";
                    //    filename = "NTC Corresponding GL";
                    //    rdlcFile = "CorrespondingGL.rdlc";
                    //    sheetname = "NTC Corresponding GL";
                    //    break;
                    //case "daily gl":
                    //    // iResult = consolidatorRepository.ExceptionReportBlankIndustryCode(frmdate, todate, "ICBS");
                    //    rptDataSetName = "dsDailyGL";
                    //    filename = "NTC Daily GL";
                    //    rdlcFile = "DailyGL.rdlc";
                    //    sheetname = "NTC Corresponding GL";
                    //    break;
                    //case "exchange rate":
                    //    //iResult = consolidatorRepository.ExceptionReportBlankIndustryCode(frmdate, todate, "ICBS");
                    //    rptDataSetName = "dsExchangeRate";
                    //    filename = "NTC Exchange Rate";
                    //    rdlcFile = "ExchangeRate.rdlc";
                    //    sheetname = "NTC Exchange Rate";
                    //    break;
                    //case "migrated account":
                    //    //iResult = consolidatorRepository.ExceptionReportBlankIndustryCode(frmdate, todate, "ICBS");
                    //    rptDataSetName = "dsMigratedAccount";
                    //    filename = "NTC Migrated Account";
                    //    rdlcFile = "MigratedAccount.rdlc";
                    //    sheetname = "NTC Migrated Account";
                    //    break;
                    //case "past due":
                    //    //iResult = consolidatorRepository.ExceptionReportBlankIndustryCode(frmdate, todate, "ICBS");
                    //    rptDataSetName = "dsPastDue";
                    //    filename = "NTC Past Due";
                    //    rdlcFile = "PastDue.rdlc";
                    //    sheetname = "NTC Past Due";
                    //    break;
                    //case "qualifying capital":
                    //    //iResult = consolidatorRepository.ExceptionReportBlankIndustryCode(frmdate, todate, "ICBS");
                    //    rptDataSetName = "dsQualifyingCapital";
                    //    filename = "NTC Qualifying Capital";
                    //    rdlcFile = "QualifyingCapitalReport.rdlc";
                    //    sheetname = "NTC Qualifying Capital";
                    //    break;
                    //case "under litigation":
                    //    //iResult = consolidatorRepository.ExceptionReportBlankIndustryCode(frmdate, todate, "ICBS");
                    //    rptDataSetName = "dsUnderLitigation";
                    //    filename = "NTC Under Litigation";
                    //    rdlcFile = "UnderLitigation.rdlc";
                    //    sheetname = "NTC Under Litigation";
                    //    break;
                    #endregion

                    #region Exceptional Report
                    #region ICBS
                    case "icbs - blank industry code":
                        parameters.Add(new ReportParameter("paramDateFrom", cmbDateFrom.Text));
                        parameters.Add(new ReportParameter("paramDateTo", cmbDateTo.Text));
                        iResult = null;
                        iResult = consolidatorRepository.ExceptionReportBlankIndustryCode(frmdate, todate, "ICBS");
                        GetBlankIndustryCode();
                        rptDataSetName = "dsicbsblankindustrycode";
                        filename = "NTC ICBS - Blank Industry Code";
                        rdlcFile = "Icbsblankindustrycode.rdlc";
                        sheetname = "ICBS - Blank Industry Code";
                        break;
                    case "icbs - zero asset size":
                        parameters.Add(new ReportParameter("paramDateFrom", cmbDateFrom.Text));
                        parameters.Add(new ReportParameter("paramDateTo", cmbDateTo.Text));
                        iResult = null;
                        iResult = consolidatorRepository.ExceptionReportZeroAssetSize(frmdate, todate, "ICBS");
                        //GetICBSZeroAsset();
                        GetZeroAsset();
                        rptDataSetName = "dsicbszeroassetsize";
                        filename = "NTC ICBS - zero asset size";
                        rdlcFile = "Icbszeroassetsize.rdlc";
                        sheetname = "ICBS - zero asset size";
                        break;
                    case "icbs - dosri tagging":
                        parameters.Add(new ReportParameter("paramDateFrom", cmbDateFrom.Text));
                        parameters.Add(new ReportParameter("paramDateTo", cmbDateTo.Text));
                        iResult = null;
                        iResult = consolidatorRepository.ExceptionReportDosriTagging(frmdate, todate, "ICBS");
                        GetInvalidDosriTagging();
                        rptDataSetName = "dsicbsdosritagging";
                        filename = "NTC ICBS - dosri tagging";
                        rdlcFile = "Icbsdosritagging.rdlc";
                        sheetname = "ICBS - Dosri Tagging";
                        break;
                    #endregion
                    #region AAF
                    case "aaf - blank industry code":
                        parameters.Add(new ReportParameter("paramDateFrom", cmbDateFrom.Text));
                        parameters.Add(new ReportParameter("paramDateTo", cmbDateTo.Text));
                        iResult = null;
                        iResult = consolidatorRepository.ExceptionReportBlankIndustryCode(frmdate, todate, "AAF");
                        GetBlankIndustryCode();
                        filename = "NTC AAF - blank industry code";
                        rdlcFile = "Aafblankindustrycode.rdlc";
                        sheetname = "AAF - blank industry code";
                        rptDataSetName = "dsBlankIndustryCode";
                        break;
                    case "aaf - zero asset size":
                        parameters.Add(new ReportParameter("paramDateFrom", cmbDateFrom.Text));
                        parameters.Add(new ReportParameter("paramDateTo", cmbDateTo.Text));
                        iResult = null;
                        iResult = consolidatorRepository.ExceptionReportZeroAssetSize(frmdate, todate, "AAF");
                        GetZeroAsset();
                        rptDataSetName = "dsaafzeroassetsize";
                        filename = "NTC AAF - zero asset size";
                        rdlcFile = "Aafzeroassetsize.rdlc";
                        sheetname = "AAF - zero asset size";
                        break;
                    //case "aaf - dosri tagging":
                    //    parameters.Add(new ReportParameter("paramDateFrom", cmbDateFrom.Text));
                    //    parameters.Add(new ReportParameter("paramDateTo", cmbDateTo.Text));
                    //    iResult = consolidatorRepository.ExceptionReportDosriTagging(frmdate, todate, "AAF");
                    //    GetInvalidDosriTagging();
                    //    rptDataSetName = "dsInvalidDosriTagging";
                    //    filename = "NTC AAF - dosri tagging";
                    //    rdlcFile = "Aafdosritagging.rdlc";
                    //    sheetname = "AAF - dosri tagging";
                    //    break; 
                    #endregion
                    case "difference in tagging of risk and gl":
                        parameters.Add(new ReportParameter("paramDateFrom", cmbDateFrom.Text));
                        parameters.Add(new ReportParameter("paramDateTo", cmbDateTo.Text));
                        iResult = null;
                        iResult = consolidatorRepository.ExceptionReportDifferenceInTaggingOfRriskAndGL(frmdate, todate, "AAF");
                        GetDiffRiskAndGL();
                        rptDataSetName = "dsdifferenceintaggingofriskandgl";
                        filename = "NTC Difference in tagging of risk and gl";
                        rdlcFile = "Differenceintaggingofriskandgl.rdlc";
                        sheetname = "Difference In Tagging of Risk and GL";
                        break;
                    case "summary report":
                        parameters.Add(new ReportParameter("paramDateFrom", cmbDateFrom.Text));
                        parameters.Add(new ReportParameter("paramDateTo", cmbDateTo.Text));
                        iResult = null;
                        iResult = consolidatorRepository.ExceptionReportSummaryReportSumOfOB(frmdate, todate, "");
                        GetSumOfOB();
                        parameters.Add(new ReportParameter("totalGMYBal", totalGMYBal.ToString()));
                        parameters.Add(new ReportParameter("totalOB", totalOB.ToString()));
                        parameters.Add(new ReportParameter("totalDiffOB", totalDiffOB.ToString()));
                        iResult = consolidatorRepository.ExceptionReportSummaryReportSumOfUDIBalance(frmdate, todate, "AAF");
                        GetSumOfUDIBalance();
                        parameters.Add(new ReportParameter("totalUDIBal", totalUDIBal.ToString()));
                        parameters.Add(new ReportParameter("totalGMYBALUDI", totalGMYBALUDI.ToString()));
                        parameters.Add(new ReportParameter("totalDiffUDI", totalDiffUDI.ToString()));
                        iResult = null;
                        iResult = consolidatorRepository.ExceptionReportSummaryReportSumOfPVRV(frmdate, todate, "AAF");
                        GetSumOfPVRV();
                        parameters.Add(new ReportParameter("totalPVRV", totalPVRV.ToString()));
                        parameters.Add(new ReportParameter("totalGMYBALPVRV", totalGMYBALPVRV.ToString()));
                        parameters.Add(new ReportParameter("totalDiffPVRV", totalDiffPVRV.ToString()));
                        iResult = null;
                        iResult = consolidatorRepository.ExceptionReportSummaryReportSumOfPVGD(frmdate, todate, "AAF");
                        GetSumOfPVGD();
                        parameters.Add(new ReportParameter("totalPVGD", totalPVGD.ToString()));
                        parameters.Add(new ReportParameter("totalGMYBALPVGD", totalGMYBALPVGD.ToString()));
                        parameters.Add(new ReportParameter("totalDiffPVGD", totalDiffPVGD.ToString()));
                        iResult = null;
                        iResult = consolidatorRepository.ExceptionReportSummaryReportSumOfACCRUEDINTERESTRECEIVABLE(frmdate, todate, "AAF");
                        GetSumOfACCRUEDINTERESTRECEIVABLE();
                        parameters.Add(new ReportParameter("totalGMYACCRUEDINTERESTRECEIVABLE", totalGMYACCRUEDINTERESTRECEIVABLE.ToString()));
                        parameters.Add(new ReportParameter("totalACCRUEDINTERESTRECEIVABLE", totalACCRUEDINTERESTRECEIVABLE.ToString()));
                        parameters.Add(new ReportParameter("totalDiffACCR", totalDiffACCR.ToString()));
                        iResult = null;
                        iResult = consolidatorRepository.ExceptionReportSummaryReportSumOfCLIENTEQUITY(frmdate, todate, "FAMS");
                        GetSumOfCLIENTEQUITY();
                        parameters.Add(new ReportParameter("totalGMYCLIENTSEQUITY", totalGMYCLIENTSEQUITY.ToString()));
                        parameters.Add(new ReportParameter("totalCLIENTSEQUITY", totalCLIENTSEQUITY.ToString()));
                        parameters.Add(new ReportParameter("totalDiffEQ", totalDiffEQ.ToString()));

                        ntcGrandTotalGYMBal = totalGMYBal + totalGMYBALUDI + totalGMYBALPVRV + totalGMYBALPVRV + totalGMYACCRUEDINTERESTRECEIVABLE + totalGMYCLIENTSEQUITY;
                        ntcGrandTotalSum = totalCLIENTSEQUITY + totalACCRUEDINTERESTRECEIVABLE + totalPVGD + totalPVRV + totalUDIBal + totalOB;
                        ntcGrandTotalDiff = ntcGrandTotalGYMBal - ntcGrandTotalSum;

                        parameters.Add(new ReportParameter("ntcGrandTotalGYMBal", ntcGrandTotalGYMBal.ToString()));
                        parameters.Add(new ReportParameter("ntcGrandTotalSum", ntcGrandTotalSum.ToString()));
                        parameters.Add(new ReportParameter("ntcGrandTotalDiff", ntcGrandTotalDiff.ToString()));
                        parameters.Add(new ReportParameter("ntcGrandTotalDiff", ntcGrandTotalDiff.ToString()));
                        rptDataSetNameForSummary[0] = "dssummary";
                        rptDataSetNameForSummary[1] = "dsSumOfUDIBalance";
                        rptDataSetNameForSummary[2] = "dsSumOfPVRV";
                        rptDataSetNameForSummary[3] = "dsSumOfPVGD";
                        rptDataSetNameForSummary[4] = "dsSumOfAccIntReceievables";
                        rptDataSetNameForSummary[5] = "dsSumOfClientEquity";
                        filename = "NTC Summary Report";
                        rdlcFile = "SummaryReport.rdlc";
                        sheetname = "Summary Report";
                        break;
                        #endregion
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private void summaryWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitInfo.Text = "Fetching Data from server, Please wait...";

            lblWaitInfo.Text = labelsreports[1];
        }

        private void summaryWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            IsBusy = false;
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";
            }
            else if (e.Error != null)
            {

                MetroMessageBox.Show(this, "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                lblWaitStatus.Text = "Status: Error Encountered while processing";
                return;
            }
            else
            {
                DisplayData(parameters, rptDataSetName, rptDataSetNameForSummary);
                lblBusy.Text = "";
                btnExport.Enabled = true;
                pnlWaitInfo.Visible = false;
            }
        }

        private void frmReportViewer_FormClosed(object sender, FormClosedEventArgs e)
        {
            frmReportViewer.frmrptviewer = null;
        }

        private void miniToolStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void consolidatorToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(consolidatorToolStripMenuItem.Text);
        }

        private void correspondingGLToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(correspondingGLToolStripMenuItem.Text);
        }

        private void rptHover(string rptname)
        {
            txtRptName.Text = rptname;
        }

        private void dailyGLToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(dailyGLToolStripMenuItem.Text);
        }

        private void exchangeRateToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(exchangeRateToolStripMenuItem.Text);
        }

        private void migratedAccountToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(migratedAccountToolStripMenuItem.Text);
        }

        private void pastDueToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(pastDueToolStripMenuItem.Text);
        }

        private void qualifyingCapitalToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(qualifyingCapitalToolStripMenuItem.Text);
        }

        private void underLitigationToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(underLitigationToolStripMenuItem.Text);
        }

        private void summaryReportToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(summaryReportToolStripMenuItem.Text);
        }

        private void aAFBlankIndustryCodeToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(aAFBlankIndustryCodeToolStripMenuItem.Text);
        }

        private void aAFDOSRITAGGINGToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(aAFDOSRITAGGINGToolStripMenuItem.Text);
        }

        private void aAFZeroAssetSizeToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(aAFZeroAssetSizeToolStripMenuItem.Text);
        }

        private void iCBSBlankIndustryCodeToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(iCBSBlankIndustryCodeToolStripMenuItem.Text);
        }

        private void iCBSDOSRITaggingToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(iCBSDOSRITaggingToolStripMenuItem.Text);
        }

        private void iCBSZeroAssetSizeToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(iCBSZeroAssetSizeToolStripMenuItem.Text);
        }

        private void differenceInTaggingOfRiskAndGLToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(differenceInTaggingOfRiskAndGLToolStripMenuItem.Text);
        }

        private void consolidatorToolStripMenuItem_MouseMove(object sender, MouseEventArgs e)
        {
            rptHover(consolidatorToolStripMenuItem.Text);
        }

        private void correspondingGLToolStripMenuItem_MouseMove(object sender, MouseEventArgs e)
        {
            rptHover(correspondingGLToolStripMenuItem.Text);
        }

        private void consolidatorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
            rptHover(consolidatorToolStripMenuItem.Text);
        }

        private void correspondingGLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(correspondingGLToolStripMenuItem.Text);
        }

        private void dailyGLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(dailyGLToolStripMenuItem.Text);
        }

        private void exchangeRateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(exchangeRateToolStripMenuItem.Text);
        }

        private void migratedAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(migratedAccountToolStripMenuItem.Text);
        }

        private void pastDueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(pastDueToolStripMenuItem.Text);
        }

        private void qualifyingCapitalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(qualifyingCapitalToolStripMenuItem.Text);
        }

        private void underLitigationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(underLitigationToolStripMenuItem.Text);
        }

        private void summaryReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(summaryReportToolStripMenuItem.Text);
        }

        private void aAFBlankIndustryCodeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(aAFBlankIndustryCodeToolStripMenuItem.Text);
        }

        private void aAFDOSRITAGGINGToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(aAFDOSRITAGGINGToolStripMenuItem.Text);
        }

        private void aAFZeroAssetSizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(aAFZeroAssetSizeToolStripMenuItem.Text);
        }

        private void iCBSBlankIndustryCodeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(iCBSBlankIndustryCodeToolStripMenuItem.Text);
        }

        private void iCBSDOSRITaggingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(iCBSDOSRITaggingToolStripMenuItem.Text);
        }

        private void iCBSZeroAssetSizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(iCBSZeroAssetSizeToolStripMenuItem.Text);
        }

        private void differenceInTaggingOfRiskAndGLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.Visible = txtRptName.Text != "Consolidator" ? true : false;
            rptHover(differenceInTaggingOfRiskAndGLToolStripMenuItem.Text);
        }

        private void txtRptName_TextChanged(object sender, EventArgs e)
        {
            btnExecute.Enabled = txtRptName.Text.Length > 0 ? true : false;
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            if (!IsBusy)
            {

                SaveFileDialog diag = new SaveFileDialog();
                diag.Filter = "Excel Files(.xls)|*.xls";//| Excel Files(.xlsx) | *.xlsx";
                diag.FilterIndex = 0;
                diag.RestoreDirectory = true;
                diag.Title = "Export NTC Consolidator To Excel File";

                if (!string.IsNullOrEmpty(txtRptName.Text.Trim()))
                {
                    if (diag.ShowDialog() == DialogResult.OK)
                    {
                        try
                        {
                            pnlWaitInfo.Visible = true;
                            lblWaitInfo.Text = "Exporting Data, Please wait...";
                            lblWaitStatus.Text = "Status: In-progress...";
                            ExportFilename = diag.FileName;
                            fileDestination = Path.GetFullPath(diag.FileName);

                            summaryExportWorker = new BackgroundWorker();
                            summaryExportWorker.WorkerReportsProgress = true;
                            summaryExportWorker.DoWork += new DoWorkEventHandler(summaryExportWorker_DoWork);
                            summaryExportWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(summaryExportWorker_RunWorkerCompleted);
                            summaryExportWorker.ProgressChanged += new ProgressChangedEventHandler(summaryExportWorker_ProgressChanged);
                            summaryExportWorker.WorkerSupportsCancellation = true;
                            summaryExportWorker.RunWorkerAsync();

                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                    }
                }
            }
            else
            {
                lblBusy.Text = "Busy processing, Please wait...";
            }
        }

        private void summaryExportWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitInfo.Text = "Exporting Data, Please wait...";

            lblWaitInfo.Text = labelsreports[1];
        }

        private void summaryExportWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            IsBusy = false;
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";
            }
            else if (e.Error != null)
            {
                MetroMessageBox.Show(this, "\r\n\r\nError encountered while exporting the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);

                lblWaitStatus.Text = "Status: Error Encountered while processing";
                return;
            }
            else
            {

                lblBusy.Text = "";
                pnlWaitInfo.Visible = false;
                MetroMessageBox.Show(this, "\r\n" + Path.GetFileName(ExportFilename) + " was successfully exported.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void summaryExportWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            IsBusy = true;

            try
            {
                Warning[] warnings;
                string[] streamids;
                string mimeType;
                string encoding;
                string extension;
                byte[] bytes = this.reportViewer1.LocalReport.Render("EXCEL", "", out mimeType, out encoding, out extension, out streamids, out warnings);
                FileStream fs = new FileStream(fileDestination, FileMode.Create);
                fs.Write(bytes, 0, bytes.Length);
                fs.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void exceptionalReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //panel1.Visible = txtRptName.Text != "Consolidator" ? true : false;
        }
    }

}
