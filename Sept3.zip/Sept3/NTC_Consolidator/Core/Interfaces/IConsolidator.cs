﻿using NTC_Consolidator.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC_Consolidator.Core.Interfaces
{
    public interface IConsolidator : IDisposable
    {
        IEnumerable<BDOLF_Consolidator> GetAll();
       // IEnumerable<BDOLF_Consolidator> GetAll(string fromdate, string todate);
        Array ExceptionReportBlankIndustryCode(DateTime datefrm, DateTime dateTo, string system);
        Array ExceptionReportZeroAssetSize(DateTime datefrm, DateTime dateTo, string system);
       // Array ExceptionReportZeroAssetSizeICBS(DateTime datefrm, DateTime dateTo, string system);
        Array ExceptionReportDosriTagging(DateTime datefrm, DateTime dateTo, string system);
        Array ExceptionReportDifferenceInTaggingOfRriskAndGL(DateTime datefrm, DateTime dateTo, string system);
        Array ExceptionReportSummaryReportSumOfOB(DateTime datefrm, DateTime dateTo, string system);
        Array ExceptionReportSummaryReportSumOfUDIBalance(DateTime datefrm, DateTime dateTo, string system);
        Array ExceptionReportSummaryReportSumOfPVRV(DateTime datefrm, DateTime dateTo, string system);
        Array ExceptionReportSummaryReportSumOfPVGD(DateTime datefrm, DateTime dateTo, string system);
        Array ExceptionReportSummaryReportSumOfACCRUEDINTERESTRECEIVABLE(DateTime datefrm, DateTime dateTo, string system);//SUM OF CLIENT'S EQUITY
        Array ExceptionReportSummaryReportSumOfCLIENTEQUITY(DateTime datefrm, DateTime dateTo, string system);
        Array Consolidator(DateTime datefrm, DateTime dateTo, string system);
        Array CorrespondingGL(DateTime datefrm, DateTime dateTo, string system);
        Array DailyGL(DateTime datefrm, DateTime dateTo, string system);
        Array ExchangeRate(DateTime datefrm, DateTime dateTo, string system);
        Array MigratedAccount(DateTime datefrm, DateTime dateTo, string system);
        Array PastDue(DateTime datefrm, DateTime dateTo, string system);
        Array QualifyingCapital(DateTime datefrm, DateTime dateTo, string system);
        Array UnderLitigation(DateTime datefrm, DateTime dateTo, string system);
        Array Summary(DateTime datefrm, DateTime dateTo, string system);
        BDOLF_Consolidator GetByID(int TransID);
        BDOLF_Consolidator GetByCode(string keyword);
        void DeleteInsertConsolidator(BDOLF_Consolidator ntc, string keyword);
        void DeleteConsolidator(int AccountNo);
        void TruncateTable();
        IEnumerable<BDOLF_Consolidator> GetTopOne();
        void DeleteConsolidator(string keyword);
        void UpdateConsolidator(BDOLF_Consolidator ntc);
        void BulkInsert(object[] objdata, string keyword);
        void BulkDelete(object[] objdata);
        void BulkUpdete(object[] objdata);
        string GetDate();
        bool ConsoChecker(string keyword);
        bool isGLCodeExist(string keyword);
        void Save();
    }
}
