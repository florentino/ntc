﻿using NTC_Consolidator.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NTC_Consolidator.Data;
using System.Data.Entity;
using System.Data;
using System.Collections;
using System.Data.SqlClient;
using NTC_Consolidator.NTC_Model;
using System.Transactions;

namespace NTC_Consolidator.Core.Repository
{
    public class ConsolidatorRepository : IConsolidator, IDisposable
    {
        private NTC_Context_Entities context;
        DbSet<BDOLF_Consolidator> _bjectSet;

        public ConsolidatorRepository(NTC_Context_Entities context)
        {
            this.context = context;
            _bjectSet = context.Set<BDOLF_Consolidator>();
        }

        public void BulkDelete(object[] objdata)
        {
            throw new NotImplementedException();
        }

        public void BulkInsert(object[] objdata, string keyword)
        {
            try
            {
                var icbsData = (DataTable)objdata[0];
                var aafData = (DataTable)objdata[1];
                var famsData = (DataTable)objdata[2];

                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, new TimeSpan(2, 0, 0)))
                {
                    NTC_Context_Entities context = null;
                    try
                    {
                        context = new NTC_Context_Entities();
                        context.Configuration.AutoDetectChangesEnabled = false;
                        // context.Configuration.ValidateOnSaveEnabled = false;
                        // context.Database.CommandTimeout = 2500;
                        int count = 0;
                        int icbscount = 0;

                        DeleteConsolidator(keyword); // Delete Insert

                        #region ICBS

                        foreach (DataRow entityToInsert in icbsData.Rows)
                        {
                            BDOLF_Consolidator item = new BDOLF_Consolidator();
                            item.AccountNo = entityToInsert["AccountNo"].ToString();
                            item.ClientName = entityToInsert["ClientName"].ToString();
                            item.AO = entityToInsert["AO"].ToString();
                            item.FacilityCode = entityToInsert["FacilityCode"].ToString();
                            item.StatusPerSystem = entityToInsert["StatusPerSystem"].ToString();
                            item.ValueDate = Convert.ToDateTime(entityToInsert["ValueDate"]);
                            item.MaturityDate = Convert.ToDateTime(entityToInsert["MaturityDate"]);
                            item.TotalLoan = Convert.ToDecimal(entityToInsert["TotalLoan"] == null ? 0M : entityToInsert["TotalLoan"]);
                            item.OB = Convert.ToDecimal(entityToInsert["OB"] == null ? 0M : entityToInsert["OB"]);
                            item.MonthlyOB = Convert.ToDecimal(entityToInsert["MonthlyOB"] == null ? 0M : entityToInsert["MonthlyOB"]);
                            item.AccruedInterestReceivable = Convert.ToDecimal(entityToInsert["AccruedInterestReceivable"] == null ? 0M : entityToInsert["AccruedInterestReceivable"]);
                            item.OriginalRate = Convert.ToDecimal(entityToInsert["OriginalRate"] == null ? 0M : entityToInsert["OriginalRate"]);
                            item.CurrentRate = Convert.ToDecimal(entityToInsert["CurrentRate"] == null ? 0M : entityToInsert["CurrentRate"]);

                            item.TermInMonths = Convert.ToInt32(entityToInsert["TermInMonths"] == null ? 0 : entityToInsert["TermInMonths"]);

                            item.AAFICBSRateType = entityToInsert["AAFICBSRateType"].ToString();
                            item.PastDueDateITLDateExtractedPerAAFICBS = entityToInsert["PastDueDateITLDateExtractedPerAAFICBS"].ToString();
                            item.PerFaMSAAFICBSIndustryCode = entityToInsert["PerFaMSAAFICBSIndustryCode"].ToString();
                            item.IndustryHeader = entityToInsert["IndustryHeader"].ToString();
                            item.IndustryDetail = entityToInsert["IndustryDetail"].ToString();
                            item.Collateral = entityToInsert["Collateral"].ToString();
                            item.PerFaMSAAFICBSAssetSize = entityToInsert["PerFaMSAAFICBSAssetSize"].ToString();
                            item.CostCenter = entityToInsert["CostCenter"].ToString();
                            item.NationalityPerICBS = entityToInsert["NationalityPerICBS"].ToString();
                            item.NextRateReviewDateExtractedPerFaMSAAFICBS = Convert.ToDateTime(entityToInsert["NextRateReviewDateExtractedPerFaMSAAFICBS"]);
                            item.TaxID = entityToInsert["TaxID"].ToString();
                            item.LoanPurposeCode = entityToInsert["LoanPurposeCode"].ToString();
                            item.MaturityTypeCode = entityToInsert["MaturityTypeCode"].ToString();
                            item.BankRelationship = entityToInsert["BankRelationship"].ToString();
                            item.SyndicatedLoanInd = entityToInsert["SyndicatedLoanInd"].ToString();
                            item.CustomerTypeDescription = entityToInsert["CustomerTypeDescription"].ToString();
                            item.RPT = entityToInsert["RPT"].ToString();
                            item.ICBSCollateralCode = entityToInsert["ICBSCollateralCode"].ToString();
                            item.AssetValue = Convert.ToDecimal(entityToInsert["AssetValue"] == null ? 0M : entityToInsert["AssetValue"]);
                            item.ApprovedAmount = Convert.ToDecimal(entityToInsert["ApprovedAmount"] == null ? 0M : entityToInsert["ApprovedAmount"]);
                            item.LastPrincipalPay = Convert.ToDecimal(entityToInsert["LastPrincipalPay"] == null ? 0M : entityToInsert["LastPrincipalPay"]);
                            item.PrincipalPayDate = Convert.ToDateTime(entityToInsert["PrincipalPayDate"]);
                            item.LastInterestPay = Convert.ToDecimal(entityToInsert["LastInterestPay"] == null ? 0M : entityToInsert["LastInterestPay"]);
                            item.LastInterestPayDate = Convert.ToDateTime(entityToInsert["LastInterestPayDate"]);
                            item.PreviousMonthsNPLTaggingByRisk = entityToInsert["PreviousMonthsNPLTaggingByRisk"].ToString();
                            item.SpecificRequiredProvisions = entityToInsert["SpecificRequiredProvisions"].ToString();
                            item.GeneralRequiredProvisions = entityToInsert["GeneralRequiredProvisions"].ToString();
                            item.Reason = entityToInsert["Reason"].ToString();
                            item.RawFiles = entityToInsert["RawFiles"].ToString();
                            item.isConsolidated = Convert.ToBoolean(entityToInsert["isConsolidated"]);
                            item.isDeleted = Convert.ToBoolean(entityToInsert["isDeleted"]);
                            item.UserName = entityToInsert["UserName"].ToString();
                            item.TransDate = Convert.ToDateTime(entityToInsert["TransDate"]);
                            item.RecordDate = Convert.ToDateTime(entityToInsert["RecordDate"]);
                            item.SYSTEM = entityToInsert["SYSTEM"].ToString();
                            ++count;
                            ++icbscount;
                            context = AddToContext(context, item, count, 100, true);

                        }
                   
                        #endregion

                        #region AAF
                      
                        foreach (DataRow entityToInsert in aafData.Rows)
                        {
                            BDOLF_Consolidator item = new BDOLF_Consolidator();

                            item.AccountNo = entityToInsert["AccountNo"].ToString();
                            item.ClientName = entityToInsert["ClientName"].ToString();
                            item.AO = entityToInsert["AO"].ToString();
                            item.FacilityCode = entityToInsert["FacilityCode"].ToString();
                            item.StatusPerSystem = entityToInsert["StatusPerSystem"].ToString();
                            item.ValueDate = Convert.ToDateTime(entityToInsert["ValueDate"]);
                            item.FirstDueDate = Convert.ToDateTime(entityToInsert["FirstDueDate"]);
                            item.MaturityDate = Convert.ToDateTime(entityToInsert["MaturityDate"]);
                            item.TotalLoan = Convert.ToDecimal(entityToInsert["TotalLoan"] == null ? 0M : entityToInsert["TotalLoan"]);
                            item.OB = Convert.ToDecimal(entityToInsert["OB"] == null ? 0M : entityToInsert["OB"]);
                            item.MonthlyOB = Convert.ToDecimal(entityToInsert["MonthlyOB"] == null ? 0M : entityToInsert["MonthlyOB"]);
                            item.UDIBalance = Convert.ToDecimal(entityToInsert["UDIBalance"] == null ? 0M : entityToInsert["UDIBalance"]);
                            item.OrigERV = Convert.ToDecimal(entityToInsert["OrigERV"] == null ? 0M : entityToInsert["OrigERV"]);
                            item.PVRV = Convert.ToDecimal(entityToInsert["PVRV"] == null ? 0M : entityToInsert["PVRV"]);
                            item.OrigGD = Convert.ToDecimal(entityToInsert["OrigGD"] == null ? 0M : entityToInsert["OrigGD"]);
                            item.PVGD = Convert.ToDecimal(entityToInsert["PVGD"] == null ? 0M : entityToInsert["PVGD"]);
                            item.OriginalRate = Convert.ToDecimal(entityToInsert["OriginalRate"] == null ? 0M : entityToInsert["OriginalRate"]);
                            item.CurrentRate = Convert.ToDecimal(entityToInsert["CurrentRate"] == null ? 0M : entityToInsert["CurrentRate"]);
                            item.TermInMonths = (int)Convert.ToDouble(entityToInsert["TermInMonths"] == null ? 0 : entityToInsert["TermInMonths"]);
                            item.RemainingTermInMonths = (int)Convert.ToDouble(entityToInsert["RemainingTermInMonths"] == null ? 0 : entityToInsert["RemainingTermInMonths"]);
                            item.OriginalAmortizationAAF = Convert.ToDecimal(entityToInsert["OriginalAmortizationAAF"] == null ? 0M : entityToInsert["OriginalAmortizationAAF"]);
                            item.PaymentScheduleAmortizationAAF = Convert.ToDecimal(entityToInsert["PaymentScheduleAmortizationAAF"] == null ? 0M : entityToInsert["PaymentScheduleAmortizationAAF"]);
                            item.RepricedDate = Convert.ToDateTime(entityToInsert["RepricedDate"]);
                            item.AAFICBSRateType = entityToInsert["AAFICBSRateType"].ToString();
                            item.RepricedAmortization = Convert.ToDecimal(entityToInsert["RepricedAmortization"] == null ? 0M : entityToInsert["RepricedAmortization"]);
                            item.PastDueDateITLDateExtractedPerAAFICBS =entityToInsert["PastDueDateITLDateExtractedPerAAFICBS"].ToString();
                            item.PerFaMSAAFICBSIndustryCode = entityToInsert["PerFaMSAAFICBSIndustryCode"].ToString();
                            item.IndustryHeader = entityToInsert["IndustryHeader"].ToString();
                            item.IndustryDetail = entityToInsert["IndustryDetail"].ToString();
                            item.Collateral = entityToInsert["Collateral"].ToString();
                            item.PerFaMSAAFICBSAssetSizeInWords = entityToInsert["PerFaMSAAFICBSAssetSizeInWords"].ToString();
                            item.ICBSGLCode = entityToInsert["ICBSGLCode"].ToString();
                            item.ICBSGLName = entityToInsert["ICBSGLName"].ToString();
                            item.CostCenter = entityToInsert["CostCenter"].ToString();
                            item.BranchNameOfCostCenterPerSystem = entityToInsert["BranchNameOfCostCenterPerSystem"].ToString();
                            item.OriginatingBranchBooked = entityToInsert["OriginatingBranchBooked"].ToString();
                            item.NationalityPerICBS = entityToInsert["NationalityPerICBS"].ToString();
                            item.NextRateReviewDateExtractedPerFaMSAAFICBS = Convert.ToDateTime(entityToInsert["NextRateReviewDateExtractedPerFaMSAAFICBS"]);
                            item.TaxID = entityToInsert["TaxID"].ToString();
                            item.CustomerTypeDescription = entityToInsert["CustomerTypeDescription"].ToString();
                            item.RELCode = entityToInsert["RELCode"].ToString();
                            item.REECode = entityToInsert["REECode"].ToString();
                            item.REEAddtlInfo = entityToInsert["REEAddtlInfo"].ToString();
                            item.AcctRef = entityToInsert["AcctRef"].ToString();
                            item.RPT = entityToInsert["RPT"].ToString();
                            item.ASSETCOST = Convert.ToDecimal(entityToInsert["ASSETCOST"] == null ? 0M : entityToInsert["ASSETCOST"]);
                            item.LeaseType = entityToInsert["LeaseType"].ToString();
                            item.ICBSCollateralCode = entityToInsert["ICBSCollateralCode"].ToString();
                            item.AssetValue = Convert.ToDecimal(entityToInsert["AssetValue"] == null ? 0M : entityToInsert["AssetValue"]);
                            item.ApprovedAmount = Convert.ToDecimal(entityToInsert["ApprovedAmount"] == null ? 0M : entityToInsert["ApprovedAmount"]);
                            item.CPNumber = entityToInsert["CPNumber"].ToString();
                            item.LastPrincipalPay = Convert.ToDecimal(entityToInsert["LastPrincipalPay"] == null ? 0M : entityToInsert["LastPrincipalPay"]);
                            item.PrincipalPayDate = Convert.ToDateTime(entityToInsert["PrincipalPayDate"]);
                            item.LastInterestPay = Convert.ToDecimal(entityToInsert["LastInterestPay"] == null ? 0M : entityToInsert["LastInterestPay"]);
                            item.LastInterestPayDate = Convert.ToDateTime(entityToInsert["LastInterestPayDate"]);
                            item.PreviousMonthsNPLTaggingByRisk = entityToInsert["PreviousMonthsNPLTaggingByRisk"].ToString();
                            item.SpecificRequiredProvisions = entityToInsert["SpecificRequiredProvisions"].ToString();
                            item.GeneralRequiredProvisions = entityToInsert["GeneralRequiredProvisions"].ToString();
                            item.Reason = entityToInsert["Reason"].ToString();
                            item.RawFiles = entityToInsert["RawFiles"].ToString();
                            item.isConsolidated = Convert.ToBoolean(entityToInsert["isConsolidated"]);
                            item.isDeleted = Convert.ToBoolean(entityToInsert["isDeleted"]);
                            item.UserName = entityToInsert["UserName"].ToString();
                            item.TransDate = Convert.ToDateTime(entityToInsert["TransDate"]);
                            item.RecordDate = Convert.ToDateTime(entityToInsert["RecordDate"]);
                            item.SYSTEM = entityToInsert["SYSTEM"].ToString();
                            ++count;
                            context = AddToContext(context, item, count, 100, true);

                        }

                        #endregion

                        #region FaMS

                        Parallel.ForEach(famsData.AsEnumerable(), (dRow) =>
                        {
                            BDOLF_Consolidator item = new BDOLF_Consolidator();

                            item.SYSTEM = dRow["SYSTEM"].ToString();
                            item.RecordDate = Convert.ToDateTime(dRow["RecordDate"]);
                            item.Reason = dRow["Reason"].ToString();
                            item.RawFiles = dRow["RawFiles"].ToString();
                            item.isDeleted = Convert.ToBoolean(dRow["isDeleted"]);
                            item.UserName = dRow["UserName"].ToString();
                            item.TransDate = Convert.ToDateTime(dRow["TransDate"]);
                            item.isConsolidated = Convert.ToBoolean(dRow["isConsolidated"]);
                            item.AccountNo = dRow["AccountNo"].ToString();
                            item.ClientName = dRow["ClientName"].ToString();
                            item.AO = dRow["AO"].ToString();
                            item.StatusPerSystem = dRow["StatusPerSystem"].ToString();
                            item.ValueDate = Convert.ToDateTime(dRow["ValueDate"]);
                            item.MaturityDate = Convert.ToDateTime(dRow["MaturityDate"]);
                            item.TotalLoan = Convert.ToDecimal(dRow["TotalLoan"] == null ? 0M : dRow["TotalLoan"]);
                            item.OB = Convert.ToDecimal(dRow["OB"] == null ? 0M : dRow["OB"]);
                            item.MonthlyOB = Convert.ToDecimal(dRow["MonthlyOB"] == null ? 0M : dRow["MonthlyOB"]);
                            item.OriginalRate = Convert.ToDecimal(dRow["OriginalRate"] == null ? 0M : dRow["OriginalRate"]);
                            item.CurrentRate = Convert.ToDecimal(dRow["CurrentRate"] == null ? 0M : dRow["CurrentRate"]);
                            item.TermInMonths = (int)Convert.ToDouble(dRow["TermInMonths"] == null ? 0 : dRow["TermInMonths"]);
                            item.PerFaMSAAFICBSIndustryCode = dRow["PerFaMSAAFICBSIndustryCode"].ToString();
                            item.IndustryHeader = dRow["IndustryHeader"].ToString();
                            item.IndustryDetail = dRow["IndustryDetail"].ToString();
                            item.NextRateReviewDateExtractedPerFaMSAAFICBS = Convert.ToDateTime(dRow["NextRateReviewDateExtractedPerFaMSAAFICBS"]);
                            item.PreviousMonthsNPLTaggingByRisk = dRow["PreviousMonthsNPLTaggingByRisk"].ToString();
                            item.SpecificRequiredProvisions = dRow["SpecificRequiredProvisions"].ToString();
                            item.GeneralRequiredProvisions = dRow["GeneralRequiredProvisions"].ToString();

                            ++count;
                            context = AddToContext(context, item, count, 100, true);

                        });

                        #endregion

                        context.SaveChanges();
                    }
                    finally
                    {
                        if (context != null)
                            context.Dispose();
                    }

                    scope.Complete();
                }
            }
            catch (Exception ex)
            {
                // scope.Rollback();
                throw ex;
            }
        }

        private NTC_Context_Entities AddToContext(NTC_Context_Entities context, BDOLF_Consolidator aafmodel, int count, int commitCount, bool recreateContext)
        {
            context.Set<BDOLF_Consolidator>().Add(aafmodel);

            if (count % commitCount == 0)
            {
                context.SaveChanges();
                if (recreateContext)
                {
                    context.Dispose();
                    context = new NTC_Context_Entities();
                    context.Configuration.AutoDetectChangesEnabled = false;
                }
            }


            return context;
        }

        public void BulkUpdete(object[] objdata)
        {
            throw new NotImplementedException();
        }

        public bool ConsoChecker(string keyword)
        {
            var parameter = DateTime.Today;
            var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
            //var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));
            var query = context.BDOLF_Consolidator.Where(a => a.RecordDate < firstDayOfMonth).AsEnumerable().Any();
            // var query = context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstDayOfMonth && a.RecordDate <= lastDayOfMonth)).AsEnumerable().Any();
            return query;
        }

        //public bool ConsoCheckerCurrentMonth(string keyword)
        //{
        //    var parameter = DateTime.Today;

        //    var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
        //    var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));
        //    var query = context.BDOLF_Consolidator.Where(a => a.RecordDate < firstDayOfMonth).AsEnumerable().Any();

        //    return query;
        //}

        public void DeleteConsolidator(string keyword)
        {
            var parameter = Convert.ToDateTime(keyword);

            var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
            var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));

            var query = context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstDayOfMonth && a.RecordDate <= lastDayOfMonth)).AsEnumerable().ToList();
            
            //context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstDayOfMonth && a.RecordDate <= lastDayOfMonth))

            using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, new TimeSpan(2, 0, 0)))
            {

                try
                {
                    context.BDOLF_Consolidator.RemoveRange(query);

                    context.BDOLF_Consolidator.RemoveRange(query);

                    context.SaveChanges();
                }
                catch (Exception)
                {
                    throw;
                }
                scope.Complete();
            }

        }

        public void DeleteConsolidator(int keyword)
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<BDOLF_Consolidator> GetAll()
        {
            var parameter = DateTime.Today;

            var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
            var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));
            var query = context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstDayOfMonth && a.RecordDate <= lastDayOfMonth)).AsEnumerable();

            return query;
        }

        //public IEnumerable<BDOLF_Consolidator> ExceptionReport()
        public IQueryable<BDOLF_Consolidator> ExceptionReport()
        {
            var parameter = DateTime.Today;

            var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
            var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));
            //var query = context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstDayOfMonth && a.RecordDate <= lastDayOfMonth)).AsEnumerable();
            //var query = context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstDayOfMonth && a.RecordDate <= lastDayOfMonth)).Select(x => new AAFModel { SYSTEM = x.SYSTEM, AccountNo = x.AccountNo, ClientName = x.ClientName, AO = x.AO, StatusPerSystem = x.StatusPerSystem, PerFaMSAAFICBSIndustryCode = x.PerFaMSAAFICBSIndustryCode, IndustryHeader = x.IndustryHeader, IndustryDetail = x.IndustryDetail, PerFaMSAAFICBSAssetSize = x.PerFaMSAAFICBSAssetSize, PerFaMSAAFICBSAssetSizeInWords = x.PerFaMSAAFICBSAssetSizeInWords, RPT = x.RPT, PreviousMonthsNPLTaggingByRisk = x.PreviousMonthsNPLTaggingByRisk }).AsEnumerable();
            var query = context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstDayOfMonth && a.RecordDate <= lastDayOfMonth)).Select(x =>
                        new
                        {
                            SYSTEM = x.SYSTEM,
                            AccountNo = x.AccountNo,
                            ClientName = x.ClientName,
                            AO = x.AO,
                            StatusPerSystem = x.StatusPerSystem,
                            PerFaMSAAFICBSIndustryCode = x.PerFaMSAAFICBSIndustryCode,
                            IndustryHeader = x.IndustryHeader,
                            IndustryDetail = x.IndustryDetail,
                            PerFaMSAAFICBSAssetSize = x.PerFaMSAAFICBSAssetSize,
                            PerFaMSAAFICBSAssetSizeInWords = x.PerFaMSAAFICBSAssetSizeInWords,
                            RPT = x.RPT,
                            PreviousMonthsNPLTaggingByRisk = x.PreviousMonthsNPLTaggingByRisk
                        });
          
            return query;
        }

        public BDOLF_Consolidator GetByCode(string keyword)
        {
            throw new NotImplementedException();
        }

        public BDOLF_Consolidator GetByID(int keyword)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<BDOLF_Consolidator> GetTopOne()
        {
            var query = from data in context.BDOLF_Consolidator.OrderByDescending(t => t.TransDate).Take(1)
                        select data;

            return query;
        }

        public void DeleteInsertConsolidator(BDOLF_Consolidator gl, string keyword)
        {
            DeleteConsolidator(keyword);

            context.BDOLF_Consolidator.Add(gl);
        }

        public void Save()
        {
            throw new NotImplementedException();
        }

        public void TruncateTable()
        {
            throw new NotImplementedException();
        }

        public void UpdateConsolidator(BDOLF_Consolidator gl)
        {
            throw new NotImplementedException();
        }

        public bool isGLCodeExist(string keyword)
        {
            var parameter = DateTime.Today;

            var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
            var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));
            return context.BDOLF_Consolidator.Where(a => (a.RecordDate >= firstDayOfMonth && a.RecordDate <= lastDayOfMonth) && a.AccountNo == keyword).Any();
        }
    }
}
