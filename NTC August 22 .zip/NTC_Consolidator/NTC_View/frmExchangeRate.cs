﻿using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Core.Repository;
using NTC_Consolidator.Data;
using NTC_Consolidator.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmExchangeRate : MetroFramework.Forms.MetroForm
    {
        private IExchangeRate exchangeRateRepository;
        ToolTip tt = new ToolTip();
        DataTable dtGrid = new DataTable();
        string recDate = "";

        private static frmExchangeRate rateform = null;
        public static frmExchangeRate Instance()
        {
            if (rateform == null)
            {
                rateform = new frmExchangeRate();
            }
            return rateform;
        }

        public frmExchangeRate()
        {
            InitializeComponent();
            this.exchangeRateRepository = new ExchangeRateRepository(new NTC_Context_Entities());
            this.dgvRate.ShowCellToolTips = true;

        }

        private void frmExchangeRate_Load(object sender, EventArgs e)
        {
            GetAllRate();
            dtPicker.MinDate = DateTime.Now;
            GetCurrency();
            cmbDescription.SelectedValue = "PHP";
            txtRate.Enabled = true;
            //cmbDescription.Enabled = true;
            //btnSubmit.Enabled = true;
        }

        private void GetAllRate()
        {
            dgvRate.DataSource = exchangeRateRepository.GetAll().ToList();
            dgvRate.Columns["CurrencyID"].Visible = false;
            dgvRate.Columns["CreatedDate"].Visible = false;
            dgvRate.Columns["isDeleted"].Visible = false;

            dgvRate.Columns["DateTimeRate"].DefaultCellStyle.Format = "MM/dd/yyyy";

            this.dgvRate.ClearSelection();
        }

        private void GetCurrency()
        {
            var currencies = CultureInfo.GetCultures(CultureTypes.SpecificCultures)
                                                    .Select(ci => ci.LCID).Distinct()
                                                    .Select(id => new RegionInfo(id))
                                                    .GroupBy(r => r.ISOCurrencySymbol)
                                                    .Select(g => g.First())
                                                    .Select(r => new
                                                    {
                                                        r.ISOCurrencySymbol,
                                                        r.CurrencyEnglishName,
                                                        r.CurrencySymbol,
                                                        r.Name,
                                                    }).ToList();

            DataTable dtcurrencies = new DataTable();
            dtcurrencies.Clear();
            dtcurrencies.Columns.Add("ID");
            dtcurrencies.Columns.Add("CountryName");
            dtcurrencies.Columns.Add("CurrencySymbol");
            dtcurrencies.Columns.Add("CurrencyEnglishName");
            DataRow dr = null;

            var rowNum = 0;
            foreach (var currency in currencies)
            {
                rowNum++;
                dr = dtcurrencies.NewRow();
                dr["ID"] = rowNum;
                dr["CountryName"] = currency.Name;
                dr["CurrencySymbol"] = currency.ISOCurrencySymbol;
                dr["CurrencyEnglishName"] = currency.CurrencyEnglishName + " ( " + currency.ISOCurrencySymbol + " ) " + currency.CurrencySymbol;
                dtcurrencies.Rows.Add(dr);
            }

            dtcurrencies.DefaultView.Sort = "[CurrencyEnglishName] ASC";

            cmbDescription.DataSource = dtcurrencies;
            cmbDescription.DisplayMember = "CurrencyEnglishName";
            cmbDescription.ValueMember = "CurrencySymbol";
            //cmbDescription.SelectedText = "Philippine Peso  PHP  PhP";
            cmbDescription.SelectedIndex = -1;
        }

        private void txtRate_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;
            decimal x;
            if (ch == (char)Keys.Back)
            {
                e.Handled = false;
            }
            else if (!char.IsDigit(ch) && ch != '.' || !Decimal.TryParse(txtRate.Text + ch, out x))
            {
                e.Handled = true;
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            var isPassed = false;
            var selectedCurrency = cmbDescription.SelectedValue != null ? cmbDescription.SelectedValue.ToString() : "";
            var rateAmount = txtRate.Text;

            #region CorrespondingGL Validation Using EF DataAnnotation

            ExchangeRate eRate = new ExchangeRate();

            isPassed = IsValid(isPassed, selectedCurrency, rateAmount, eRate); //Check for Valid Input

            if (!isPassed)
            {
                return;
            }
            else
            {
                var curentRate = new BDOLF_ExchangeRate();
                curentRate.CurrencyCode = selectedCurrency;
                curentRate.CurrencyRate = rateAmount == "" ? 0M : Convert.ToDecimal(rateAmount);
                curentRate.CreatedDate = DateTime.Now;
                curentRate.CreatedBy = frmConsolidator.UserName;
                curentRate.DateTimeRate = DateTime.Now;
                curentRate.isDeleted = false;

                var data = exchangeRateRepository.GetByCode(selectedCurrency, recDate);
                
                try
                {
                    if (data != null)
                    {
                        var parameter = Convert.ToDateTime(recDate);
                        var firstDayOfMonth = new DateTime(parameter.Year, parameter.Month, 1);
                        // var lastDayOfMonth = new DateTime(parameter.Year, parameter.Month, DateTime.DaysInMonth(parameter.Year, parameter.Month));
                        if (firstDayOfMonth.Year < DateTime.Today.Year)
                        {
                            MetroFramework.MetroMessageBox.Show(this, "\r\n\r\nSorry, Rate from previous month or year is not editable", "Exchange Rate", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        }
                        else 
                        {
                            if (data.DateTimeRate.Month < DateTime.Today.Month)
                            {
                                MetroFramework.MetroMessageBox.Show(this, "\r\n\r\nSorry, Rate from previous month or year is not editable", "Exchange Rate", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                            }
                            else if (data.DateTimeRate.Month >= DateTime.Today.Month)
                            {
                                curentRate.CurrencyID = data.CurrencyID;
                                exchangeRateRepository.UpdateRate(curentRate);
                                MetroFramework.MetroMessageBox.Show(this, "\r\n\r\nSuccessfully updated", "Exchange Rate", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                    else
                    {
                        exchangeRateRepository.InsertRate(curentRate);
                        exchangeRateRepository.Save();
                        MetroFramework.MetroMessageBox.Show(this, "\r\n\r\nNew Rate for this month was successfully added", "Exchange Rate", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                   
                    cmbDescription.SelectedValue = "PHP";
                    txtRate.Text = "";
                    GetAllRate();
                }
                catch (Exception ex)
                {
                    MetroFramework.MetroMessageBox.Show(this, "\r\n\r\nError encountered, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    throw;
                }
            }

            #endregion
        }

        private bool IsValid(bool isPassed, string selectedCurrency, string rateAmount, ExchangeRate eRate)
        {
            isPassed = true;

            try
            {
                if (string.IsNullOrEmpty(selectedCurrency))
                {
                    eRate.CurrencyCode = "";
                }
                else
                {
                    lblErrCurrType.Text = "";
                }
            }
            catch (ValidationException ex)
            {
                lblErrCurrType.Text = ex.Message;
                isPassed = false;
            }

            try
            {
                if (string.IsNullOrEmpty(rateAmount))
                {
                    eRate.CurrencyRate = 0M;
                }
                else
                {
                    lblErrRate.Text = "";
                }
            }
            catch (ValidationException ex)
            {
                lblErrRate.Text = ex.Message;
                isPassed = false;
            }

            return isPassed;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            frmExchangeRate.rateform = null;
            this.Close();
        }

        private void dgvRate_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //btnSubmit.Text = "&Submit";

            //txtRate.Enabled = false;
            //cmbDescription.Enabled = false;
            btnSubmit.Enabled = true;

            if (e.RowIndex >= 0)
            {
                //gets a collection that contains all the rows
                DataGridViewRow row = this.dgvRate.Rows[e.RowIndex];
                //populate the textbox from specific value of the coordinates of column and row.
                txtRate.Text = row.Cells["CurrencyRate"].Value.ToString();
                var val = row.Cells["CurrencyCode"].Value.ToString();
                recDate = row.Cells["DateTimeRate"].Value.ToString();
                cmbDescription.SelectedValue = val;
                //dtPicker.Text = Convert.ToDateTime(row.Cells["DateTimeRate"].Value).ToShortDateString().ToString();
            }
        }

        private void frmExchangeRate_FormClosed(object sender, FormClosedEventArgs e)
        {
            frmExchangeRate.rateform = null;
        }

        private DataTable GetAllExchangeRateRecordToDataTable()
        {
            var data = exchangeRateRepository.GetAll().ToList();
            DataTable dt = new DataTable();
            dt.Columns.Add("CurrencyCode");
            dt.Columns.Add("CurrencyRate");
            dt.Columns.Add("DateTimeRate");
            DataRow dr = null;

            foreach (var item in data)
            {
                dr = dt.NewRow();
                dr["CurrencyCode"] = item.CurrencyCode;
                dr["CurrencyRate"] = item.CurrencyRate;
                dr["DateTimeRate"] = item.DateTimeRate;
                dt.Rows.Add(dr);
            }
            return dt;
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            var dtData = GetAllExchangeRateRecordToDataTable();
            SaveFileDialog diag = new SaveFileDialog();
            diag.Filter = "Excel Files(.xls)|*.xls";//| Excel Files(.xlsx) | *.xlsx";
            diag.FilterIndex = 0;
            diag.RestoreDirectory = true;
            //  diag.CreatePrompt = true;
            diag.Title = "Export Exchange Rate To Excel File";

            if (dtData.Rows.Count > 0)
            {
                if (diag.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        StreamWriter wr = new StreamWriter(diag.FileName);
                        for (int i = 0; i < dtData.Columns.Count; i++)
                        {
                            wr.Write(dtData.Columns[i].ToString().ToUpper() + "\t");
                        }

                        wr.WriteLine();
                        //write rows to excel file
                        for (int i = 0; i < (dtData.Rows.Count); i++)
                        {
                            for (int j = 0; j < dtData.Columns.Count; j++)
                            {
                                if (dtData.Rows[i][j] != null)
                                {
                                    wr.Write("" + Convert.ToString(dtData.Rows[i][j]) + "" + "\t");
                                }
                                else
                                {
                                    wr.Write("\t");
                                }
                            }
                            //go to next line
                            wr.WriteLine();
                        }

                        //close file
                        wr.Close();
                        MetroFramework.MetroMessageBox.Show(this, "\r\n\r\nExchange Rate was successfully exported", "Exchange Rate", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MetroFramework.MetroMessageBox.Show(this, "\r\n\r\nError encountered, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        throw;
                    }
                }

            }
        }

        private void editToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //btnSubmit.Text = "&Update";
            txtRate.Enabled = true;
            //cmbDescription.Enabled = true;
           // btnSubmit.Enabled = true;
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult dr = MetroFramework.MetroMessageBox.Show(this, "\r\n\r\nAre you sure you want to delte this item?", "Exchange Rate", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    var currencyCode = dgvRate.CurrentRow.Cells["CurrencyCode"].Value.ToString();
                    exchangeRateRepository.DeleteRate(currencyCode);
                    // exchangeRateRepository.Save();
                    MetroFramework.MetroMessageBox.Show(this, "\r\n\r\nSuccessfully deleted", "Exchange Rate", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    cmbDescription.SelectedValue = "PHP";
                    txtRate.Text = "";
                    GetAllRate();
                }
            }
            catch (Exception ex)
            {
                MetroFramework.MetroMessageBox.Show(this, "\r\n\r\nError encountered, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                throw;
            }
        }

        private void dgvRate_MouseDown(object sender, MouseEventArgs e)
        {

        }

        private void dgvRate_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                int rowSelected = e.RowIndex;
                if (e.RowIndex != -1)
                {
                    this.dgvRate.ClearSelection();
                    this.dgvRate.Rows[rowSelected].Selected = true;
                    DataGridViewRow row = this.dgvRate.Rows[e.RowIndex];
                    txtRate.Text = row.Cells["CurrencyRate"].Value.ToString();
                    var val = row.Cells["CurrencyCode"].Value.ToString();
                    cmbDescription.SelectedValue = val;
                }
                // you now have the selected row with the context menu showing for the user to delete etc.
            }
        }

        private void dgvRate_MouseLeave(object sender, EventArgs e)
        {

        }

        private void txtRate_MouseDown(object sender, MouseEventArgs e)
        {

        }

        private void cmbDescription_MouseDown(object sender, MouseEventArgs e)
        {

        }

        private void dgvRate_CellLeave(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void pictureBox1_MouseHover(object sender, EventArgs e)
        {
            tt.SetToolTip(this.picInfo, "By default Rate Amount is equal to zero(0.0000)\r\n\r\nClick Gridview to cancel editing.");
        }

        private void picInfo_Click(object sender, EventArgs e)
        {
            tt.SetToolTip(this.picInfo, "By default Rate Amount is equal to zero(0.0000)\r\n\r\nClick Gridview to cancel editing.");
        }

        private void dgvRate_MouseHover(object sender, EventArgs e)
        {
            tt.SetToolTip(this.dgvRate, "Rigth Click the Item to Edte or Delete the records.");
        }

        private void dgvRate_MouseMove(object sender, MouseEventArgs e)
        {
        }
    }
}
