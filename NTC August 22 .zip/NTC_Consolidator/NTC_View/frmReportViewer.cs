﻿using Microsoft.Reporting.WinForms;
using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Core.Repository;
using NTC_Consolidator.Data;
using NTC_Consolidator.Helper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmReportViewer : MetroFramework.Forms.MetroForm
    {
        private ICorrespondingGLRepository correspondingGLRepository;
        private IConsolidator consolidatorRepository;
        private IFilePathRepository filePathRepository;
        private IExchangeRate exchangeRate;

        string module = "";

        private static frmReportViewer frmrptviewer = null;
        public static frmReportViewer Instance()
        {
            if (frmrptviewer == null)
            {
                frmrptviewer = new frmReportViewer();
            }
            return frmrptviewer;
        }

        public frmReportViewer()
        {
            InitializeComponent();

            this.consolidatorRepository = new ConsolidatorRepository(new NTC_Context_Entities());
            this.filePathRepository = new FilePathRepository(new NTC_Context_Entities());
            this.exchangeRate = new ExchangeRateRepository(new NTC_Context_Entities());
            this.correspondingGLRepository = new CorrespondingGLRepository(new NTC_Context_Entities());

            pnlWaitInfo.Location = new Point(this.ClientSize.Width / 2 - pnlWaitInfo.Size.Width / 2, this.ClientSize.Height / 2 - pnlWaitInfo.Size.Height / 2);
            pnlWaitInfo.Visible = false;
        }

        #region 'Disable Export to PDF and Export to Word'
        private void DisableReportViewerExportToExcel()
        {
            var toolstrip = this.ntcReportViewerForm.Controls.Find("toolStrip1", true)[0] as ToolStrip;
            if (toolstrip != null)
                foreach (var dropdownbutton in toolstrip.Items.OfType<ToolStripDropDownButton>())
                    dropdownbutton.DropDownOpened += new EventHandler(dropdownbutton_DropDownOpened);
        }

        void dropdownbutton_DropDownOpened(object sender, EventArgs e)
        {
            if (sender is ToolStripDropDownButton)
            {
                var ddlist = sender as ToolStripDropDownButton;

                foreach (var item in ddlist.DropDownItems.OfType<ToolStripDropDownItem>())
                    if (item.Text.Contains("PDF") || item.Text.Contains("Word"))
                    {
                        item.Enabled = false;
                    }
            }
        }
        #endregion

        private void frmReportViewer_Load(object sender, EventArgs e)
        {
            this.ntcReportViewerForm.RefreshReport();
            btnExecute.Enabled = false;

            cmbRptType.DataSource = ReportType();

            cmbRptType.DisplayMember = "Text";
            cmbRptType.ValueMember = "Value";

            cmbModeuleName.DataSource = ModuleName();
            cmbModeuleName.DisplayMember = "Text";
            cmbModeuleName.ValueMember = "Value";


            cmbRptType.SelectedIndex = -1;
            cmbModeuleName.SelectedIndex = -1;
        }

        public void ExportToExcel(string rptDataSetName, string filename, DataTable dtSource, string fileDestination, string fileFormat, string rdlcFile, string sheetname)
        {
            ntcReportViewerForm.Reset();
            ntcReportViewerForm.LocalReport.DataSources.Clear();

            ReportViewer report = new ReportViewer();
            ReportDataSource rds = new ReportDataSource(rptDataSetName, dtSource);

            List<ReportParameter> parameter = new List<ReportParameter>();

            //parameter.Add(new ReportParameter("IsInitial", ReportSelectionEntities._ReportChoice == 1 ? "true" : "false"));

            var pathfile = "NTC_Consolidator.Report." + rdlcFile;
            report.ProcessingMode = ProcessingMode.Local;
            report.LocalReport.ReportEmbeddedResource = pathfile;
            this.ntcReportViewerForm.LocalReport.SetParameters(parameter);
            this.ntcReportViewerForm.LocalReport.DisplayName = sheetname;
            //report = sheetname;
            report.LocalReport.DataSources.Add(rds);

            Warning[] warnings;
            string[] streamids;
            string mimeType;
            string encoding;
            string extension;
            //this.report.LocalReport.ReportPath = "Daily Performance Report.rdlc";
            byte[] bytes = report.LocalReport.Render(fileFormat.ToUpper(), "", out mimeType, out encoding, out extension, out streamids, out warnings);
            FileStream fs = new FileStream(fileDestination, FileMode.Create);
            //Response.Buffer = true;
            fs.Write(bytes, 0, bytes.Length);
            fs.Close();

        }

        private Array ReportType()
        {
            var items = new[] {
                        new { Text = "", Value = "" },
                        new { Text = "Consolidator", Value = "consolidator" },
                        new { Text = "Corresponding GL", Value = "correspondinggl" },
                        new { Text = "Daily GL", Value = "dailygl" },
                        new { Text = "Exchange Rate", Value = "exchangerate" },
                        new { Text = "Migrated Account", Value = "migratedaccount" },
                        new { Text = "Past Due", Value = "pastdue" },
                        new { Text = "Qualifying Capital", Value = "qualifyingcapital" },
                        new { Text = "Under Litigation", Value = "underlitigation" },
                        new { Text = "Summary Report", Value = "summaryreport" }
                       };

            return items;
        }

        private Array ModuleName()
        {
            var items = new[] {
                        new { Text = "", Value = "" },
                        new { Text = "AAF - Blank Industry Code", Value = "aafblankindustrycode" },
                        new { Text = "AAF - DOSRI TAGGING", Value = "aafdosritagging" },
                        new { Text = "AAF - Zero Asset Size", Value = "aafzeroassetsize" },
                        new { Text = "Difference in Tagging of Risk and GL", Value = "differenceintaggingofriskandgl" },
                        new { Text = "ICBS - Blank Industry Code", Value = "icbsblankindustrycode" },
                        new { Text = "ICBS - DOSRI Tagging", Value = "icbsdosritagging" },
                        new { Text = "ICBS - Zero Asset Size", Value = "icbszeroassetsize" },
                       };

            return items;
        }

        private DataTable GetConsolidator()
        {
            pnlWaitInfo.Visible = true;
            lblWaitInfo.Text = "Please wait while loading records...";
            lblWaitStatus.Text = "Status: Fetching Data.";

            var query = consolidatorRepository.GetAll().ToList();
            pnlWaitInfo.Visible = false;
            return query.ToDataTable();
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {

            DataTable dtSource = new DataTable();
            DataTable dtexceptionalReport = new DataTable();
            var ExportFilename = "";
            var rptDataSetName = "";
            var filename = "";
            var fileDestination = "";
            var fileFormat = "";
            var rdlcFile = "";
            var sheetname = "";

            SaveFileDialog diag = new SaveFileDialog();
            diag.Filter = "Excel Files(.xls)|*.xls";//| Excel Files(.xlsx) | *.xlsx";
            diag.FilterIndex = 0;
            diag.RestoreDirectory = true;
            diag.Title = "Export NTC Consolidator To Excel File";

            if (!string.IsNullOrEmpty(module))
            {
                if (diag.ShowDialog() == DialogResult.OK)
                {
                    pnlWaitInfo.Visible = false;

                    ExportFilename = diag.FileName;
                    fileDestination = Path.GetFullPath(diag.FileName);
                    fileFormat = "Excel";

                    //set filter module here
                    //this query is for exceptional report only
                    dtexceptionalReport = GetConsolidator();


                    switch (module.ToString().Trim().ToLower())
                    {
                        case "consolidator":
                            dtSource = consolidatorRepository.GetAll().ToDataTable();
                            rptDataSetName = "dsNTCReport";
                            filename = "NTC Consolidated File";
                            rdlcFile = "NTCConsolidatorReport.rdlc";
                            sheetname = "NTC Consolidated Report";
                            break;
                        case "corresponding gl":
                            dtSource = correspondingGLRepository.GetGL().ToDataTable();//.ToDataTable();
                            rptDataSetName = "dsCorrespondingGL";
                            filename = "NTC Corresponding GL";
                            rdlcFile = "CorrespondingGL.rdlc";
                            sheetname = "NTC Corresponding GL";
                            break;
                        case "daily gl":
                            dtSource = correspondingGLRepository.GetGL().ToDataTable();//.ToDataTable();
                            rptDataSetName = "dsCorrespondingGL";
                            filename = "NTC Daily GL";
                            rdlcFile = "DailyGL.rdlc";
                            sheetname = "NTC Corresponding GL";
                            break;
                        case "exchange rate":
                            dtSource = correspondingGLRepository.GetGL().ToDataTable();//.ToDataTable();
                            rptDataSetName = "dsCorrespondingGL";
                            filename = "NTC Exchange Rate";
                            rdlcFile = "ExchangeRate.rdlc";
                            sheetname = "NTC Exchange Rate";
                            break;
                        case "migrated account":
                            dtSource = correspondingGLRepository.GetGL().ToDataTable();//.ToDataTable();
                            rptDataSetName = "dsCorrespondingGL";
                            filename = "NTC Migrated Account";
                            rdlcFile = "MigratedAccount.rdlc";
                            sheetname = "NTC Migrated Account";
                            break;
                        case "past due":
                            dtSource = correspondingGLRepository.GetGL().ToDataTable();//.ToDataTable();
                            rptDataSetName = "dsCorrespondingGL";
                            filename = "NTC Past Due";
                            rdlcFile = "PastDue.rdlc";
                            sheetname = "NTC Past Due";
                            break;
                        case "qualifying capital":
                            dtSource = correspondingGLRepository.GetGL().ToDataTable();//.ToDataTable();
                            rptDataSetName = "dsCorrespondingGL";
                            filename = "NTC Qualifying Capital";
                            rdlcFile = "QualifyingCapital.rdlc";
                            sheetname = "NTC Qualifying Capital";
                            break;
                        case "under litigation":
                            dtSource = correspondingGLRepository.GetGL().ToDataTable();//.ToDataTable();
                            rptDataSetName = "dsCorrespondingGL";
                            filename = "NTC Under Litigation";
                            rdlcFile = "UnderLitigation.rdlc";
                            sheetname = "NTC Under Litigation";
                            break;
                        ///////////////////////////// Exceptional Report ////////////////////////////////
                        case "icbs - blank industry code":
                            dtSource = dtexceptionalReport;
                            rptDataSetName = "dsicbsblankindustrycode";
                            filename = "NTC ICBS - Blank Industry Code";
                            rdlcFile = "Icbsblankindustrycode.rdlc";
                            sheetname = "ICBS - Blank Industry Code";
                            break;
                        case "icbs - zero asset size":
                            dtSource = correspondingGLRepository.GetGL().ToDataTable();//.ToDataTable();
                            rptDataSetName = "dsicbszeroassetsize";
                            filename = "NTC ICBS - zero asset size";
                            rdlcFile = "Icbszeroassetsize.rdlc";
                            sheetname = "ICBS - zero asset size";
                            break;
                        case "icbs - dosri tagging":
                            dtSource = correspondingGLRepository.GetGL().ToDataTable();//.ToDataTable();
                            rptDataSetName = "dsicbsdosritagging";
                            filename = "NTC ICBS - dosri tagging";
                            rdlcFile = "Icbsdosritagging.rdlc";
                            sheetname = "ICBS - Dosri Tagging";
                            break;
                        case "aaf - blank industry code":
                            dtSource = correspondingGLRepository.GetGL().ToDataTable();//.ToDataTable();
                            rptDataSetName = "dsaafblankindustrycode";
                            filename = "NTC AAF - blank industry code";
                            rdlcFile = "Aafblankindustrycode.rdlc";
                            sheetname = "AAF - blank industry code";
                            break;
                        case "aaf - zero asset size":
                            dtSource = correspondingGLRepository.GetGL().ToDataTable();//.ToDataTable();
                            rptDataSetName = "dsaafzeroassetsize";
                            filename = "NTC AAF - zero asset size";
                            rdlcFile = "Aafzeroassetsize.rdlc";
                            sheetname = "AAF - zero asset size";
                            break;
                        case "aaf - dosri tagging":
                            dtSource = correspondingGLRepository.GetGL().ToDataTable();//.ToDataTable();
                            rptDataSetName = "dsaafdosritagging";
                            filename = "NTC AAF - dosri tagging";
                            rdlcFile = "Aafdosritagging.rdlc";
                            sheetname = "AAF - dosri tagging";
                            break;
                        case "difference in tagging of risk and gl":
                            dtSource = correspondingGLRepository.GetGL().ToDataTable();//.ToDataTable();
                            rptDataSetName = "dsdifferenceintaggingofriskandgl";
                            filename = "NTC Difference in tagging of risk and gl";
                            rdlcFile = "Differenceintaggingofriskandgl.rdlc";
                            sheetname = "Difference In Tagging of Risk and GL";
                            break;
                        case "summary report":
                            dtSource = correspondingGLRepository.GetGL().ToDataTable();//.ToDataTable();
                            rptDataSetName = "dssummary";
                            filename = "NTC Summary Report";
                            rdlcFile = "Summaryreport.rdlc";
                            sheetname = "Summary Report";
                            break;

                    }

                    ExportToExcel(rptDataSetName, filename, dtSource, fileDestination, fileFormat, rdlcFile, sheetname);
                }
            }
        }

        private void cmbModeuleName_SelectedIndexChanged(object sender, EventArgs e)
        {
            module = cmbModeuleName.SelectedItem.ToString();
            btnExecute.Enabled = cmbModeuleName.SelectedItem.ToString() != "" ? true : false;
        }

        private void frmReportViewer_FormClosed(object sender, FormClosedEventArgs e)
        {
            frmReportViewer.frmrptviewer = null;
        }
    }

}
