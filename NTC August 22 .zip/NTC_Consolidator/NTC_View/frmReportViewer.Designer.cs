﻿namespace NTC_Consolidator.NTC_View
{
    partial class frmReportViewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ntcReportViewerForm = new Microsoft.Reporting.WinForms.ReportViewer();
            this.btnExecute = new MetroFramework.Controls.MetroButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cmbDateTo = new MetroFramework.Controls.MetroDateTime();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.cmbDateFrom = new MetroFramework.Controls.MetroDateTime();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.pnlWaitInfo = new System.Windows.Forms.Panel();
            this.lblWaitStatus1 = new MetroFramework.Controls.MetroLabel();
            this.lblWaitFilePath = new MetroFramework.Controls.MetroLabel();
            this.lblWaitStatus = new MetroFramework.Controls.MetroLabel();
            this.lblWaitInfo = new MetroFramework.Controls.MetroLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.miniToolStrip = new System.Windows.Forms.MenuStrip();
            this.cmbRptType = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.cmbModeuleName = new MetroFramework.Controls.MetroComboBox();
            this.bdolF_ConsolidatorTableAdapter1 = new NTC_Consolidator.Report.DataSet.NTC_DataSetTableAdapters.BDOLF_ConsolidatorTableAdapter();
            this.panel1.SuspendLayout();
            this.pnlWaitInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // ntcReportViewerForm
            // 
            this.ntcReportViewerForm.LocalReport.ReportEmbeddedResource = "NTC_Consolidator.Report.NTCConsolidatorReport.rdlc";
            this.ntcReportViewerForm.Location = new System.Drawing.Point(28, 138);
            this.ntcReportViewerForm.Name = "ntcReportViewerForm";
            this.ntcReportViewerForm.Size = new System.Drawing.Size(1150, 458);
            this.ntcReportViewerForm.TabIndex = 0;
            // 
            // btnExecute
            // 
            this.btnExecute.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnExecute.Location = new System.Drawing.Point(1066, 102);
            this.btnExecute.Name = "btnExecute";
            this.btnExecute.Size = new System.Drawing.Size(111, 29);
            this.btnExecute.TabIndex = 87;
            this.btnExecute.Text = "&Generate Report";
            this.btnExecute.UseCustomBackColor = true;
            this.btnExecute.UseCustomForeColor = true;
            this.btnExecute.UseSelectable = true;
            this.btnExecute.UseStyleColors = true;
            this.btnExecute.Click += new System.EventHandler(this.btnExecute_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.metroLabel2);
            this.panel1.Controls.Add(this.cmbModeuleName);
            this.panel1.Controls.Add(this.cmbDateTo);
            this.panel1.Controls.Add(this.metroLabel3);
            this.panel1.Controls.Add(this.cmbDateFrom);
            this.panel1.Controls.Add(this.metroLabel1);
            this.panel1.Location = new System.Drawing.Point(302, 94);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(758, 42);
            this.panel1.TabIndex = 88;
            // 
            // cmbDateTo
            // 
            this.cmbDateTo.CustomFormat = "MM/dd/yyyy";
            this.cmbDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.cmbDateTo.Location = new System.Drawing.Point(594, 7);
            this.cmbDateTo.MinDate = new System.DateTime(2018, 6, 1, 0, 0, 0, 0);
            this.cmbDateTo.MinimumSize = new System.Drawing.Size(0, 29);
            this.cmbDateTo.Name = "cmbDateTo";
            this.cmbDateTo.Size = new System.Drawing.Size(144, 29);
            this.cmbDateTo.TabIndex = 91;
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.Location = new System.Drawing.Point(532, 17);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(62, 19);
            this.metroLabel3.TabIndex = 90;
            this.metroLabel3.Text = "Date To: ";
            // 
            // cmbDateFrom
            // 
            this.cmbDateFrom.CustomFormat = "MM/dd/yyyy";
            this.cmbDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.cmbDateFrom.Location = new System.Drawing.Point(375, 7);
            this.cmbDateFrom.MinDate = new System.DateTime(2018, 6, 1, 0, 0, 0, 0);
            this.cmbDateFrom.MinimumSize = new System.Drawing.Size(0, 29);
            this.cmbDateFrom.Name = "cmbDateFrom";
            this.cmbDateFrom.Size = new System.Drawing.Size(144, 29);
            this.cmbDateFrom.TabIndex = 89;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.Location = new System.Drawing.Point(298, 17);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(79, 19);
            this.metroLabel1.TabIndex = 34;
            this.metroLabel1.Text = "Date From: ";
            // 
            // pnlWaitInfo
            // 
            this.pnlWaitInfo.BackColor = System.Drawing.Color.Transparent;
            this.pnlWaitInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlWaitInfo.Controls.Add(this.lblWaitStatus1);
            this.pnlWaitInfo.Controls.Add(this.lblWaitFilePath);
            this.pnlWaitInfo.Controls.Add(this.lblWaitStatus);
            this.pnlWaitInfo.Controls.Add(this.lblWaitInfo);
            this.pnlWaitInfo.Controls.Add(this.pictureBox1);
            this.pnlWaitInfo.Location = new System.Drawing.Point(359, 722);
            this.pnlWaitInfo.Name = "pnlWaitInfo";
            this.pnlWaitInfo.Size = new System.Drawing.Size(326, 117);
            this.pnlWaitInfo.TabIndex = 89;
            // 
            // lblWaitStatus1
            // 
            this.lblWaitStatus1.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblWaitStatus1.Location = new System.Drawing.Point(3, 156);
            this.lblWaitStatus1.Name = "lblWaitStatus1";
            this.lblWaitStatus1.Size = new System.Drawing.Size(322, 19);
            this.lblWaitStatus1.TabIndex = 4;
            this.lblWaitStatus1.Text = "Total Numbers of Records:";
            this.lblWaitStatus1.Visible = false;
            // 
            // lblWaitFilePath
            // 
            this.lblWaitFilePath.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblWaitFilePath.Location = new System.Drawing.Point(3, 175);
            this.lblWaitFilePath.Name = "lblWaitFilePath";
            this.lblWaitFilePath.Size = new System.Drawing.Size(322, 19);
            this.lblWaitFilePath.TabIndex = 3;
            this.lblWaitFilePath.Text = "File Path:";
            this.lblWaitFilePath.Visible = false;
            // 
            // lblWaitStatus
            // 
            this.lblWaitStatus.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblWaitStatus.Location = new System.Drawing.Point(3, 91);
            this.lblWaitStatus.Name = "lblWaitStatus";
            this.lblWaitStatus.Size = new System.Drawing.Size(322, 19);
            this.lblWaitStatus.TabIndex = 2;
            this.lblWaitStatus.Text = "Status: ";
            // 
            // lblWaitInfo
            // 
            this.lblWaitInfo.FontSize = MetroFramework.MetroLabelSize.Small;
            this.lblWaitInfo.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.lblWaitInfo.Location = new System.Drawing.Point(3, 60);
            this.lblWaitInfo.Name = "lblWaitInfo";
            this.lblWaitInfo.Size = new System.Drawing.Size(318, 23);
            this.lblWaitInfo.TabIndex = 1;
            this.lblWaitInfo.Text = "Reading ICBS Raw File, Please Wait...";
            this.lblWaitInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::NTC_Consolidator.Properties.Resources.lg_discuss_ellipsis_preloader;
            this.pictureBox1.Location = new System.Drawing.Point(3, -14);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(318, 94);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.Location = new System.Drawing.Point(28, 112);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(84, 19);
            this.metroLabel4.TabIndex = 91;
            this.metroLabel4.Text = "Report Type:";
            // 
            // miniToolStrip
            // 
            this.miniToolStrip.AutoSize = false;
            this.miniToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.miniToolStrip.Location = new System.Drawing.Point(6, 2);
            this.miniToolStrip.Name = "miniToolStrip";
            this.miniToolStrip.Size = new System.Drawing.Size(198, 24);
            this.miniToolStrip.TabIndex = 0;
            // 
            // cmbRptType
            // 
            this.cmbRptType.DropDownHeight = 80;
            this.cmbRptType.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbRptType.FormattingEnabled = true;
            this.cmbRptType.IntegralHeight = false;
            this.cmbRptType.ItemHeight = 23;
            this.cmbRptType.Location = new System.Drawing.Point(118, 102);
            this.cmbRptType.MaxDropDownItems = 20;
            this.cmbRptType.Name = "cmbRptType";
            this.cmbRptType.Size = new System.Drawing.Size(178, 29);
            this.cmbRptType.Sorted = true;
            this.cmbRptType.TabIndex = 90;
            this.cmbRptType.UseSelectable = true;
            this.cmbRptType.UseStyleColors = true;
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.Location = new System.Drawing.Point(4, 17);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(101, 19);
            this.metroLabel2.TabIndex = 93;
            this.metroLabel2.Text = "Module Name: ";
            // 
            // cmbModeuleName
            // 
            this.cmbModeuleName.DropDownHeight = 80;
            this.cmbModeuleName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbModeuleName.FormattingEnabled = true;
            this.cmbModeuleName.IntegralHeight = false;
            this.cmbModeuleName.ItemHeight = 23;
            this.cmbModeuleName.Location = new System.Drawing.Point(108, 7);
            this.cmbModeuleName.MaxDropDownItems = 20;
            this.cmbModeuleName.Name = "cmbModeuleName";
            this.cmbModeuleName.Size = new System.Drawing.Size(178, 29);
            this.cmbModeuleName.Sorted = true;
            this.cmbModeuleName.TabIndex = 92;
            this.cmbModeuleName.UseSelectable = true;
            this.cmbModeuleName.UseStyleColors = true;
            // 
            // bdolF_ConsolidatorTableAdapter1
            // 
            this.bdolF_ConsolidatorTableAdapter1.ClearBeforeFill = true;
            // 
            // frmReportViewer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1201, 634);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.cmbRptType);
            this.Controls.Add(this.pnlWaitInfo);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnExecute);
            this.Controls.Add(this.ntcReportViewerForm);
            this.MaximizeBox = false;
            this.Name = "frmReportViewer";
            this.ShadowType = MetroFramework.Forms.MetroFormShadowType.DropShadow;
            this.Style = MetroFramework.MetroColorStyle.Yellow;
            this.Text = "NTC Report Viewer";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.frmReportViewer_FormClosed);
            this.Load += new System.EventHandler(this.frmReportViewer_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnlWaitInfo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer ntcReportViewerForm;
        private MetroFramework.Controls.MetroButton btnExecute;
        private System.Windows.Forms.Panel panel1;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        internal MetroFramework.Controls.MetroDateTime cmbDateTo;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        internal MetroFramework.Controls.MetroDateTime cmbDateFrom;
        private System.Windows.Forms.Panel pnlWaitInfo;
        private MetroFramework.Controls.MetroLabel lblWaitStatus1;
        private MetroFramework.Controls.MetroLabel lblWaitFilePath;
        private MetroFramework.Controls.MetroLabel lblWaitStatus;
        private MetroFramework.Controls.MetroLabel lblWaitInfo;
        private System.Windows.Forms.PictureBox pictureBox1;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private System.Windows.Forms.MenuStrip miniToolStrip;
        private MetroFramework.Controls.MetroComboBox cmbRptType;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroComboBox cmbModeuleName;
        private Report.DataSet.NTC_DataSetTableAdapters.BDOLF_ConsolidatorTableAdapter bdolF_ConsolidatorTableAdapter1;
    }
}