﻿using NTC_Consolidator.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmAPLAccount : MetroFramework.Forms.MetroForm
    {
        private IAPLAccount APLRepository;
        private static frmAPLAccount frmaplAccount = null;

        private BackgroundWorker retrieveWorker;
        private BackgroundWorker saveWorker;
        DataTable dtDailyGL;

        //DataTable dtupdated = new DataTable("Updated");
       // NumberStyles styles;
        DateTime dateparam;
        string[] progressArray = new string[5];


        public static frmAPLAccount Instance()
        {
            if (frmaplAccount == null)
            {
                frmaplAccount = new frmAPLAccount();
            }
            return frmaplAccount;
        }

        public frmAPLAccount()
        {
            InitializeComponent();
        }

        private void frmAPLAccount_Load(object sender, EventArgs e)
        {

        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {

        }
    }
}
