﻿using MetroFramework;
using MetroFramework.Forms;
using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Core.Repository;
using NTC_Consolidator.Data;
using NTC_Consolidator.Helper;
using NTC_Consolidator.Model;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.OleDb;
//using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Forms;


namespace NTC_Consolidator.NTC_View
{
    public partial class frmCorrespondingGL : MetroForm
    {
        private ICorrespondingGLRepository correspondingGLRepository;

        SaveFileDialog diag = new SaveFileDialog();
        DataTable dt = new DataTable();
        DataTable dtGL;
        string filename = "";
        bool isEnabled = false;
        string[] progressArray = new string[5];
        private BackgroundWorker retrieveWorker;
        private BackgroundWorker saveWorker;
        private static frmCorrespondingGL glform = null;

        public static frmCorrespondingGL Instance()
        {
            if (glform == null)
            {
                glform = new frmCorrespondingGL();
            }
            return glform;
        }

        public frmCorrespondingGL()
        {
            isEnabled = false;
            InitializeComponent();
            this.correspondingGLRepository = new CorrespondingGLRepository(new NTC_Context_Entities());

            pnlDialog.Location = new Point(
           this.ClientSize.Width / 2 - pnlDialog.Size.Width / 2,
           this.ClientSize.Height / 2 - pnlDialog.Size.Height / 2);
            pnlDialog.Visible = false;

            pnlWaitInfo.Location = new Point(
          this.ClientSize.Width / 2 - pnlWaitInfo.Size.Width / 2,
          this.ClientSize.Height / 2 - pnlWaitInfo.Size.Height / 2);
            pnlWaitInfo.Visible = false;
        }

        private void frmCorrespomdingGL_Load(object sender, EventArgs e)
        {
            ////////lblBusy.Text = "";

            ////////var _instance = new NTCService();

            ////////dt = _instance.GetAllGLRecord();

            ////////Search(txtSearch.Text);
            ////////cmbStatus.SelectedIndex = 0;
            // EnableDisabledFields(false);
            LoadData();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            //isEnabled = true;
            //EnableDisabledFields(isEnabled);

            //btnSubmit.Text = isEnabled == false ? "&Add New Record" : "&Submit";

            var isPassed = false;
            var _system = cmbSysTagging.SelectedItem != null ? cmbSysTagging.SelectedItem.ToString() : "";
            var _status = cmbStatus.SelectedItem != null ? cmbStatus.SelectedItem.ToString() : "";
            var txtcode = txtGLCode.Text;
            var txtname = txtGLName.Text;
            var product = txtProductDesc.Text;

            try
            {
                #region CorrespondingGL Validation Using EF DataAnnotation

                CorrespondingGL gl = new CorrespondingGL();

                isPassed = IsValid(isPassed, txtcode, txtname, gl, _system, _status, product); //Check for Valid Input

                if (!isPassed)
                {
                    return;
                }
                else
                {
                    //validate first before saving
                    //////var _instance = new NTCService();

                    var GLData = new BDOLF_CorrepondingGL();
                    GLData.CreatedBy = frmConsolidator.UserName;
                    GLData.CreatedDate = DateTime.Now;
                    GLData.GLCode = txtcode;
                    GLData.GLName = txtname;
                    GLData.isDeleted = false;
                    GLData.ProductDesc = product;
                    GLData.System = _system;
                    GLData.Status = _status;

                    var data = correspondingGLRepository.GetCorrespondingGLByID(txtcode);
                    if (data != null)
                    {
                        GLData.GLCode = data.GLCode;
                        MetroMessageBox.Show(this, "\r\n\r\nGL Code Already Exist in the Database", "Exists", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }


                    if (btnSubmit.Text != "&Update")
                    {
                        correspondingGLRepository.InsertCorrespondingGL(GLData);
                        correspondingGLRepository.Save();
                        MetroMessageBox.Show(this, "\r\n\r\nSuccessfully saved", "Correponding GL", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        correspondingGLRepository.UpdateCorrespondingGL(GLData);
                        correspondingGLRepository.Save();
                        MetroMessageBox.Show(this, "\r\n\r\nSuccessfully saved", "Correponding GL", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        cmbStatus.SelectedIndex = 0;
                        cmbSysTagging.SelectedIndex = -1;
                        txtProductDesc.Text =
                        txtGLCode.Text = "";
                        txtGLName.Text = "";

                    }
                }
                LoadData();


                #endregion
            }
            catch (Exception ex)
            {
                MetroMessageBox.Show(this, "\r\n\r\nError encountered, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void LoadData()
        {
            var data = correspondingGLRepository.GetGL().ToDataTable();
            #region Load Data into datagrid
            dgvGL.DataSource = data;// correspondingGLRepository.GetGL();
            dgvGL.Columns["CreatedDate"].Visible = false;
            dgvGL.Columns["CreatedBy"].Visible = false;
            dgvGL.Columns["isDeleted"].Visible = false;
            this.dgvGL.ClearSelection();
            //Search(txtSearch.Text);

            dt = data;
            #endregion
        }

        private void EnableDisabledFields(bool _isEnabled)
        {
            cmbSysTagging.Enabled = _isEnabled;
            txtGLCode.Enabled = _isEnabled;
            txtGLName.Enabled = _isEnabled;
            txtProductDesc.Enabled = _isEnabled;
            cmbStatus.Enabled = _isEnabled;
        }

        private bool IsValid(bool isPassed, string txtcode, string txtname, CorrespondingGL gl, string system, string status, string product)
        {
            isPassed = true;

            try
            {
                if (string.IsNullOrEmpty(txtcode))
                {
                    gl.GLCode = "";
                }
                else
                {
                    lblErrGLCode.Text = "";
                }
            }
            catch (ValidationException ex)
            {
                lblErrGLCode.Text = ex.Message;
                isPassed = false;
            }

            try
            {
                if (string.IsNullOrEmpty(txtname))
                {
                    gl.GLName = "";
                }
                else
                {
                    lblErrGLName.Text = "";
                }
            }
            catch (ValidationException ex)
            {
                lblErrGLName.Text = ex.Message;
                isPassed = false;
            }

            try
            {
                if (string.IsNullOrEmpty(status))
                {
                    gl.Status = "";
                }
                else
                {
                    lblErrStatus.Text = "";
                }
            }
            catch (ValidationException ex)
            {
                lblErrStatus.Text = ex.Message;
                isPassed = false;
            }

            try
            {
                if (string.IsNullOrEmpty(system))
                {
                    gl.System = "";
                }
                else
                {
                    lblErrSystemTagging.Text = "";
                }
            }
            catch (ValidationException ex)
            {
                lblErrSystemTagging.Text = ex.Message;
                isPassed = false;
            }

            try
            {
                if (string.IsNullOrEmpty(product))
                {
                    gl.ProductDesc = "";
                }
                else
                {
                    lblErrProductDesc.Text = "";
                }
            }
            catch (ValidationException ex)
            {
                lblErrProductDesc.Text = ex.Message;
                isPassed = false;
            }
            return isPassed;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            txtSearch.Text = "";
            Search("");
        }

        private void Search(string keyword)
        {
            if (!string.IsNullOrEmpty(keyword))
            {
                DataView dv = new DataView(dt);
                dv.RowFilter = "GLCode LIKE '%" + keyword + "%' OR GLName LIKE '%" + keyword + "%' OR CreatedBy LIKE '%" + keyword + "%'";

                dgvGL.DataSource = dv;
            }
            else
            {
                dgvGL.DataSource = dt;
            }
            this.dgvGL.Columns["GLName"].Width = 180;
            //this.dgvGL.Columns["RowID"].Visible = false;
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            Search(txtSearch.Text);
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            // Check if the backgroundWorker is already busy running the asynchronous operation
            if (!backgroundWorker1.IsBusy /*&& fileValidatedAndNoErrors*/)
            {
                ExportToExcel();
            }
            else
            {
                lblBusy.Text = "Busy processing, Please wait...";
            }
        }

        private void ExportToExcel()
        {
            // Stream myStream;
            diag.Filter = "Excel|*.xls";//|Excel 2010|*.xlsx";
            diag.Title = "Save Corresponding GL";
            diag.ShowDialog();
            filename = Path.GetFileName(diag.FileName);

            if (diag.FileName != "")
            {
                // This method will start the execution asynchronously in the background
                backgroundWorker1.RunWorkerAsync();
            }
        }

        private void backgroundWorker1_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            //open file
            StreamWriter wr = new StreamWriter(diag.FileName, false, Encoding.Unicode);

            try
            {
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    wr.Write(dt.Columns[i].ToString().ToUpper() + "\t");
                }

                wr.WriteLine();

                //write rows to excel file
                for (int i = 0; i < (dt.Rows.Count); i++)
                {
                    Thread.Sleep(1000);
                    for (int j = 0; j < dt.Columns.Count; j++)
                    {
                        if (dt.Rows[i][j] != null)
                        {
                            wr.Write("" + Convert.ToString(dt.Rows[i][j]) + "" + "\t");
                        }
                        else
                        {
                            wr.Write("\t");
                        }

                        if (backgroundWorker1.WorkerSupportsCancellation == true)
                        {
                            backgroundWorker1.CancelAsync();
                        }

                    }
                    //go to next line
                    wr.WriteLine();
                }
                //close file
                wr.Close();
            }
            catch (Exception ex)
            {
                lblBusy.Text = "";
                MetroMessageBox.Show(this, "\r\n\r\nError encountered while generating the excel file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void backgroundWorker1_RunWorkerCompleted(object sender, System.ComponentModel.RunWorkerCompletedEventArgs e)
        {
            lblBusy.Text = "";

            MetroMessageBox.Show(this, "\r\n\r\n" + filename + " file was successfully generated", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void deleteRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (this.dgvGL.SelectedRows.Count > 0)
                {
                    var rowSelected = this.dgvGL.SelectedRows[0].Index;

                    DialogResult responseDlg = MetroMessageBox.Show(this, "\r\n\r\nAre you sure, You want to delete this GL Code (" + dgvGL.Rows[rowSelected].Cells["GLCode"].Value + ") in the system?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (responseDlg == DialogResult.Yes)
                    {
                        var GLCode = dgvGL.CurrentRow.Cells["GLCode"].Value.ToString();
                        correspondingGLRepository.DeleteCorrespondingGL(GLCode);
                        LoadData();
                        MetroMessageBox.Show(this, "\r\n\r\n" + dgvGL.Rows[rowSelected].Cells["GLCode"].Value + " has been removed", "Remove Record", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MetroFramework.MetroMessageBox.Show(this, "\r\n\r\nError encountered, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                throw;
            }
        }

        private void DeleteItem(int rowSelected)
        {
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                DataRow recRow = dt.Rows[i];
                if (recRow["RowID"].ToString() == rowSelected.ToString())
                {
                    dt.Rows.Remove(recRow);
                    dt.AcceptChanges();
                    break;
                }
            }
        }

        private void editRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            btnSubmit.Text = "&Update";
            txtGLCode.Enabled = true;
            txtGLName.Enabled = true;
            txtProductDesc.Enabled = true;
            cmbSysTagging.Enabled = true;
            cmbStatus.Enabled = true;
            btnSubmit.Enabled = true;
        }

        private void dgvGL_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //txtGLCode.Enabled = false;
            //txtGLName.Enabled = false;
            //txtProductDesc.Enabled = false;
            //cmbSysTagging.Enabled = false;
            //cmbStatus.Enabled = false;
            //btnSubmit.Enabled = false;

            if (e.RowIndex >= 0)
            {
                //gets a collection that contains all the rows
                DataGridViewRow row = this.dgvGL.Rows[e.RowIndex];
                //populate the textbox from specific value of the coordinates of column and row.
                txtGLCode.Text = row.Cells["GLCode"].Value.ToString();
                txtGLName.Text = row.Cells["GLName"].Value.ToString();
                txtProductDesc.Text = row.Cells["ProductDesc"].Value.ToString();

                var val = row.Cells["System"].Value.ToString();
                var val1 = row.Cells["Status"].Value.ToString().Trim();

                cmbSysTagging.Text = val;

                // cmbSysTagging.SelectedValue = val;
                cmbStatus.Text = val1;


            }
        }

        private void dgvGL_CellLeave(object sender, DataGridViewCellEventArgs e)
        {
            btnSubmit.Text = "&Submit";
        }

        private void dgvGL_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                int rowSelected = e.RowIndex;
                if (e.RowIndex != -1)
                {
                    this.dgvGL.ClearSelection();
                    this.dgvGL.Rows[rowSelected].Selected = true;

                }
                // you now have the selected row with the context menu showing for the user to delete etc.
            }
        }

        private void frmCorrespondingGL_FormClosed(object sender, FormClosedEventArgs e)
        {
            frmCorrespondingGL.glform = null;
        }

        private void insertNewRecordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            txtGLCode.Text = "";
            txtGLName.Text = "";
            txtProductDesc.Text = "";
            cmbSysTagging.SelectedIndex = -1;
            cmbStatus.SelectedIndex = -1;
            btnSubmit.Text = "&Submit";
        }

        private void lblErrGLCode_Click(object sender, EventArgs e)
        {

        }

        private void metroLabel7_Click(object sender, EventArgs e)
        {
            pnlDialog.Visible = false;
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "NTC Consolidator";
            dlg.Filter = "Excel Files(.xls)|*.xls";//| Excel Files(.xlsx) | *.xlsx";

            // dlg.Multiselect = true;

            DialogResult resDlg = dlg.ShowDialog();

            if (resDlg == DialogResult.OK)
            {
                txtFilePath.Text = dlg.FileName;

                pnlDialog.Visible = false;
                pnlDialog.Visible = true;

                retrieveWorker = new BackgroundWorker();
                retrieveWorker.WorkerReportsProgress = true;
                retrieveWorker.DoWork += new DoWorkEventHandler(retrieveWorker_DoWork);
                retrieveWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(retrieveWorker_RunWorkerCompleted);
                retrieveWorker.ProgressChanged += new ProgressChangedEventHandler(retrieveWorker_ProgressChanged);
                retrieveWorker.WorkerSupportsCancellation = true;
                retrieveWorker.RunWorkerAsync();

            }
        }

        #region Load File From Excel
        private void retrieveWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitInfo.Text = "Retrieving record from " + txtFilePath.Text + ", Please wait...";

            lblWaitInfo.Text = labelsreports[1];
        }

        private void retrieveWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";
            }
            else if (e.Error != null)
            {
                lblWaitStatus.Text = "Status: Error Encountered while processing";
                return;
            }
            else
            {
                pnlWaitInfo.Visible = true;
                saveWorker = new BackgroundWorker();
                saveWorker.WorkerReportsProgress = true;
                saveWorker.DoWork += new DoWorkEventHandler(saveWorker_DoWork);
                saveWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(saveWorker_RunWorkerCompleted);
                saveWorker.ProgressChanged += new ProgressChangedEventHandler(saveWorker_ProgressChanged);
                saveWorker.WorkerSupportsCancellation = true;
                saveWorker.RunWorkerAsync();

            }
        }

        private void retrieveWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                string connString = "";

                if (Path.GetExtension(txtFilePath.Text) == ".xls")
                    connString = string.Format("Provider = Microsoft.Jet.OLEDB.4.0;Data Source={0};" + "Extended Properties='Excel 8.0;HDR=YES;IMEX=1;'", txtFilePath.Text);

                if (Path.GetExtension(txtFilePath.Text) == ".xlsx")
                {
                    MetroMessageBox.Show(this, "\r\nPlease change the file format from XLSX to XLS.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }

                using (OleDbConnection conn = new OleDbConnection(connString))
                {
                    conn.Open();
                    OleDbCommand cmd = new OleDbCommand();
                    DataTable dbSchema = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);
                    if (dbSchema == null || dbSchema.Rows.Count < 1)
                    {
                        throw new Exception("Error: Could not determined the name of the worksheet.");
                    }

                    string worksheetname = dbSchema.Rows[0]["TABLE_NAME"].ToString();

                    OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM[" + worksheetname + "] WHERE [SYSTEM] <> ''", conn);

                    DataTable dtold = new DataTable(worksheetname);

                    da.Fill(dtold);
                    progressArray[0] = (1 * 100 / dtold.Rows.Count).ToString(); // percent
                    progressArray[1] = "Loading records, Please wait..."; //header text
                    progressArray[2] = "Status: In-progress"; //Status
                    progressArray[3] = "";// i.ToString(); //column
                    progressArray[4] = "0";// dtold.Columns.Count;// headers.Length.ToString(); //total column

                    dtGL = dtold;
                    retrieveWorker.ReportProgress(1 * 100 / dtold.Rows.Count, progressArray); // wla lng, just to show the loading information
                }
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("It is already opened exclusively by another user"))
                {
                    MetroMessageBox.Show(this, "\r\n" + txtFilePath.Text + " File is already opened exclusively by another user, or you need permission to view and write its data.\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }
                else if (ex.Message.Contains("External table is not in the expected format"))
                {
                    MetroMessageBox.Show(this, "\r\nPlease save first the file with the extension name of \".xls\".\r\nNOTE: Please Close or Save all Open Documents", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }
                else
                {
                    MetroMessageBox.Show(this, "\r\n\r\nError encountered while reading the file, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
                throw new Exception("Error encountered while reading the file, Please contact your system administrator");
            }
        }

        #endregion

        #region Save Records
        private void saveWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                #region CorrespondingGL Validation Using EF DataAnnotation

                foreach (DataRow row in dtGL.Rows)
                {
                    //TextBox1.Text = row["ImagePath"].ToString();
               
                    var GLData = new BDOLF_CorrepondingGL();
                    GLData.CreatedBy = frmConsolidator.UserName;
                    GLData.CreatedDate = DateTime.Now;
                    GLData.GLCode = row["GMACT"].ToString();
                    GLData.GLName = row["GMNAME"].ToString();
                    GLData.isDeleted = false;
                    GLData.ProductDesc = row["PRODUCT DESCRIPTION PER SYSTEM"].ToString();
                    GLData.System = row["SYSTEM"].ToString();
                    GLData.Status = row["STATUS PER SYSTEM"].ToString();

                    var data = correspondingGLRepository.GetCorrespondingGLByID(GLData.GLCode);
                    if (data != null)
                    {
                        continue;
                    }
                    
                        correspondingGLRepository.InsertCorrespondingGL(GLData);
                        correspondingGLRepository.Save();
                       
                  
                    #endregion
                }
            }
            catch (Exception ex)
            {
                MetroMessageBox.Show(this, "\r\n\r\nError encountered, Please contact your system administrator", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        private void saveWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                pnlWaitInfo.Visible = false;
                lblWaitInfo.Text = "";
                lblWaitStatus.Text = "Status: Error";
            }
            else if (e.Error != null)
            {
                lblWaitStatus.Text = "Status: Error Encountered while processing";
                return;
            }
            else
            {
                pnlDialog.Visible = false;
                pnlWaitInfo.Visible = false;
                MetroMessageBox.Show(this, "\r\n" + Path.GetFileName(txtFilePath.Text) + " was successfully inserted.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadData();
            }
        }

        private void saveWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            string[] labelsreports = (string[])e.UserState;

            lblWaitInfo.Text = "Retrieving record from " + txtFilePath.Text + ", Please wait...";

            lblWaitInfo.Text = labelsreports[1];
        }

        #endregion
        private void lnkBulkInsert_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            pnlDialog.Visible = true;
        }
    }
}
