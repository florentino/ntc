﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmReportViewer : MetroFramework.Forms.MetroForm
    {
        public frmReportViewer()
        {
            InitializeComponent();
        }

        private void frmReportViewer_Load(object sender, EventArgs e)
        {
            this.ntcReportViewerForm.RefreshReport();
        }

        public void ExportToExcel(string rptDataSource, string filename, DataTable dtSource, string fileDestination, string fileFormat, string rdlcFile, string sheetname)
        {
            ReportViewer report = new ReportViewer();
            ReportDataSource rds = new ReportDataSource(rptDataSource, dtSource);

            var pathfile = "NTC_Consolidator.Report." + rdlcFile;
            report.Clear();
            report.Refresh();
            report.ProcessingMode = ProcessingMode.Local;
            report.LocalReport.ReportEmbeddedResource = pathfile;
            //report = sheetname;
            report.LocalReport.DataSources.Add(rds);
      
            Warning[] warnings;
            string[] streamids;
            string mimeType;
            string encoding;
            string extension;
            //this.report.LocalReport.ReportPath = "Daily Performance Report.rdlc";
            byte[] bytes = report.LocalReport.Render(fileFormat.ToUpper(), "", out mimeType, out encoding, out extension, out streamids, out warnings);
            FileStream fs = new FileStream(fileDestination, FileMode.Create);
            //Response.Buffer = true;
            fs.Write(bytes, 0, bytes.Length);
            fs.Close();

        }
    }
}
