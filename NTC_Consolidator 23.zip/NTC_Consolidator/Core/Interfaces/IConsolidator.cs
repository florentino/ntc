﻿using NTC_Consolidator.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTC_Consolidator.Core.Interfaces
{
    public interface IConsolidator : IDisposable
    {
        IEnumerable<BDOLF_Consolidator> GetAll();
        IEnumerable<object> ExceptionReport(DateTime datefrm, DateTime dateTo);
        BDOLF_Consolidator GetByID(int TransID);
        BDOLF_Consolidator GetByCode(string keyword);
        void DeleteInsertConsolidator(BDOLF_Consolidator ntc, string keyword);
        void DeleteConsolidator(int AccountNo);
        void TruncateTable();
        IEnumerable<BDOLF_Consolidator> GetTopOne();
        void DeleteConsolidator(string keyword);
        void UpdateConsolidator(BDOLF_Consolidator ntc);
        void BulkInsert(object[] objdata, string keyword);
        void BulkDelete(object[] objdata);
        void BulkUpdete(object[] objdata);
        bool ConsoChecker(string keyword);
        bool isGLCodeExist(string keyword);
        void Save();
    }
}
