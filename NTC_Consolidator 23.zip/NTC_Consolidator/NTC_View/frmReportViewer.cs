﻿using Microsoft.Reporting.WinForms;
using NTC_Consolidator.Core.Interfaces;
using NTC_Consolidator.Core.Repository;
using NTC_Consolidator.Data;
using NTC_Consolidator.Helper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NTC_Consolidator.NTC_View
{
    public partial class frmReportViewer : MetroFramework.Forms.MetroForm
    {
        private ICorrespondingGLRepository correspondingGLRepository;
        private IConsolidator consolidatorRepository;
        private IFilePathRepository filePathRepository;
        private IExchangeRate exchangeRate;

        DataTable dtexceptionalReport = new DataTable();
        DataTable dtSource = new DataTable();
        private static frmReportViewer frmrptviewer = null;
        //private string ExportFilename = "";
        private string rptDataSetName = "";
        private string filename = "";
        //private string fileDestination = "";

        private string rdlcFile = "";
        private string sheetname = "";

        public static frmReportViewer Instance()
        {
            if (frmrptviewer == null)
            {
                frmrptviewer = new frmReportViewer();
            }
            return frmrptviewer;
        }

        public frmReportViewer()
        {
            InitializeComponent();

            this.consolidatorRepository = new ConsolidatorRepository(new NTC_Context_Entities());
            this.filePathRepository = new FilePathRepository(new NTC_Context_Entities());
            this.exchangeRate = new ExchangeRateRepository(new NTC_Context_Entities());
            this.correspondingGLRepository = new CorrespondingGLRepository(new NTC_Context_Entities());

            pnlWaitInfo.Location = new Point(this.ClientSize.Width / 2 - pnlWaitInfo.Size.Width / 2, this.ClientSize.Height / 2 - pnlWaitInfo.Size.Height / 2);
            pnlWaitInfo.Visible = false;
        }
       
        private void frmReportViewer_Load(object sender, EventArgs e)
        {
            this.ntcReportViewerForm.RefreshReport();

            //ReportViewer report = new ReportViewer();
            //var pathfile = "NTC_Consolidator.Report.NoRecordsFound.rdlc";
            //report.ProcessingMode = ProcessingMode.Local;
            //report.LocalReport.ReportEmbeddedResource = pathfile;
            btnExecute.Enabled = false;
        }

        // public void LoadDataToRDLC(string rptDataSetName, string filename, DataTable dtSource, string fileDestination, string fileFormat, string rdlcFile, string sheetname)
        public void LoadDataToRDLC(string rptDataSetName, DataTable dtSource, string rdlcFile, string sheetname)
        {
            ReportViewer report = new ReportViewer();
           // ReportDataSource rds = new ReportDataSource("dsaafblankindustrycode", dtSource);
            // var rds = new ReportDataSource("dsaafblankindustrycode", dtSource);

            var dt = Convert.ToDateTime(cmbDateFrom.Text).ToShortDateString();
            var dt1 = Convert.ToDateTime(cmbDateTo.Text).ToShortDateString();
            //ReportParameter[] rParams = new ReportParameter[]
            //{
            //    new ReportParameter("paramDateFrom", Convert.ToDateTime(cmbDateFrom.Text).ToShortDateString()),
            //    new ReportParameter("paramDateTo", Convert.ToDateTime(cmbDateTo.Text).ToShortDateString())
            //};

            List<ReportParameter> parameter = new List<ReportParameter>();
            parameter.Add(new ReportParameter("paramDateFrom", dt));
            parameter.Add(new ReportParameter("paramDateTo", dt1));

            var pathfile = "NTC_Consolidator.Report." + rdlcFile;
           // report.ProcessingMode = ProcessingMode.Local;
           // report.LocalReport.DataSources.Add(rds);
           // report.LocalReport.ReportEmbeddedResource = pathfile;
           //// report.LocalReport.ReportPath = pathfile;
           // ntcReportViewerForm.LocalReport.DisplayName = sheetname;
           // ntcReportViewerForm.LocalReport.SetParameters(parameter);
           // report.RefreshReport();

            ReportDataSource dSource = new ReportDataSource("dsaafblankindustrycode", dtSource);
            report.LocalReport.DataSources.Add(dSource);
            report.LocalReport.ReportEmbeddedResource = pathfile;
            report.LocalReport.SetParameters(parameter);
            report.LocalReport.DisplayName = sheetname;
            report.RefreshReport();
        }

        private static void GenerateExcel(string fileDestination, string ExportFilename, string fileFormat)
        {
            ReportViewer report = new ReportViewer();

            Warning[] warnings;
            string[] streamids;
            string mimeType;
            string encoding;
            string extension;
            //this.report.LocalReport.ReportPath = "Daily Performance Report.rdlc";
            byte[] bytes = report.LocalReport.Render(fileFormat.ToUpper(), "", out mimeType, out encoding, out extension, out streamids, out warnings);
            FileStream fs = new FileStream(fileDestination, FileMode.Create);
            //Response.Buffer = true;
            fs.Write(bytes, 0, bytes.Length);
            fs.Close();
        }

        private DataTable GetConsolidator()
        {
            pnlWaitInfo.Visible = true;
            lblWaitInfo.Text = "Please wait while loading records...";
            lblWaitStatus.Text = "Status: Fetching Data.";
            pnlWaitInfo.Visible = false;

            var data = consolidatorRepository.ExceptionReport(Convert.ToDateTime(cmbDateFrom.Text), Convert.ToDateTime(cmbDateTo.Text)).AsEnumerable().ToArray();

            var result = new DataTable();
            result.Columns.Add("SYSTEM");
            result.Columns.Add("AccountNo");
            result.Columns.Add("ClientName");
            result.Columns.Add("AO");
            result.Columns.Add("StatusPerSystem");
            result.Columns.Add("PerFaMSAAFICBSIndustryCode");
            result.Columns.Add("IndustryHeader");
            result.Columns.Add("IndustryDetail");
            result.Columns.Add("PerFaMSAAFICBSAssetSize");
            result.Columns.Add("PerFaMSAAFICBSAssetSizeInWords");
            result.Columns.Add("RPT");
            result.Columns.Add("PreviousMonthsNPLTaggingByRisk");

            DataRow dr = null;

            foreach (var objVal in data)
            {
                var item = objVal.ObjectToData();

                dr = result.NewRow();
                dr["SYSTEM"] = item.Rows[0]["SYSTEM"];
                dr["AccountNo"] = item.Rows[0]["AccountNo"];
                dr["ClientName"] = item.Rows[0]["ClientName"];
                dr["AO"] = item.Rows[0]["AO"];
                dr["StatusPerSystem"] = item.Rows[0]["StatusPerSystem"];
                dr["PerFaMSAAFICBSIndustryCode"] = item.Rows[0]["PerFaMSAAFICBSIndustryCode"];
                dr["IndustryHeader"] = item.Rows[0]["IndustryHeader"];
                dr["IndustryDetail"] = item.Rows[0]["IndustryDetail"];
                dr["PerFaMSAAFICBSAssetSize"] = item.Rows[0]["PerFaMSAAFICBSAssetSize"];
                dr["PerFaMSAAFICBSAssetSizeInWords"] = item.Rows[0]["PerFaMSAAFICBSAssetSizeInWords"];
                dr["RPT"] = item.Rows[0]["RPT"];
                dr["PreviousMonthsNPLTaggingByRisk"] = item.Rows[0]["PreviousMonthsNPLTaggingByRisk"];

                result.Rows.Add(dr);
            }
            return result;
        }

        private void btnExecute_Click(object sender, EventArgs e)
        {
            dtexceptionalReport = GetConsolidator();

            switch (txtRptName.Text.Trim().ToLower())
            {
                #region NTCReport
                case "consolidator":
                    rptDataSetName = "dsNTCReport";
                    filename = "NTC Consolidated File";
                    rdlcFile = "NTCConsolidatorReport.rdlc";
                    sheetname = "NTC Consolidated Report";
                    break;
                case "corresponding gl":
                    rptDataSetName = "dsCorrespondingGL";
                    filename = "NTC Corresponding GL";
                    rdlcFile = "CorrespondingGL.rdlc";
                    sheetname = "NTC Corresponding GL";
                    break;
                case "daily gl":
                    rptDataSetName = "dsCorrespondingGL";
                    filename = "NTC Daily GL";
                    rdlcFile = "DailyGL.rdlc";
                    sheetname = "NTC Corresponding GL";
                    break;
                case "exchange rate":
                    rptDataSetName = "dsCorrespondingGL";
                    filename = "NTC Exchange Rate";
                    rdlcFile = "ExchangeRate.rdlc";
                    sheetname = "NTC Exchange Rate";
                    break;
                case "migrated account":
                    rptDataSetName = "dsCorrespondingGL";
                    filename = "NTC Migrated Account";
                    rdlcFile = "MigratedAccount.rdlc";
                    sheetname = "NTC Migrated Account";
                    break;
                case "past due":
                    rptDataSetName = "dsCorrespondingGL";
                    filename = "NTC Past Due";
                    rdlcFile = "PastDue.rdlc";
                    sheetname = "NTC Past Due";
                    break;
                case "qualifying capital":
                    rptDataSetName = "dsCorrespondingGL";
                    filename = "NTC Qualifying Capital";
                    rdlcFile = "QualifyingCapital.rdlc";
                    sheetname = "NTC Qualifying Capital";
                    break;
                case "under litigation":
                    rptDataSetName = "dsCorrespondingGL";
                    filename = "NTC Under Litigation";
                    rdlcFile = "UnderLitigation.rdlc";
                    sheetname = "NTC Under Litigation";
                    break;
                #endregion

                #region Exceptional Report
                case "icbs - blank industry code":
                    rptDataSetName = "dsicbsblankindustrycode";
                    filename = "NTC ICBS - Blank Industry Code";
                    rdlcFile = "Icbsblankindustrycode.rdlc";
                    sheetname = "ICBS - Blank Industry Code";
                    break;
                case "icbs - zero asset size":
                    rptDataSetName = "dsicbszeroassetsize";
                    filename = "NTC ICBS - zero asset size";
                    rdlcFile = "Icbszeroassetsize.rdlc";
                    sheetname = "ICBS - zero asset size";
                    break;
                case "icbs - dosri tagging":
                    rptDataSetName = "dsicbsdosritagging";
                    filename = "NTC ICBS - dosri tagging";
                    rdlcFile = "Icbsdosritagging.rdlc";
                    sheetname = "ICBS - Dosri Tagging";
                    break;
                case "aaf - blank industry code":
                    rptDataSetName = "dsaafblankindustrycode";
                    filename = "NTC AAF - blank industry code";
                    rdlcFile = "Aafblankindustrycode.rdlc";
                    sheetname = "AAF - blank industry code";
                    break;
                case "aaf - zero asset size":
                    rptDataSetName = "dsaafzeroassetsize";
                    filename = "NTC AAF - zero asset size";
                    rdlcFile = "Aafzeroassetsize.rdlc";
                    sheetname = "AAF - zero asset size";
                    break;
                case "aaf - dosri tagging":
                    rptDataSetName = "dsaafdosritagging";
                    filename = "NTC AAF - dosri tagging";
                    rdlcFile = "Aafdosritagging.rdlc";
                    sheetname = "AAF - dosri tagging";
                    break;
                case "difference in tagging of risk and gl":
                    rptDataSetName = "dsdifferenceintaggingofriskandgl";
                    filename = "NTC Difference in tagging of risk and gl";
                    rdlcFile = "Differenceintaggingofriskandgl.rdlc";
                    sheetname = "Difference In Tagging of Risk and GL";
                    break;
                case "summary report":
                    rptDataSetName = "dssummary";
                    filename = "NTC Summary Report";
                    rdlcFile = "Summaryreport.rdlc";
                    sheetname = "Summary Report";
                    break;
                    #endregion

            }

            LoadDataToRDLC(rptDataSetName, dtexceptionalReport, rdlcFile, sheetname);
        }

        private void frmReportViewer_FormClosed(object sender, FormClosedEventArgs e)
        {
            frmReportViewer.frmrptviewer = null;
        }

        private void miniToolStrip_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void consolidatorToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(consolidatorToolStripMenuItem.Text);
        }

        private void correspondingGLToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(correspondingGLToolStripMenuItem.Text);
        }

        private void rptHover(string rptname)
        {
            txtRptName.Text = rptname;
        }

        private void dailyGLToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(dailyGLToolStripMenuItem.Text);
        }

        private void exchangeRateToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(exchangeRateToolStripMenuItem.Text);
        }

        private void migratedAccountToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(migratedAccountToolStripMenuItem.Text);
        }

        private void pastDueToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(pastDueToolStripMenuItem.Text);
        }

        private void qualifyingCapitalToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(qualifyingCapitalToolStripMenuItem.Text);
        }

        private void underLitigationToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(underLitigationToolStripMenuItem.Text);
        }

        private void summaryReportToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(summaryReportToolStripMenuItem.Text);
        }

        private void aAFBlankIndustryCodeToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(aAFBlankIndustryCodeToolStripMenuItem.Text);
        }

        private void aAFDOSRITAGGINGToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(aAFDOSRITAGGINGToolStripMenuItem.Text);
        }

        private void aAFZeroAssetSizeToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(aAFZeroAssetSizeToolStripMenuItem.Text);
        }

        private void iCBSBlankIndustryCodeToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(iCBSBlankIndustryCodeToolStripMenuItem.Text);
        }

        private void iCBSDOSRITaggingToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(iCBSDOSRITaggingToolStripMenuItem.Text);
        }

        private void iCBSZeroAssetSizeToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(iCBSZeroAssetSizeToolStripMenuItem.Text);
        }

        private void differenceInTaggingOfRiskAndGLToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
            rptHover(differenceInTaggingOfRiskAndGLToolStripMenuItem.Text);
        }

        private void consolidatorToolStripMenuItem_MouseMove(object sender, MouseEventArgs e)
        {
            rptHover(consolidatorToolStripMenuItem.Text);
        }

        private void correspondingGLToolStripMenuItem_MouseMove(object sender, MouseEventArgs e)
        {
            rptHover(correspondingGLToolStripMenuItem.Text);
        }

        private void consolidatorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rptHover(consolidatorToolStripMenuItem.Text);
        }

        private void correspondingGLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rptHover(correspondingGLToolStripMenuItem.Text);
        }

        private void dailyGLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rptHover(dailyGLToolStripMenuItem.Text);
        }

        private void exchangeRateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rptHover(exchangeRateToolStripMenuItem.Text);
        }

        private void migratedAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rptHover(migratedAccountToolStripMenuItem.Text);
        }

        private void pastDueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rptHover(pastDueToolStripMenuItem.Text);
        }

        private void qualifyingCapitalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rptHover(qualifyingCapitalToolStripMenuItem.Text);
        }

        private void underLitigationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rptHover(underLitigationToolStripMenuItem.Text);
        }

        private void summaryReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rptHover(summaryReportToolStripMenuItem.Text);
        }

        private void aAFBlankIndustryCodeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rptHover(aAFBlankIndustryCodeToolStripMenuItem.Text);
        }

        private void aAFDOSRITAGGINGToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rptHover(aAFDOSRITAGGINGToolStripMenuItem.Text);
        }

        private void aAFZeroAssetSizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rptHover(aAFZeroAssetSizeToolStripMenuItem.Text);
        }

        private void iCBSBlankIndustryCodeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rptHover(iCBSBlankIndustryCodeToolStripMenuItem.Text);
        }

        private void iCBSDOSRITaggingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rptHover(iCBSDOSRITaggingToolStripMenuItem.Text);
        }

        private void iCBSZeroAssetSizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rptHover(iCBSZeroAssetSizeToolStripMenuItem.Text);
        }

        private void differenceInTaggingOfRiskAndGLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rptHover(differenceInTaggingOfRiskAndGLToolStripMenuItem.Text);
        }

        private void txtRptName_TextChanged(object sender, EventArgs e)
        {
            btnExecute.Enabled = txtRptName.Text.Length > 0 ? true : false;
        }

        private void btnExport_Click(object sender, EventArgs e)
        {
            SaveFileDialog diag = new SaveFileDialog();
            diag.Filter = "Excel Files(.xls)|*.xls";//| Excel Files(.xlsx) | *.xlsx";
            diag.FilterIndex = 0;
            diag.RestoreDirectory = true;
            diag.Title = "Export NTC Consolidator To Excel File";

            if (!string.IsNullOrEmpty(txtRptName.Text.Trim()))
            {
                if (diag.ShowDialog() == DialogResult.OK)
                {
                    pnlWaitInfo.Visible = false;
                    var ExportFilename = diag.FileName;
                    var fileDestination = Path.GetFullPath(diag.FileName);
                    var fileFormat = "Excel";

                    //set filter module here
                    //this query is for exceptional report only

                    GenerateExcel(fileDestination, ExportFilename, fileFormat);
                }
            }
        }
    }

}
